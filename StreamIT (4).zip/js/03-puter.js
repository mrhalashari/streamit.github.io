        // ===== الحساب السحابي الخاص (Puter): دخول + نسخ احتياطي/استعادة للمكتبة =====
        // تُحمَّل مكتبة puter.js كسلاً عند أول فتح للإعدادات حتى لا تُبطئ الإقلاع.
        const puterStatusPill = document.getElementById('puterStatusPill');
        const puterUserLine = document.getElementById('puterUserLine');
        const puterLoginBtn = document.getElementById('puterLoginBtn');
        const puterBackupBtn = document.getElementById('puterBackupBtn');
        const puterRestoreBtn = document.getElementById('puterRestoreBtn');
        const puterLogoutBtn = document.getElementById('puterLogoutBtn');
        const puterLastLine = document.getElementById('puterLastLine');
        const puterUsagePct = document.getElementById('puterUsagePct');
        const puterUsageBar = document.getElementById('puterUsageBar');
        const PUTER_DIR = 'streamit';
        const PUTER_BACKUP_PATH = PUTER_DIR + '/streamit-library-backup.json';
        const PUTER_M3U_PATH = PUTER_DIR + '/streamit-playlists.m3u8';
        const PUTER_TRACK_PATH = PUTER_DIR + '/streamit-tracking.json';
        const PUTER_LEGACY_PATHS = ['streamit-library-backup.json', 'streamit-playlists.m3u8', 'streamit-tracking.json'];
        const PUTER_META_KEY = 'streamit_puter_last_backup_v1';
        let puterLoadPromise = null;
        let puterBusy = false;
        let puterRestoreArmed = false;
        let puterRestoreTimer = null;
        function ensurePuterLoaded() {
            if (window.puter && window.puter.auth) return Promise.resolve(true);
            if (!puterLoadPromise) {
                puterLoadPromise = new Promise((resolve) => {
                    let done = false;
                    const fin = (v) => { if (!done) { done = true; resolve(v); } };
                    try {
                        const s = document.createElement('script');
                        s.src = 'https://js.puter.com/v2/';
                        s.async = true;
                        s.onload = () => fin(!!(window.puter && window.puter.auth));
                        s.onerror = () => fin(false);
                        document.head.appendChild(s);
                        setTimeout(() => fin(!!(window.puter && window.puter.auth)), 15000);
                    } catch (e) { fin(false); }
                });
            }
           return puterLoadPromise;
       }
        // أي عملية Puter معلّقة تُنهى بمهلة حتى لا تتجمد الأزرار (puterBusy) للأبد
        function puterOp(promise, ms) {
            return Promise.race([
                promise,
                new Promise((_, rej) => setTimeout(() => rej(new Error('puter-timeout')), ms || 45000))
            ]);
        }
        async function puterEnsureDir() {
            try {
                if (!puterSignedIn()) return false;
                try { await puterOp(window.puter.fs.mkdir(PUTER_DIR), 15000); } catch (e) {}
                return true;
            } catch (e) { return false; }
        }
        async function puterWriteFile(path, data) {
            try { await puterEnsureDir(); } catch (e) {}
            try {
                try { return await puterOp(window.puter.fs.write(path, data, { overwrite: true }), 60000); }
                catch (e1) { return await puterOp(window.puter.fs.write(path, data), 60000); }
            } catch (e) { throw e; }
        }
        async function puterDeleteIfExists(path) {
            try { await puterOp(window.puter.fs.delete(path), 15000); return true; }
            catch (e) { return false; }
        }
        async function puterReadFirst(paths) {
            let lastErr = null;
            for (const pa of paths) {
                try {
                    const blob = await puterOp(window.puter.fs.read(pa), 60000);
                    const text = await blob.text();
                    return { text, path: pa };
                } catch (e) { lastErr = e; }
            }
            throw lastErr || new Error('read-failed');
        }
        function puterSetBusy(on) {
            puterBusy = on;
            [puterLoginBtn, puterBackupBtn, puterRestoreBtn, puterLogoutBtn, document.getElementById('puterWipeBtn')].forEach(b => {
                if (!b) return;
                b.disabled = on;
                b.classList.toggle('opacity-50', on);
            });
        }
        function puterSetStatus(signed, username) {
            if (signed) {
                try { puterStatusPill.textContent = tLang('online'); } catch (e) { puterStatusPill.textContent = 'Online'; }
                puterStatusPill.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800';
                try { puterUserLine.textContent = tLang('tHello') + username; } catch (e) { puterUserLine.textContent = username; }
                puterUserLine.classList.remove('hidden');
            } else {
                try { puterStatusPill.textContent = tLang('offline'); } catch (e) { puterStatusPill.textContent = 'Offline'; }
                puterStatusPill.className = 'text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700';
                puterUserLine.classList.add('hidden');
            }
            puterLoginBtn.classList.toggle('hidden', signed);
            [puterBackupBtn, puterRestoreBtn, puterLogoutBtn, document.getElementById('puterWipeBtn')].forEach(b => {
                if (!b) return;
                b.classList.toggle('hidden', !signed);
                const isInlineBtn = (b !== puterLogoutBtn);
                b.classList.toggle('flex', !signed ? false : isInlineBtn);
                if (signed && isInlineBtn) b.classList.add('inline-flex'); else b.classList.remove('inline-flex');
            });
        }
        function renderPuterLast() {
            try {
                const raw = localStorage.getItem(PUTER_META_KEY);
                if (!raw) { puterLastLine.classList.add('hidden'); return; }
                const m = JSON.parse(raw);
                let _loc = 'en'; try { _loc = (appLang === 'ar' ? 'ar' : (appLang === 'zh' ? 'zh-CN' : (appLang === 'hi' ? 'hi-IN' : 'en-US'))); } catch (e) {}
                const d = m && m.ts ? new Date(m.ts).toLocaleString(_loc) : '';
                let _pre = 'Last cloud backup: ', _unit = 'items'; try { _pre = tLang('lastBackup'); _unit = tLang('itemsUnit'); } catch (e) {}
                puterLastLine.textContent = _pre + d + (m && m.count != null ? (' (' + m.count + ' ' + _unit + ')') : '');
                puterLastLine.classList.remove('hidden');
            } catch (e) {}
        }
        async function puterRefreshState() {
            const ok = await ensurePuterLoaded();
            if (!ok) {
                try { puterStatusPill.textContent = tLang('loadFail'); } catch (e) { puterStatusPill.textContent = 'Load failed'; }
                return false;
            }
            try {
                if (window.puter.auth.isSignedIn()) {
                    const u = await puterOp(window.puter.auth.getUser(), 15000);
                    puterSetStatus(true, (u && (u.username || u.email)) || tLang('tPuterUser'));
                } else {
                    puterSetStatus(false, '');
                }
            } catch (e) {
                puterSetStatus(false, '');
            }
            renderPuterLast();
            try { puterRefreshQuota(); } catch (e) {}
            return true;
        }
        function puterSignedIn() {
            try { return !!(window.puter && window.puter.auth && window.puter.auth.isSignedIn()); }
            catch (e) { return false; }
        }
        async function puterRefreshQuota() {
            if (!puterSignedIn()) {
                try { puterUsagePct.textContent = '—'; puterUsageBar.style.width = '0%'; } catch (e) {}
                return;
            }
            try {
                const sp = await Promise.race([
                    window.puter.fs.space(),
                    new Promise((_, rej) => setTimeout(() => rej(new Error('quota-timeout')), 10000))
                ]);
                const used = Number(sp && (sp.used ?? sp.usedBytes ?? sp.size)) || 0;
                const cap = Number(sp && (sp.capacity ?? sp.total ?? sp.limit ?? sp.max)) || 0;
                if (cap > 0) {
                    const pct = Math.min(100, (used / cap) * 100);
                    puterUsageBar.style.width = pct.toFixed(1) + '%';
                    puterUsagePct.textContent = pct.toFixed(1) + '% (' + fmtBytes(used) + ' / ' + fmtBytes(cap) + ')';
                } else if (used > 0) {
                    let _used = ''; try { _used = tLang('space'); } catch (e) { _used = 'Used'; }
                    puterUsagePct.textContent = _used + ': ' + fmtBytes(used);
                } else {
                    puterUsagePct.textContent = '—';
                }
            } catch (e) {
                try { puterUsagePct.textContent = tLang('loadFail'); } catch (e2) {}
            }
        }
        // بصمات المحتوى (SHA-256 لسطور الهوية مرتبة) — فهرسة سريعة لكل فئة عند الاستعادة
        async function puterLibraryFingerprints(items) {
            const cats = { tv: [], movie: [], live: [] };
            (items || []).forEach(it => {
                try {
                    if (it && cats[it.category]) cats[it.category].push(identityOf(it) + '|' + (it.url || ''));
                } catch (e) {}
            });
            Object.keys(cats).forEach(k => cats[k].sort());
            const all = cats.tv.concat(cats.movie, cats.live);
            return {
                counts: { tv: cats.tv.length, movie: cats.movie.length, live: cats.live.length, total: all.length },
                tv: await sha256Hex(cats.tv.join('\n')),
                movie: await sha256Hex(cats.movie.join('\n')),
                live: await sha256Hex(cats.live.join('\n')),
                total: await sha256Hex(all.join('\n'))
            };
        }
        // ملف التتبع: شوهد/لم يشاهد + آخر مشاهدة + المعلومات الكاملة للموثق
        function puterBuildTracking(items) {
            const entries = (items || []).map(it => {
                try {
                    const doc = it.tmdbDetails || null;
                    return {
                        id: it.id || '',
                        category: it.category || '',
                        title: (it.metaTitle || it.parsedShowTitle || it.cleanTitle || it.rawTitle || ''),
                        showKey: it.showKey || groupKeyOf(it) || '',
                        season: it.seasonNumber || 1,
                        episode: it.episodeNumber || 1,
                        url: it.url || '',
                        year: it.year || '',
                        watchedAt: it.watchedAt || 0,
                        watched: !!it.watchedAt,
                        isFavorite: !!it.isFavorite,
                        documented: !!doc,
                        doc: doc ? { title: doc.title || '', year: doc.year || '', rating: doc.rating || '', genres: doc.genres || '', overview: doc.overview || '', poster: doc.poster || '', backdrop: doc.backdrop || '' } : null
                    };
                } catch (e) { return null; }
            }).filter(Boolean);
            const watched = entries.filter(e => e.watched);
            return {
                app: 'streamit-tracking', v: 1, savedAt: Date.now(),
                counts: { total: entries.length, watched: watched.length, unwatched: entries.length - watched.length,
                    documented: entries.filter(e => e.documented).length, favorites: entries.filter(e => e.isFavorite).length },
                lastWatched: (function () { try { return JSON.parse(JSON.stringify(lastWatched)); } catch (e) { return null; } })(),
                entries: entries
            };
        }
        // ظرف المكتبة للمزامنة: IndexedDB أولاً (النسخة الكاملة الموثقة)، ثم مرآة localStorage
        function puterReadLibraryEnvelope() {
            const lsFallback = () => {
                try {
                    const raw = localStorage.getItem('m3u_smart_playlist_items_v8');
                    const d = JSON.parse(raw);
                    if (d && Array.isArray(d.items)) return { env: d, from: 'localstorage' };
                } catch (e) {}
                return null;
            };
            return new Promise((resolve) => {
                try {
                    const rq = indexedDB.open('streamit_db_v1', 1);
                    rq.onsuccess = () => {
                        try {
                            const db = rq.result;
                            if (!db.objectStoreNames.contains('kv')) return resolve(lsFallback());
                            const g = db.transaction('kv', 'readonly').objectStore('kv').get('library');
                            g.onsuccess = () => {
                                const v = g.result;
                                if (v && Array.isArray(v.items)) resolve({ env: v, from: 'indexeddb' });
                                else resolve(lsFallback());
                            };
                            g.onerror = () => resolve(lsFallback());
                        } catch (e) { resolve(lsFallback()); }
                    };
                    rq.onerror = () => resolve(lsFallback());
                } catch (e) { resolve(lsFallback()); }
            });
        }
        function puterWriteLibraryEnvelope(env) {
            const writeLs = () => {
                try { localStorage.setItem('m3u_smart_playlist_items_v8', JSON.stringify(env)); return true; }
                catch (e) { return false; }
            };
            return new Promise((resolve) => {
                try {
                    const rq = indexedDB.open('streamit_db_v1', 1);
                    rq.onsuccess = () => {
                        try {
                            const db = rq.result;
                            if (!db.objectStoreNames.contains('kv')) return resolve(writeLs());
                            const tx = db.transaction('kv', 'readwrite').objectStore('kv').put(env, 'library');
                            tx.onsuccess = () => resolve(writeLs());
                            tx.onerror = () => resolve(writeLs());
                        } catch (e) { resolve(writeLs()); }
                    };
                    rq.onerror = () => resolve(writeLs());
                } catch (e) { resolve(writeLs()); }
            });
        }
        puterLoginBtn.addEventListener('click', async () => {
            if (puterBusy) return;
            puterSetBusy(true);
            try {
                const ok = await ensurePuterLoaded();
                if (!ok) {
                    showStatus(tLang('tPuterLoad'), "error");
                    return;
                }
                await puterOp(window.puter.auth.signIn(), 120000);
                await puterRefreshState();
                showStatus(tLang('tLoginOk'), "success");
            } catch (e) {
                if (e && e.message === 'puter-timeout') showStatus(tLang('tLoginTimeout'), "error");
                else showStatus(tLang('tLoginCancel'), "error");
            } finally {
                puterSetBusy(false);
            }
        });
        puterLogoutBtn.addEventListener('click', () => {
            try { if (window.puter && window.puter.auth) window.puter.auth.signOut(); } catch (e) {}
            puterSetStatus(false, '');
            showStatus(tLang('tLogoutOk'), "info");
            try { puterRefreshQuota(); } catch (e) {}
        });
        puterBackupBtn.addEventListener('click', async () => {
            if (puterBusy) return;
            if (!puterSignedIn()) {
                showStatus(tLang('tNeedLogin'), "error");
                return;
            }
            puterSetBusy(true);
            try {
                const src = await puterReadLibraryEnvelope();
                if (!src || !Array.isArray(src.env.items) || src.env.items.length === 0) {
                    showStatus(tLang('tNoItems'), "error");
                    return;
                }
                const fps = await puterLibraryFingerprints(src.env.items);
                try { src.env.settings = { lang: (typeof appLang !== 'undefined' ? appLang : 'en'), autoDoc: isAutoDocOn(), impDur: (typeof isImpDurOn === 'function' ? isImpDurOn() : true), impPl: (typeof isImpPlOn === 'function' ? isImpPlOn() : false), smartAlive: (typeof isSmartAliveOn === 'function' ? isSmartAliveOn() : true), smartKind: (typeof isSmartKindOn === 'function' ? isSmartKindOn() : true), stremio: (typeof stremioAddons !== 'undefined' ? stremioAddons : []) }; } catch (e) {}
                const libPayload = { app: 'streamit', v: 1, savedAt: Date.now(), count: src.env.items.length, fingerprints: fps, settings: { lang: (typeof appLang !== 'undefined' ? appLang : 'en'), autoDoc: isAutoDocOn(), impDur: (typeof isImpDurOn === 'function' ? isImpDurOn() : true), impPl: (typeof isImpPlOn === 'function' ? isImpPlOn() : false), smartAlive: (typeof isSmartAliveOn === 'function' ? isSmartAliveOn() : true), smartKind: (typeof isSmartKindOn === 'function' ? isSmartKindOn() : true), stremio: (typeof stremioAddons !== 'undefined' ? stremioAddons : []) }, envelope: src.env };
                await puterWriteFile(PUTER_BACKUP_PATH, JSON.stringify(libPayload));
                await puterWriteFile(PUTER_M3U_PATH, buildM3U8Content(src.env.items));
                const tracking = puterBuildTracking(src.env.items);
                await puterWriteFile(PUTER_TRACK_PATH, JSON.stringify(tracking));
                try { localStorage.setItem(PUTER_META_KEY, JSON.stringify({ ts: Date.now(), count: src.env.items.length, watched: tracking.counts.watched, documented: tracking.counts.documented })); } catch (e) {}
                renderPuterLast();
                puterRefreshQuota();
                showStatus(tLang('tBackupDone') + " (" + src.env.items.length + " " + tLang('itemsUnit') + ").", "success");
            } catch (e) {
                showStatus(tLang('tBackupFail'), "error");
            } finally {
                puterSetBusy(false);
            }
        });
        puterRestoreBtn.addEventListener('click', async () => {
            if (puterBusy) return;
            if (!puterSignedIn()) {
                showStatus(tLang('tNeedLogin'), "error");
                return;
            }
            if (!puterRestoreArmed) {
                puterRestoreArmed = true;
                puterRestoreBtn.querySelector('i').className = 'fa-solid fa-triangle-exclamation';
                const orig = ' ' + tLang('restore');
                puterRestoreBtn.childNodes.forEach(n => { if (n.nodeType === 3) n.textContent = ' ' + tLang('tTapAgain'); });
                showStatus(tLang('tRestoreConfirm'), "info");
                clearTimeout(puterRestoreTimer);
                puterRestoreTimer = setTimeout(() => {
                    puterRestoreArmed = false;
                    puterRestoreBtn.querySelector('i').className = 'fa-solid fa-cloud-arrow-down';
                    puterRestoreBtn.childNodes.forEach(n => { if (n.nodeType === 3) n.textContent = orig; });
                }, 6000);
                return;
            }
            clearTimeout(puterRestoreTimer);
            puterRestoreArmed = false;
            puterSetBusy(true);
            try {
                const got = await puterReadFirst([PUTER_BACKUP_PATH].concat(PUTER_LEGACY_PATHS));
                const text = got.text;
                const data = JSON.parse(text);
                const env = data && data.envelope;
                if (!env || !Array.isArray(env.items)) throw new Error('bad-backup');
                env.ts = Date.now();
                try {
                    const rl = (data && data.settings && data.settings.lang) || (env && env.settings && env.settings.lang);
                    if (rl === 'en' || rl === 'ar' || rl === 'zh' || rl === 'hi') { try { localStorage.setItem(LANG_KEY, rl); } catch (e) {} try { appLang = rl; } catch (e) {} }
                try { const _ra = (data && data.settings && data.settings.autoDoc); if (_ra !== undefined) { autoDocOn = (_ra === undefined || _ra === true || _ra === 1 || _ra === '1'); try { localStorage.setItem('streamit_autodoc_v1', autoDocOn ? '1' : '0'); } catch (e2) {} try { const _t2 = document.getElementById('autoDocToggle'); if (_t2) _t2.checked = autoDocOn; } catch (e3) {} } } catch (e) {}
                try { const _id2 = (data && data.settings && data.settings.impDur); if (_id2 !== undefined) { impDurOn = (_id2 === undefined || _id2 === true || _id2 === 1 || _id2 === '1'); try { localStorage.setItem('streamit_impdur_v1', impDurOn ? '1' : '0'); } catch (e2) {} try { const _t2 = document.getElementById('impDurToggle'); if (_t2) _t2.checked = impDurOn; } catch (e3) {} } } catch (e) {}
                try { const _ip2 = (data && data.settings && data.settings.impPl); if (_ip2 !== undefined) { impPlOn = (_ip2 === true || _ip2 === 1 || _ip2 === '1'); try { localStorage.setItem('streamit_imppl_v1', impPlOn ? '1' : '0'); } catch (e2) {} try { const _t2 = document.getElementById('impPlToggle'); if (_t2) _t2.checked = impPlOn; } catch (e3) {} } } catch (e) {}
                try { const _sa2 = (data && data.settings && data.settings.smartAlive); if (_sa2 !== undefined) { smartAliveOn = (_sa2 === undefined || _sa2 === true || _sa2 === 1 || _sa2 === '1'); try { localStorage.setItem('streamit_smartalive_v1', smartAliveOn ? '1' : '0'); } catch (e2) {} try { const _t2 = document.getElementById('smartAliveToggle'); if (_t2) _t2.checked = smartAliveOn; } catch (e3) {} } } catch (e) {}
                try { const _sk2 = (data && data.settings && data.settings.smartKind); if (_sk2 !== undefined) { smartKindOn = (_sk2 === undefined || _sk2 === true || _sk2 === 1 || _sk2 === '1'); try { localStorage.setItem('streamit_smartkind_v1', smartKindOn ? '1' : '0'); } catch (e2) {} try { const _t2 = document.getElementById('smartKindToggle'); if (_t2) _t2.checked = smartKindOn; } catch (e3) {} } } catch (e) {}
                try {
                    const _sm2 = (data && data.settings && data.settings.stremio) || (env && env.settings && env.settings.stremio);
                    if (Array.isArray(_sm2) && _sm2.length) {
                        try { localStorage.setItem('streamit_stremio_addons_v1', JSON.stringify(_sm2.filter(x => x && x.base))); } catch (e2) {}
                        try { if (typeof stremioLoadAddons === 'function') stremioLoadAddons(); } catch (e2) {}
                        try { if (typeof renderStremioAddons === 'function') renderStremioAddons(); } catch (e2) {}
                    }
                } catch (e) {}
                } catch (e) {}
                let fpNote = '';
                try {
                    const nowFp = await puterLibraryFingerprints(env.items);
                    const oldFp = data.fingerprints || null;
                    if (oldFp && oldFp.total === nowFp.total) fpNote = ' (' + tLang('tFpMatch') + ').';
                    else if (oldFp) fpNote = ' (' + tLang('tFpNew') + ': ' + nowFp.counts.total + ' ' + tLang('itemsUnit') + ').';
                } catch (e2) {}
                await puterWriteLibraryEnvelope(env);
                showStatus(tLang('tRestored') + " (" + env.items.length + " " + tLang('itemsUnit') + ")." + fpNote + " " + tLang('tReloading'), "success");
                setTimeout(() => { try { location.reload(); } catch (e) {} }, 900);
            } catch (e) {
                showStatus(tLang('tRestoreBad'), "error");
                puterSetBusy(false);
            }
        });
        (function initPuterWipe() {
            const btn = document.getElementById('puterWipeBtn');
            if (!btn) return;
            let armed = false, timer = null;
            btn.addEventListener('click', async () => {
                if (puterBusy) return;
                if (!puterSignedIn()) { showStatus(tLang('tWipeNeedLogin'), "error"); return; }
                if (!armed) {
                    armed = true;
                    try { btn.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> ' + tLang('tWipeSure'); } catch (e) {}
                    showStatus(tLang('tWipeConfirm'), "info");
                    clearTimeout(timer);
                    timer = setTimeout(() => { armed = false; try { btn.innerHTML = '<i class="fa-solid fa-trash-can"></i> ' + tLang('wipe'); } catch (e) {} }, 6000);
                    return;
                }
                clearTimeout(timer); armed = false;
                puterSetBusy(true);
                try {
                    const targets = [PUTER_BACKUP_PATH, PUTER_M3U_PATH, PUTER_TRACK_PATH].concat(PUTER_LEGACY_PATHS);
                    for (const pa of targets) { try { await puterDeleteIfExists(pa); } catch (e) {} }
                    try {
                        const lst = await puterOp(window.puter.fs.readdir(PUTER_DIR), 15000);
                        const arr = Array.isArray(lst) ? lst : (lst && lst.files ? lst.files : []);
                        for (const f of arr) {
                            try {
                                const nm = (f && (f.name || f.path)) || '';
                                if (!nm) continue;
                                const full = PUTER_DIR + '/' + String(nm).split('/').pop();
                                await puterDeleteIfExists(full);
                            } catch (e) {}
                        }
                    } catch (e) {}
                    try { for (const pa of PUTER_LEGACY_PATHS) { try { await puterDeleteIfExists(pa); } catch (e) {} } } catch (e) {}
                    await puterEnsureDir();
                    try { await puterWriteFile(PUTER_DIR + '/.streamit-keep', JSON.stringify({ app: 'streamit', v: 1, createdAt: Date.now() })); } catch (e) {}
                    try { localStorage.removeItem(PUTER_META_KEY); } catch (e) {}
                    try { renderPuterLast(); } catch (e) {}
                    try { puterRefreshQuota(); } catch (e) {}
                    try { btn.innerHTML = '<i class="fa-solid fa-trash-can"></i> ' + tLang('wipe'); } catch (e) {}
                    showStatus(tLang('tWipeDone'), "success");
                } catch (e) {
                    showStatus(tLang('tWipeFail'), "error");
                } finally { puterSetBusy(false); }
            });
        })();

        // Export Data to M3U8 format: 3 فئات رئيسية (مسلسلات/أفلام/مباشر)،
        // والمسلسلات مجمّعة بمجلد group-title مستقل لكل مسلسل مع ترقيم S01E01
        // الذي تتعرف عليه كل تطبيقات IPTV (TiviMate وIPTV Smarters وغيرها).
        function m3uEscape(s) { return String(s == null ? '' : s).replace(/"/g, "'").trim(); }
        function pad2(n) { n = parseInt(n, 10) || 0; return (n < 10 ? '0' : '') + n; }
        function buildM3U8Content(itemsToExport = null) {
            const items = itemsToExport || parsedItems;
            if (items.length === 0) return "";
            const catOrder = { tv: 0, movie: 1, live: 2 };
            const sorted = items.slice().sort((a, b) => {
                const ca = catOrder[a.category] ?? 9, cb = catOrder[b.category] ?? 9;
                if (ca !== cb) return ca - cb;
                if (a.category === 'tv') {
                    const ka = (a.metaTitle || a.parsedShowTitle || a.cleanTitle || ''), kb = (b.metaTitle || b.parsedShowTitle || b.cleanTitle || '');
                    if (ka !== kb) return ka.localeCompare(kb);
                    const sa = (a.seasonNumber || 1) - (b.seasonNumber || 1);
                    if (sa !== 0) return sa;
                    return (a.episodeNumber || 1) - (b.episodeNumber || 1);
                }
                return String(a.cleanTitle || '').localeCompare(String(b.cleanTitle || ''));
            });

            let m3u8Content = "#EXTM3U\n";
            sorted.forEach(item => {
                const url = item.url || '';
                if (!url) return;
                const logo = (item.poster && !String(item.poster).startsWith('data:')) ? m3uEscape(item.poster) : m3uEscape(item.logo);
                if (item.category === 'tv') {
                    const show = m3uEscape(item.metaTitle || item.parsedShowTitle || item.cleanTitle || tLang('tabTv'));
                    const groupTitle = m3uEscape(tLang('tabTv') + ' - ' + show);
                    const code = 'S' + pad2(item.seasonNumber || 1) + 'E' + pad2(item.episodeNumber || 1);
                    const epName = (item.episodeTitle && String(item.episodeTitle).trim()) ? ' - ' + m3uEscape(item.episodeTitle) : '';
                    const title = `${show} ${code}${epName}`;
                    m3u8Content += `#EXTINF:-1 tvg-name="${title}" tvg-logo="${logo}" group-title="${groupTitle}",${title}\n${url}\n`;
                } else if (item.category === 'movie') {
                    const title = m3uEscape(item.cleanTitle || item.rawTitle || url) + (item.year ? ` (${m3uEscape(item.year)})` : '');
                    m3u8Content += `#EXTINF:-1 tvg-name="${title}" tvg-logo="${logo}" group-title="${tLang('tabMovie')}",${title}\n${url}\n`;
                } else {
                    const title = m3uEscape(item.cleanTitle || item.rawTitle || url);
                    m3u8Content += `#EXTINF:-1 tvg-name="${title}" tvg-logo="${logo}" group-title="${tLang('tabLive')}",${title}\n${url}\n`;
                }
            });
            return m3u8Content;
        }
        function exportAllDataToM3U8(itemsToExport = null) {
            const m3u8Content = buildM3U8Content(itemsToExport);
            if (!m3u8Content) {
                showStatus(tLang('tNoExport'), "error");
                return;
            }
            const blob = new Blob([m3u8Content], { type: 'application/x-mpegurl;charset=utf-8' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `StreamIT_Export_${Date.now()}.m3u8`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showStatus(tLang('tExported'), "success");
        }

        // Import Selection + Metadata Modals DOM Elements
        const importSelectModal = document.getElementById('importSelectModal');
        const importSummaryLine = document.getElementById('importSummaryLine');
        const importAccordion = document.getElementById('importAccordion');
        const impTvList = document.getElementById('impTvList');
        const impMovieList = document.getElementById('impMovieList');
        const impLiveList = document.getElementById('impLiveList');
        const impSusList = document.getElementById('impSusList');
        const impSusSection = document.getElementById('impSusSection');
        const impMovieMore = document.getElementById('impMovieMore');
        const impLiveMore = document.getElementById('impLiveMore');
        const impTvMore = document.getElementById('impTvMore');
        const impSusMore = document.getElementById('impSusMore');
        const cancelImportBtn = document.getElementById('cancelImportBtn');
        const confirmImportBtn = document.getElementById('confirmImportBtn');
        const closeImportModalBtn = document.getElementById('closeImportModalBtn');

        const metadataModal = document.getElementById('metadataModal');
        const metaCategoryBadge = document.getElementById('metaCategoryBadge');
        const metaSearchStage = document.getElementById('metaSearchStage');
        const metaDetailsStage = document.getElementById('metaDetailsStage');
        const metaSearchInput = document.getElementById('metaSearchInput');
        const manualSearchBtn = document.getElementById('manualSearchBtn');
        const searchResultsList = document.getElementById('searchResultsList');
        const metaPoster = document.getElementById('metaPoster');
        const metaTitle = document.getElementById('metaTitle');
        const metaYear = document.getElementById('metaYear');
        const metaOverview = document.getElementById('metaOverview');
        const metaRating = document.getElementById('metaRating');
        const metaGenres = document.getElementById('metaGenres');
        const confirmAddBtn = document.getElementById('confirmAddBtn');
        const cancelMetaBtn = document.getElementById('cancelMetaBtn');
        const docSuggestNote = document.getElementById('docSuggestNote');

        // View Details Modal DOM Elements
        const viewDetailsModal = document.getElementById('viewDetailsModal');
        const viewHeaderBackdrop = document.getElementById('viewHeaderBackdrop');
        const viewPosterImg = document.getElementById('viewPosterImg');
        const viewCategoryBadge = document.getElementById('viewCategoryBadge');
        const viewYearBadge = document.getElementById('viewYearBadge');
        const viewItemTitle = document.getElementById('viewItemTitle');
        const viewRatingVal = document.getElementById('viewRatingVal');
        const viewGenresContainer = document.getElementById('viewGenresContainer');
        const viewOverviewText = document.getElementById('viewOverviewText');

        // إغلاق ديالوغ المعلومات بالضغط على أي مكان فارغ خارجه
        viewDetailsModal.addEventListener('click', (e) => {
            if (e.target === viewDetailsModal) {
                viewDetailsModal.classList.add('hidden');
                viewDetailsModal.classList.remove('flex');
            }
        });

        // External Player Modal DOM Elements
        const playerModal = document.getElementById('playerModal');
        const playerItemTitle = document.getElementById('playerItemTitle');
        const playSystemChooserBtn = document.getElementById('playSystemChooserBtn');
        const playVlcBtn = document.getElementById('playVlcBtn');
        const playMxBtn = document.getElementById('playMxBtn');
        const playBrowserBtn = document.getElementById('playBrowserBtn');
        const copyUrlBtn = document.getElementById('copyUrlBtn');

        // إغلاق مشغّل الاختيار بالضغط على الخلفية (خارج الصندوق) أو زر X
        playerModal.addEventListener('click', (e) => {
            if (e.target === playerModal) {
                playerModal.classList.add('hidden');
                playerModal.classList.remove('flex');
            }
        });
        try {
            const playerModalClose = document.getElementById('playerModalClose');
            if (playerModalClose) playerModalClose.addEventListener('click', () => {
                playerModal.classList.add('hidden');
                playerModal.classList.remove('flex');
            });
        } catch (e) {}

        function openExternalPlayerModal(title, url, item) {
            currentPlayingUrl = url;
            playerItemTitle.textContent = title;
            playerModal.classList.remove('hidden');
            playerModal.classList.add('flex');
            if (item) markLastOpened(item);
        }

        // زر "قائمة كل مشغلات الجهاز": التنقل المباشر بالـ iframe كان يفشل،
        // على أندرويد نستخدم intent عام (بدون package) ليظهر النظام قائمة كل المشغلات،
        // وعلى باقي الأجهزة نقرة رابط حقيقية بتبويب جديد لتفعيل معالج النظام خارج الـ iframe.
        function openWithSystemChooser(url) {
            if (!url) { showStatus(tLang('tNoUrl'), "error"); return; }
            try {
                const ua = navigator.userAgent || '';
                const isAndroid = /Android/i.test(ua);
                if (isAndroid && /^https?:\/\//i.test(url)) {
                    const noScheme = url.replace(/^https?:\/\//i, '');
                    const scheme = url.toLowerCase().startsWith('https') ? 'https' : 'http';
                    window.location.href = `intent://${noScheme}#Intent;scheme=${scheme};action=android.intent.action.VIEW;type=video/*;end`;
                    return;
                }
                const a = document.createElement('a');
                a.href = url;
                a.target = '_blank';
                a.rel = 'noopener';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            } catch (err) {
                window.open(url, '_blank');
            }
        }

        playSystemChooserBtn.addEventListener('click', () => {
            openWithSystemChooser(currentPlayingUrl);
        });

        playVlcBtn.addEventListener('click', () => {
            window.location.href = `vlc://${currentPlayingUrl}`;
        });

        playMxBtn.addEventListener('click', () => {
            window.location.href = `intent:${currentPlayingUrl}#Intent;package=com.mxtech.videoplayer.ad;type=video/*;end`;
        });

        // صفحة مشغل الفيديو الداخلي: زر "تشغيل بالمشغل الداخلي" يفتح الرابط هنا بدل المتصفح
        const videoPlayerModal = document.getElementById('videoPlayerModal');
        const videoPlayerTitle = document.getElementById('videoPlayerTitle');
        const internalVideoEl = document.getElementById('internalVideoEl');
        const videoPlayerError = document.getElementById('videoPlayerError');
        const videoFallbackRow = document.getElementById('videoFallbackRow');
        const videoFallbackExternalBtn = document.getElementById('videoFallbackExternalBtn');
        const videoFallbackCopyBtn = document.getElementById('videoFallbackCopyBtn');
        let hlsInstance = null;

        function stopInternalVideo() {
            try { internalVideoEl.pause(); } catch (e) {}
            if (hlsInstance) { try { hlsInstance.destroy(); } catch (e) {} hlsInstance = null; }
            internalVideoEl.removeAttribute('src');
            try { internalVideoEl.load(); } catch (e) {}
        }

        function closeVideoPlayerPage() {
            stopInternalVideo();
            videoPlayerModal.classList.add('hidden');
            videoPlayerModal.classList.remove('flex');
            videoPlayerError.classList.add('hidden');
            videoFallbackRow.classList.add('hidden');
            videoFallbackRow.classList.remove('flex');
        }

        // إغلاق صفحة المشغل بالضغط على مكان فارغ (خلفية الفيديو فقط — لا الفيديو نفسه ولا الأزرار) أو زر X
        videoPlayerModal.addEventListener('click', (e) => {
            try {
                const bg = document.getElementById('videoBgArea');
                if (e.target === videoPlayerModal || (bg && e.target === bg)) closeVideoPlayerPage();
            } catch (e2) {}
        });
        try {
            const videoPlayerClose = document.getElementById('videoPlayerClose');
            if (videoPlayerClose) videoPlayerClose.addEventListener('click', () => { try { closeVideoPlayerPage(); } catch (e) {} });
        } catch (e) {}

        function showVideoError(msg) {
            videoPlayerError.textContent = msg;
            videoPlayerError.classList.remove('hidden');
            videoFallbackRow.classList.remove('hidden');
            videoFallbackRow.classList.add('flex');
        }

        function openVideoPlayerPage(title, url) {
            if (!url) { showStatus(tLang('tNoUrl'), "error"); return; }
            playerModal.classList.add('hidden');
            playerModal.classList.remove('flex');
            stopInternalVideo();
            videoPlayerError.classList.add('hidden');
            videoFallbackRow.classList.add('hidden');
            videoFallbackRow.classList.remove('flex');
            videoPlayerTitle.textContent = title || tLang('videoTitleDefault');
            videoPlayerModal.classList.remove('hidden');
            videoPlayerModal.classList.add('flex');
            const isHls = /\.m3u8($|\?)/i.test(url);
            const canNativeHls = internalVideoEl.canPlayType('application/vnd.apple.mpegurl') !== '';
            if (isHls && !canNativeHls && typeof Hls !== 'undefined' && Hls.isSupported()) {
                // تحميل أحادي مركّز لأقصى سرعة: مخزن أمامي صغير (الحاضر + ما أمامه مباشرة)
                // بلا تكديس خلفي، وفك التشفير بخيط منفصل، ولا دقة أعلى من حجم المشغل.
                hlsInstance = new Hls({
                    enableWorker: true,
                    capLevelToPlayerSize: true,
                    maxBufferLength: 20,
                    maxMaxBufferLength: 40,
                    maxBufferSize: 25 * 1000 * 1000,
                    maxBufferHole: 0.5,
                    liveSyncDurationCount: 2,
                    fragLoadingMaxRetry: 6,
                    manifestLoadingMaxRetry: 2,
                    levelLoadingMaxRetry: 3,
                    fragLoadingRetryDelay: 500,
                    manifestLoadingRetryDelay: 500,
                    abrEwmaDefaultEstimate: 1000000,
                    startLevel: -1
                });
                hlsInstance.on(Hls.Events.ERROR, (evt, data) => {
                    if (data && data.fatal) showVideoError(tLang('tPlayFail'));
                });
                hlsInstance.loadSource(url);
                hlsInstance.attachMedia(internalVideoEl);
                try { internalVideoEl.play().catch(() => {}); } catch (e) {}
            } else if (isHls && !canNativeHls) {
                showVideoError(tLang('tHlsNo'));
            } else {
                internalVideoEl.src = url;
                try { internalVideoEl.load(); } catch (e) {}
                try { internalVideoEl.play().catch(() => {}); } catch (e) {}
            }
        }

        internalVideoEl.addEventListener('error', () => {
            if (internalVideoEl.getAttribute('src')) showVideoError(tLang('tPlayErr'));
        });
        videoFallbackExternalBtn.addEventListener('click', () => openWithSystemChooser(currentPlayingUrl));
        videoFallbackCopyBtn.addEventListener('click', () => copyUrlBtn.click());

        playBrowserBtn.addEventListener('click', () => {
            openVideoPlayerPage(playerItemTitle.textContent, currentPlayingUrl);
        });

        copyUrlBtn.addEventListener('click', () => {
            const textarea = document.createElement('textarea');
            textarea.value = currentPlayingUrl;
            document.body.appendChild(textarea);
            textarea.select();
            try {
                document.execCommand('copy');
                showStatus(tLang('tCopied'), "success");
            } catch (err) {
                showStatus(tLang('tCopyFail'), "error");
            }
            document.body.removeChild(textarea);
        });

        function showFullExtractedDetails(itemData) {
            const isGroup = itemData.isShowGroup;
            const categoryText = isGroup ? tLang('catTv') : (itemData.category === 'movie' ? tLang('catMovie') : tLang('catLive'));
            
            viewCategoryBadge.textContent = categoryText;
            viewCategoryBadge.className = isGroup ? 
                'text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-400 border border-amber-800' :
                'text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-950 text-purple-400 border border-purple-800';

            const posterUrl = itemData.poster || generateSvgAvatar(itemData.title || itemData.cleanTitle);
            viewPosterImg.src = posterUrl;
            viewHeaderBackdrop.style.backgroundImage = `url('${itemData.backdrop || posterUrl}')`;

            viewItemTitle.textContent = itemData.isShowGroup ? (showLoc(itemData).title || itemData.title || itemData.cleanTitle || tLang('detailsFallback')) : (locDoc(itemData).title || dispName(itemData) || tLang('detailsFallback'));
            viewYearBadge.textContent = itemData.year ? `(${itemData.year})` : '';

            const rating = itemData.rating || (itemData.tmdbDetails ? itemData.tmdbDetails.rating : 'N/A');
            viewRatingVal.textContent = rating;

            const genres = genresText(itemData.isShowGroup ? showLoc(itemData).genres : locDoc(itemData).genres) || itemData.genres || (itemData.tmdbDetails ? itemData.tmdbDetails.genres : tLang('genresFallback'));
            viewGenresContainer.textContent = genres;

            const overview = (itemData.isShowGroup ? showLoc(itemData).overview : locDoc(itemData).overview) || itemData.overview || (itemData.tmdbDetails ? itemData.tmdbDetails.overview : tLang('noDescItem'));
            viewOverviewText.textContent = overview;

            viewDetailsModal.classList.remove('hidden');
            viewDetailsModal.classList.add('flex');
        }

        function generateSvgAvatar(text) {
            const cleanText = (text || 'M').trim().substring(0, 2).toUpperCase();
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="450" viewBox="0 0 300 450">
                <rect width="100%" height="100%" fill="#1e293b"/>
                <circle cx="150" cy="225" r="80" fill="#0f172a" stroke="#334155" stroke-width="4"/>
                <text x="50%" y="52%" dominant-baseline="middle" text-anchor="middle" fill="#38bdf8" font-size="48" font-family="sans-serif" font-weight="bold">${cleanText}</text>
            </svg>`;
            return 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svg)));
        }

        // Init App: رسم أولي فوري من المرآة المحلية، ثم ترقية من IndexedDB (الأحدث يفوز).
        // ملاحظة: الإقلاع مؤجل لـ setTimeout(0) حتى يكتمل تحليل الصفحة وتهيئة الـ const والـ CDN،
        // لأن استدعاء IndexedDB أثناء التقييم الأولي قد لا يستجيب في بعض السياقات.
        // تذكّر كل شيء: نطبّق حالة الواجهة المحفوظة (تبويب/تنقل/بحث/مسودة رابط) قبل أول رسم.
        try { const __ui0 = readLocalUi(); if (__ui0) { applyUiState(__ui0); try { window.__uiAppliedTs = __ui0.ts || 0; } catch (e) {} } } catch (e) {}
        try {
            if (navState.level !== 1) {
                const nk0 = navState.showKey || '';
                const okShow0 = (parsedItems || []).some(i => i.category === 'tv' && groupKeyOf(i) === nk0);
                if (!okShow0) navState = { level: 1, showTitle: null, showKey: null, seasonNumber: null };
            }
        } catch (e) {}
        try { applyI18n(); } catch (e) {}
        try {
            document.querySelectorAll('.lang-btn').forEach(function(b) {
                b.addEventListener('click', function() { try { setAppLang(b.getAttribute('data-lang')); } catch (e) {} });
            });
        } catch (e) {}
        // الرسم الأولي يتم في بدء التشغيل الأخير (11-scroll) بعد اكتمال كل الملفات
        try { const __sy0 = readLocalUi(); if (__sy0 && typeof __sy0.scrollY === 'number' && __sy0.scrollY > 0) setTimeout(() => { try { const __ls0 = document.getElementById('listScroll'); if (__ls0) __ls0.scrollTop = __sy0.scrollY; else window.scrollTo(0, __sy0.scrollY); } catch (e) {} }, 300); } catch (e) {}
        setTimeout(() => { try { bootStorage().then(() => { try { pruneLastWatched(); } catch (e) {} refreshApp(); try { const __u = readLocalUi(); if (__u && __u.ts && (!window.__uiAppliedTs || __u.ts > window.__uiAppliedTs)) { applyUiState(__u); window.__uiAppliedTs = __u.ts; refreshApp(); if (__u.scrollY > 0) setTimeout(() => { try { const __lsU = document.getElementById('listScroll'); if (__lsU) __lsU.scrollTop = __u.scrollY; else window.scrollTo(0, __u.scrollY); } catch (e) {} }, 100); } } catch (e) {} }).catch(() => { refreshApp(); }); } catch (e) { try { refreshApp(); } catch (e2) {} } }, 0);
        window.addEventListener('pagehide', () => { try { writeLocalUiSync(getUiSnapshot()); } catch (e) {} try { writeLocalMirror(parsedItems, lastWatched); } catch (e) {} });
        window.addEventListener('scroll', () => { try { window.scrollTo(0, 0); } catch (e) {} }, { passive: true });

        // Search Input Handling
        listSearchInput.addEventListener('input', () => {
            listSearchQuery = listSearchInput.value.trim().toLowerCase();
            if (listSearchQuery.length > 0) {
                clearListSearchBtn.classList.remove('hidden');
            } else {
                clearListSearchBtn.classList.add('hidden');
            }
            refreshApp();
            try { if (typeof stremioOnQuery === 'function') stremioOnQuery(); } catch (e) {}
        });

        clearListSearchBtn.addEventListener('click', () => {
            listSearchInput.value = '';
            listSearchQuery = '';
            clearListSearchBtn.classList.add('hidden');
            inSelectionMode = false; selectedKeys.clear();
            disarmDeleteBtn();
            refreshApp();
            try { if (typeof stremioClearBox === 'function') stremioClearBox(); } catch (e) {}
        });


        document.addEventListener('click', (e) => {
            if (!e.target.closest('.dropdown-container') && !e.target.closest('.dropdown-menu')) {
                closeAllMenus();
            }
        });

        function closeAllMenus() {
            document.querySelectorAll('.dropdown-menu').forEach(menu => {
                menu.classList.add('hidden');
                try {
                    // إعادة القائمة لموضعها الأصلي داخل البطاقة بعد إغلاقها
                    if (menu._home && menu._home.p && menu.parentElement === document.body) {
                        try { menu._home.p.insertBefore(menu, menu._home.n); } catch (e) {}
                    }
                    menu._home = null;
                } catch (e) {}
                try { menu.classList.remove('dp-fixed'); menu.style.left = ''; menu.style.top = ''; menu.style.right = ''; menu.style.zIndex = ''; } catch (e) {}
            });
        }
        // قائمة ⋮ ذكية: تُنقل لجسم الصفحة عند الفتح (هروباً من سياق تكديس البطاقة
        // z-20 الذي كان يدفنها تحت العناصر)، ثابتة فوق الكل، تنقلب للأعلى عند
        // ضيق المسافة، وتلتزم حدود الشاشة
        function positionSmartMenu(menu, btn) {
            try {
                menu.classList.remove('hidden');
                try {
                    if (menu.parentElement !== document.body) {
                        menu._home = { p: menu.parentElement, n: menu.nextSibling };
                        document.body.appendChild(menu);
                    }
                } catch (e) {}
                menu.classList.add('dp-fixed');
                const r = btn.getBoundingClientRect();
                const mh = menu.offsetHeight || 220, mw = menu.offsetWidth || 160;
                const vw = window.innerWidth || 400, vh = window.innerHeight || 700, m = 8;
                let rtl = false;
                try { rtl = (document.documentElement.dir === 'rtl'); } catch (e) {}
                let left = rtl ? r.left : (r.right - mw);
                left = Math.max(m, Math.min(left, vw - mw - m));
                const below = r.bottom + 6, above = r.top - 6 - mh;
                let top;
                if (below + mh <= vh - m) top = below;
                else if (above >= m) top = above;
                else top = Math.max(m, vh - mh - m);
                menu.style.left = left + 'px';
                menu.style.top = top + 'px';
                menu.style.right = 'auto';
                menu.style.zIndex = '90';
            } catch (e) {}
        }

