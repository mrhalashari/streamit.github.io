        // ===== تذكّر كل شيء: حالة الواجهة (خفيفة، localStorage فوري) =====
        // تُحفظ هنا في localStorage فقط (بلا اعتماد على IndexedDB حتى لا نصطدم بتهيئة لاحقة)،
        // وطبقة IndexedDB (مفتاح ui_state) تُزامَن لاحقاً من محرك التخزين بعد اكتمال تهيئته.
        var UI_STATE_KEY = 'streamit_ui_state_v1';
        var IDB_UI_KEY = 'ui_state';
        var uiSaveTimer = null;
        function readLocalUi() {
            try {
                const raw = localStorage.getItem(UI_STATE_KEY);
                if (!raw) return null;
                const s = JSON.parse(raw);
                if (s && typeof s === 'object') return s;
            } catch (e) {}
            return null;
        }
        function getUiSnapshot() {
            let scrollY = 0;
            try { const __ls = document.getElementById('listScroll'); scrollY = (__ls ? (__ls.scrollTop || 0) : (window.scrollY || 0)); } catch (e) {}
            let acc = null;
            try { acc = window.__accOpenName || null; } catch (e) {}
            let urlDraft = '';
            try { const el = document.getElementById('urlInput'); if (el) urlDraft = el.value || ''; } catch (e) {}
            return { v: 1, ts: Date.now(), currentFilter: currentFilter, navState: { level: navState.level, showTitle: navState.showTitle, showKey: navState.showKey, seasonNumber: navState.seasonNumber }, listSearchQuery: listSearchQuery, accOpenName: acc, urlDraft: urlDraft, scrollY: scrollY, tmdbHasKey: !!tmdbEffectiveKey(), appLang: (typeof appLang !== 'undefined' ? appLang : 'en') };
        }
        function writeLocalUiSync(state) {
            try { localStorage.setItem(UI_STATE_KEY, JSON.stringify(state)); return true; } catch (e) { return false; }
        }
        function saveUiStateLight() {
            try {
                clearTimeout(uiSaveTimer);
                uiSaveTimer = setTimeout(() => {
                    try { writeLocalUiSync(getUiSnapshot()); } catch (e) {}
                    try { if (typeof queueUiIdbSave === 'function') queueUiIdbSave(); } catch (e) {}
                }, 250);
            } catch (e) {}
        }
        function syncFilterTabs() {
            try {
                document.querySelectorAll('.filter-tab').forEach(t => {
                    const f = t.getAttribute('data-filter');
                    if (f === currentFilter) t.className = "filter-tab flex-1 px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold cursor-pointer transition text-xs text-center truncate";
                    else t.className = "filter-tab flex-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer transition text-xs text-center truncate";
                });
            } catch (e) {}
        }
        function applyUiState(st) {
            if (!st || typeof st !== 'object') return false;
            try {
                if (st.currentFilter === 'tv' || st.currentFilter === 'movie' || st.currentFilter === 'live') currentFilter = st.currentFilter;
                if (st.navState && typeof st.navState === 'object') {
                    const n = st.navState;
                    navState = { level: (n.level === 2 || n.level === 3) ? n.level : 1, showTitle: n.showTitle || null, showKey: n.showKey || null, seasonNumber: n.seasonNumber || null };
                    if (navState.level !== 1 && !navState.showKey && !navState.showTitle) navState = { level: 1, showTitle: null, showKey: null, seasonNumber: null };
                    if (navState.level === 3 && !navState.seasonNumber) navState.level = 2;
                }
                if (typeof st.listSearchQuery === 'string') listSearchQuery = st.listSearchQuery;
                if (st.appLang === 'en' || st.appLang === 'ar' || st.appLang === 'zh' || st.appLang === 'hi') { try { appLang = st.appLang; try { localStorage.setItem(LANG_KEY, appLang); } catch (ee) {} try { applyI18n(); } catch (ee) {} } catch (e) {} }
                if (typeof st.accOpenName === 'string' || st.accOpenName === null) { try { window.__accOpenName = st.accOpenName || null; } catch (e) {} }
                try {
                    const li = document.getElementById('listSearchInput');
                    if (li && typeof st.listSearchQuery === 'string') {
                        li.value = st.listSearchQuery;
                        const cb = document.getElementById('clearListSearchBtn');
                        if (cb) cb.classList.toggle('hidden', !(st.listSearchQuery && st.listSearchQuery.length > 0));
                    }
                } catch (e) {}
                try {
                    const ui = document.getElementById('urlInput');
                    if (ui && typeof st.urlDraft === 'string' && st.urlDraft) {
                        ui.value = st.urlDraft;
                        try { ui.dispatchEvent(new Event('input')); } catch (e) {}
                    }
                } catch (e) {}
                try { syncFilterTabs(); } catch (e) {}
                try {
                    if (typeof setAccOpen === 'function' && (st.accOpenName === 'export' || st.accOpenName === 'tmdb' || st.accOpenName === 'lang')) setAccOpen(st.accOpenName);
                } catch (e) {}
                return true;
            } catch (e) { return false; }
        }
        function pruneLastWatched() {
            try {
                let changed = false;
                const ids = new Set((parsedItems || []).map(i => i.id));
                const tvKeys = new Set();
                try { (parsedItems || []).forEach(i => { if (i && i.category === 'tv') tvKeys.add(groupKeyOf(i)); }); } catch (e) {}
                const idToCat = {};
                try { (parsedItems || []).forEach(i => { if (i) idToCat[i.id] = i.category; }); } catch (e) {}
                // تنظيف تلوث قديم: داخل shows فقط حلقات مسلسلات موجودة
                Object.keys(lastWatched.shows || {}).forEach(k => {
                    const sid = lastWatched.shows[k];
                    if (!ids.has(sid) || idToCat[sid] !== 'tv') { delete lastWatched.shows[k]; changed = true; }
                });
                if (lastWatched.movie && (!ids.has(lastWatched.movie) || idToCat[lastWatched.movie] !== 'movie')) { lastWatched.movie = null; changed = true; }
                if (lastWatched.live && (!ids.has(lastWatched.live) || idToCat[lastWatched.live] !== 'live')) { lastWatched.live = null; changed = true; }
                if (lastWatched.show && !tvKeys.has(lastWatched.show)) { lastWatched.show = null; changed = true; }
                try {
                    const _cc = lastWatched.current;
                    if (_cc && (_cc.kind === 'movie' || _cc.kind === 'live')) { if (!ids.has(_cc.id)) { lastWatched.current = null; changed = true; } }
                    else if (_cc && _cc.kind === 'tv') {
                        const _ok = (parsedItems || []).some(i => i && i.category === 'tv' && groupKeyOf(i) === _cc.key && (!_cc.id || i.id === _cc.id));
                        if (!_ok) { lastWatched.current = null; changed = true; }
                    }
                    else if (_cc) { lastWatched.current = null; changed = true; }
                } catch (e) {}
                if (changed) { try { localStorage.setItem(WATCH_KEY, JSON.stringify(lastWatched)); } catch (e) {} }
                return changed;
            } catch (e) { return false; }
        }
        // مزامنة أولى: إن كان الظرف يحمل آخر مشاهدة أحدث ومفتاح المشاهدة فارغ، نعتمدها فوراً قبل أول رسم
        try {
            const envRaw0 = localStorage.getItem(STORAGE_KEY);
            if (envRaw0) {
                const env0 = JSON.parse(envRaw0);
                if (env0 && !Array.isArray(env0) && env0.lastWatched && (!lastWatched || (!lastWatched.movie && !lastWatched.current && Object.keys(lastWatched.shows || {}).length === 0))) {
                    try { const _ec = (env0.lastWatched.current && env0.lastWatched.current.kind && env0.lastWatched.current.id) ? env0.lastWatched.current : null; lastWatched = { shows: (env0.lastWatched.shows || {}), movie: (env0.lastWatched.movie || null), live: (env0.lastWatched.live || null), show: (env0.lastWatched.show || null), current: _ec }; localStorage.setItem(WATCH_KEY, JSON.stringify(lastWatched)); } catch (e) {}
                }
            }
        } catch (e) {}
        function seasonProgress(epList) {
            let w = 0;
            (epList || []).forEach(e => { if (e.watchedAt) w++; });
            return { w, t: (epList || []).length };
        }
        function showProgress(items) { return seasonProgress(items); }
        function identityOf(it) {
            const k = it.showKey || groupKeyOf(it) || '';
            if (it.category === 'tv') return 'tv|' + k + '|S' + (it.seasonNumber || 1) + 'E' + (it.episodeNumber || 1);
            if (it.category === 'movie') return 'movie|' + k + '|' + (it.year || '');
            return 'live|' + k;
        }
        // لاحقة العرض للنسخ المكررة (1) — للعرض فقط، لا تدخل الاسم الداخلي ولا الهوية ولا التصدير
        function dispName(item) {
            if (!item) return '';
            let base = locTitleOf(item) || item.metaTitle || item.cleanTitle || item.rawTitle || '';
            if (base === 'unknown' || base === 'عنوان غير معروف') { try { base = tLang('tUnknownTitle'); } catch (e) { base = 'Unknown'; } }
            return (item.dupIndex && item.dupIndex > 0) ? (base + ' (' + item.dupIndex + ')') : base;
        }
        function nextDupIndex(baseName, category, extra) {
            let mx = 0;
            (parsedItems || []).concat(extra || []).forEach(it => {
                if (it && it.category === category && (it.cleanTitle || '') === (baseName || '')) {
                    const d = parseInt(it.dupIndex, 10) || 0;
                    if (d > mx) mx = d;
                }
            });
            return mx + 1;
        }
        // الضغطة (فتح قائمة المشغلات) = علامة "آخر مشاهدة" في فئته فقط، ولا تغيّر حالة المشاهدة للحلقات.
        // كل تاب له ذاكرة مستقلة لا تتداخل: فيلم ⇒ movie، قناة ⇒ live، حلقة ⇒ shows[المسلسل] + show
        function markLastOpened(item) {
            if (!item) return;
            if (item.category === 'movie') {
                item.watchedAt = Date.now();
                lastWatched.movie = item.id;
                try { lastWatched.current = { kind: 'movie', key: null, id: item.id, at: Date.now() }; } catch (e) {}
            } else if (item.category === 'live') {
                lastWatched.live = item.id;
                try { lastWatched.current = { kind: 'live', key: null, id: item.id, at: Date.now() }; } catch (e) {}
            } else {
                const sk = groupKeyOf(item);
                lastWatched.shows[sk] = item.id;
                lastWatched.show = sk;
                if (item.category === 'tv') { try { lastWatched.current = { kind: 'tv', key: sk, id: item.id, at: Date.now() }; } catch (e) {} }
            }
            saveItemsToStorage();
            saveLastWatched();
            refreshApp();
        }
        // زر العين للحلقة: تتابع منطقي (مشاهدة = كل ما قبلها مشاهَد، عكسها = كل ما بعدها غير مشاهَد)
        function toggleEpisodeWatched(ep) {
            if (!ep) return;
            const now = Date.now();
            const sk = groupKeyOf(ep);
            const s = ep.seasonNumber || 1, e = ep.episodeNumber || 1;
            if (ep.watchedAt) {
                parsedItems.forEach(it => {
                    if (it.category !== 'tv' || groupKeyOf(it) !== sk) return;
                    const si = it.seasonNumber || 1, ei = it.episodeNumber || 1;
                    if (si > s || (si === s && ei >= e)) it.watchedAt = 0;
                });
            } else {
                parsedItems.forEach(it => {
                    if (it.category !== 'tv' || groupKeyOf(it) !== sk) return;
                    const si = it.seasonNumber || 1, ei = it.episodeNumber || 1;
                    if (si < s || (si === s && ei <= e)) { if (!it.watchedAt) it.watchedAt = now; }
                });
            }
            saveItemsToStorage();
            refreshApp();
        }
        // الضغطتان السريعتان: تثبيت التقدّم حتى هذه الحلقة (قبلها مشاهَد، بعدها غير مشاهَد، وهي آخر مشاهَدة)
        function setProgressUpTo(ep) {
            if (!ep) return;
            const now = Date.now();
            const sk = groupKeyOf(ep);
            const s = ep.seasonNumber || 1, e = ep.episodeNumber || 1;
            parsedItems.forEach(it => {
                if (it.category !== 'tv' || groupKeyOf(it) !== sk) return;
                const si = it.seasonNumber || 1, ei = it.episodeNumber || 1;
                if (si < s || (si === s && ei <= e)) { if (!it.watchedAt) it.watchedAt = now; }
                else it.watchedAt = 0;
            });
            ep.watchedAt = now;
            lastWatched.shows[sk] = ep.id;
            lastWatched.show = sk;
            try { lastWatched.current = { kind: 'tv', key: sk, id: ep.id, at: Date.now() }; } catch (e) {}
            saveItemsToStorage();
            saveLastWatched();
            refreshApp();
        }
        function toggleMovieWatched(item) {
            if (!item || item.category !== 'movie') return;
            if (item.watchedAt) item.watchedAt = 0;
            else item.watchedAt = Date.now();
            saveItemsToStorage();
            refreshApp();
        }
        function enterSelectionMode(data) {
            inSelectionMode = true;
            if (data) {
                const k = selKeyFor(data);
                if (selectedKeys.has(k)) selectedKeys.delete(k);
                else selectedKeys.add(k);
            }
            renderCurrentLevelList();
        }
        function exitSelectionMode() {
            inSelectionMode = false;
            selectedKeys.clear();
            disarmDeleteBtn();
            renderCurrentLevelList();
        }
        function bindLongPress(card, data) {
            let lpTimer = null, sx = 0, sy = 0;
            card.addEventListener('pointerdown', (e) => {
                if (e.pointerType === 'mouse' && e.button !== 0) return;
                sx = e.clientX || 0; sy = e.clientY || 0;
                clearTimeout(lpTimer);
                lpTimer = setTimeout(() => {
                    suppressNextClick = true;
                    setTimeout(() => { suppressNextClick = false; }, 1200);
                    enterSelectionMode(data);
                }, 550);
            });
            const lpMove = (e) => {
                if (Math.hypot((e.clientX || 0) - sx, (e.clientY || 0) - sy) <= 12) return;
                clearTimeout(lpTimer);
            };
            card.addEventListener('pointermove', lpMove);
            card.addEventListener('pointerup', () => clearTimeout(lpTimer));
            card.addEventListener('pointercancel', () => clearTimeout(lpTimer));
            card.addEventListener('pointerleave', () => clearTimeout(lpTimer));
            card.addEventListener('contextmenu', (e) => e.preventDefault());
        }
        document.addEventListener('click', (e) => {
            if (suppressNextClick) { suppressNextClick = false; e.stopPropagation(); e.preventDefault(); }
        }, true);

        // DOM Elements
        const statusMessage = document.getElementById('statusMessage');
        const totalCountEl = document.getElementById('totalCount');
        const urlInput = document.getElementById('urlInput');
        const clearBtn = document.getElementById('clearBtn');
        const actionBtn = document.getElementById('actionBtn');
        const actionIcon = document.getElementById('actionIcon');
        const actionText = document.getElementById('actionText');
        const uploadProgressBar = document.getElementById('uploadProgressBar');
        const fileInput = document.getElementById('fileInput');
        const listSearchInput = document.getElementById('listSearchInput');
        const clearListSearchBtn = document.getElementById('clearListSearchBtn');
        const breadcrumbPath = document.getElementById('breadcrumbPath');
        const backToMainBtn = document.getElementById('backToMainBtn');
        const itemsGrid = document.getElementById('itemsGrid');
        const emptyState = document.getElementById('emptyState');

        // Top Settings Modal & Global Export Modals
        const topSettingsBtn = document.getElementById('topSettingsBtn');
        const globalSettingsModal = document.getElementById('globalSettingsModal');
        const closeGlobalSettingsModal = document.getElementById('closeGlobalSettingsModal');
        const exportAllM3u8Btn = document.getElementById('exportAllM3u8Btn');
        const globalApiKeyInput = document.getElementById('globalApiKeyInput');
        const saveGlobalApiKeyBtn = document.getElementById('saveGlobalApiKeyBtn');

        // إعدادات أكورديون: قسم واحد مفتوح فقط، والمنقبض لا يأخذ مساحة
        function setAccOpen(name) {
            window.__accOpenName = name || null;
            document.querySelectorAll('#settingsAccordion .acc-body').forEach(b => {
                const isOpen = b.dataset.accBody === name;
                b.style.maxHeight = isOpen ? (b.scrollHeight + 'px') : '0px';
            });
            document.querySelectorAll('#settingsAccordion .acc-head').forEach(h => {
                const isOpen = h.dataset.acc === name;
                const chev = h.querySelector('.acc-chev');
                if (chev) chev.style.transform = isOpen ? 'rotate(180deg)' : '';
            });
            try { if (typeof saveUiStateLight === 'function') saveUiStateLight(); } catch (e) {}
        }
        document.querySelectorAll('#settingsAccordion .acc-head').forEach(h => {
            h.addEventListener('click', () => {
                const name = h.dataset.acc;
                setAccOpen(window.__accOpenName === name ? null : name);
            });
        });

        topSettingsBtn.addEventListener('click', () => {
            globalApiKeyInput.value = tmdbApiKey;
            globalSettingsModal.classList.remove('hidden');
            globalSettingsModal.classList.add('flex');
            setAccOpen('export');
            // الحساب السحابي مثبّت بالأعلى: حمّل مكتبة Puter كسلاً وحدّث الحالة
            try { puterRefreshState(); } catch (e) {}
        });

        closeGlobalSettingsModal.addEventListener('click', () => {
            globalSettingsModal.classList.add('hidden');
            globalSettingsModal.classList.remove('flex');
        });

        // إغلاق الإعدادات بالضغط على الخلفية (خارج الصندوق)
        globalSettingsModal.addEventListener('click', (e) => {
            if (e.target === globalSettingsModal) {
                globalSettingsModal.classList.add('hidden');
                globalSettingsModal.classList.remove('flex');
            }
        });

        saveGlobalApiKeyBtn.addEventListener('click', () => {
            const val = globalApiKeyInput.value.trim();
            tmdbApiKey = val;
            if (val) {
                localStorage.setItem(TMDB_KEY_STORAGE, val);
                showStatus(tLang('tKeySaved'), "success");
            } else {
                localStorage.removeItem(TMDB_KEY_STORAGE);
                showStatus(tLang('tKeyCleared'), "info");
            }
            try { if (typeof saveUiStateLight === 'function') saveUiStateLight(); } catch (e) {}
        });

        exportAllM3u8Btn.addEventListener('click', () => {
            if (parsedItems.length === 0) {
                showStatus(tLang('tNoExport'), "error");
                return;
            }
            exportAllDataToM3U8();
            globalSettingsModal.classList.add('hidden');
            globalSettingsModal.classList.remove('flex');
        });

