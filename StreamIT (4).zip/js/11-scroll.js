        // ===== سلوك السكرول: بلا إخفاء للجزء العلوي — البحث والتابات الثلاث لاصقة دائماً =====
        // (ميزة الطي/الأنيميشن والسحب أُزيلت نهائياً حسب الطلب؛ العلوي ثابت ظاهر،
        // والقائمة وحدها تتحرك. زر الصعود العائم يبقى متاحاً للقوائم الطويلة.)
        // ===== طبقة احتواء قوائم الديالوغات: كل قائمة داخل لاير لا يخرج من إطار موداله =====
        // تُطبق ككلاس + سقف ارتفاع مضمّن (يغلب أي max-h من Tailwind) على حاويات القوائم،
        // مع سقف لهيكلي الإعدادات والتفاصيل اللذين بلا سقف أصلاً. بلا أي تعديل على الماركب.
        function initDlgLayers() {
            try {
                const caps = { importAccordion: '50vh', settingsAccordion: '60vh', updateLinksList: '38vh', searchResultsList: '30vh' };
                Object.keys(caps).forEach(function (id) {
                    const el = document.getElementById(id);
                    if (!el) return;
                    try { el.classList.add('dlg-layer'); } catch (e) {}
                    try { el.style.maxHeight = caps[id]; } catch (e) {}
                    try { el.style.minHeight = '0'; } catch (e) {}
                });
                ['globalSettingsModal', 'viewDetailsModal'].forEach(function (mid) {
                    const m = document.getElementById(mid);
                    if (!m || !m.firstElementChild) return;
                    const shell = m.firstElementChild;
                    try {
                        if (!shell.style.maxHeight) shell.style.maxHeight = '92vh';
                        shell.style.minHeight = '0';
                        shell.style.overflowY = 'auto';
                    } catch (e) {}
                });
            } catch (e) {}
        }
        function syncToTopBtn() {
            try {
                var _ls = document.getElementById('listScroll');
                const b = document.getElementById('toTopBtn');
                if (b && _ls) b.style.display = (_ls.scrollTop > 1200) ? 'flex' : 'none';
            } catch (e) {}
        }
        (function initListScrollWiring() {
            var ls = null;
            try { ls = document.getElementById('listScroll'); } catch (e) {}
            if (!ls) return;
            var rafPend = false;
            var vlSettleTimer = null;
            ls.addEventListener('scroll', function () {
                try { if (typeof closeAllMenus === 'function') closeAllMenus(); } catch (e) {}
                try {
                    // إلغاء تحميل الصور المعلقة عند الابتعاد ≥5 عناصر قبل الاستقرار
                    try {
                        if (typeof VL !== 'undefined' && VL && VL.center >= 0) {
                            var avg = (VL.avgH && VL.avgH > 0) ? VL.avgH : 170;
                            var vh = ls.clientHeight || 700;
                            var est = Math.floor((ls.scrollTop + vh / 2) / avg);
                            if (Math.abs(est - VL.center) >= (VL.MOVE_CANCEL || 5)) {
                                VL.imgGen++;
                                if (typeof vlAbortPendingImages === 'function') vlAbortPendingImages();
                                VL.center = est;
                            }
                        }
                    } catch (e) {}
                    clearTimeout(vlSettleTimer);
                    vlSettleTimer = setTimeout(function () {
                        try { if (typeof renderListWindow === 'function') renderListWindow(true); } catch (e) {}
                        try { syncToTopBtn(); } catch (e) {}
                    }, 500);
                } catch (e) {}
                if (rafPend) return;
                rafPend = true;
                requestAnimationFrame(function () {
                    rafPend = false;
                    try { syncToTopBtn(); } catch (e) {}
                    try { if (typeof saveUiStateLight === 'function') saveUiStateLight(); } catch (e) {}
                });
            }, { passive: true });
            try {
                const tb = document.getElementById('toTopBtn');
                if (tb) tb.addEventListener('click', function () {
                    try { ls.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) { try { ls.scrollTop = 0; } catch (e2) {} }
                });
            } catch (e) {}
        })();
        (function initModalLock() {
            const IDS = ['globalSettingsModal','viewDetailsModal','playerModal','videoPlayerModal','importSelectModal','metadataModal','updateLinksModal','stremioSugModal'];
            function anyOpen() {
                return IDS.some(id => {
                    const el = document.getElementById(id);
                    return el && !el.classList.contains('hidden') && el.classList.contains('flex');
                });
            }
            function apply() {
                let open = false;
                try { open = anyOpen(); } catch (e) {}
                try {
                    document.body.classList.toggle('modal-locked', open);
                    document.documentElement.classList.toggle('modal-locked', open);
                    const ls = document.getElementById('listScroll');
                    if (ls) ls.classList.toggle('modal-locked', open);
                    const col = document.getElementById('appColumn');
                    if (col) { try { col.inert = open; } catch (ee) {} }
                    const tg = document.getElementById('topSettingsBtn');
                    if (tg) { try { tg.inert = open; } catch (ee) {} }
                    if (open) { try { closeAllMenus(); } catch (ee) {} }
                } catch (e) {}
            }
            try { window.__updateModalLock = apply; } catch (e) {}
            try {
                const obs = new MutationObserver(() => apply());
                IDS.forEach(id => {
                    const el = document.getElementById(id);
                    if (el) obs.observe(el, { attributes: true, attributeFilter: ['class'] });
                });
            } catch (e) {}
            try { setTimeout(apply, 500); } catch (e) {}
            apply();
        })();
        try {
            const _at = document.getElementById('autoDocToggle');
            if (_at) {
                try { _at.checked = !!autoDocOn; } catch (e) {}
                _at.addEventListener('change', function() { try { setAutoDocOn(_at.checked); } catch (e) {} try { refreshApp(); } catch (e2) {} });
            }
            try {
                const _dt = document.getElementById('impDurToggle');
                if (_dt) {
                    try { _dt.checked = (typeof isImpDurOn === 'function') ? !!isImpDurOn() : true; } catch (e) {}
                    _dt.addEventListener('change', function() { try { setImpDurOn(_dt.checked); } catch (e) {} });
                }
                const _pt = document.getElementById('impPlToggle');
                if (_pt) {
                    try { _pt.checked = (typeof isImpPlOn === 'function') ? !!isImpPlOn() : false; } catch (e) {}
                    _pt.addEventListener('change', function() { try { setImpPlOn(_pt.checked); } catch (e) {} });
                }
                const _sa = document.getElementById('smartAliveToggle');
                if (_sa) {
                    try { _sa.checked = (typeof isSmartAliveOn === 'function') ? !!isSmartAliveOn() : true; } catch (e) {}
                    _sa.addEventListener('change', function() { try { setSmartAliveOn(_sa.checked); } catch (e) {} });
                }
                const _sk = document.getElementById('smartKindToggle');
                if (_sk) {
                    try { _sk.checked = (typeof isSmartKindOn === 'function') ? !!isSmartKindOn() : true; } catch (e) {}
                    _sk.addEventListener('change', function() { try { setSmartKindOn(_sk.checked); } catch (e) {} });
                }
            } catch (e) {}
        } catch (e) {}
        // ===== بدء التشغيل الأول: بعد اكتمال تحميل كل ملفات js (ترتيب آمن بدل الرفع المشترك) =====
        try { initDlgLayers(); } catch (e) {}
        try { if (typeof stremioInit === 'function') stremioInit(); } catch (e) {}
        try { parsedItems = loadSavedItems(); } catch (e) { try { parsedItems = []; } catch (e2) {} }
        try { if (typeof refreshApp === 'function') refreshApp(); } catch (e) {}
        window.__appBooted = true;
        // ===== تأكيد الخروج: الصفحة طبقة واحدة وأي رجوع صغير قد يغلقها بالغلط =====
        // (1) beforeunload للتحذير الأصلي عند الإغلاق/التحديث، (2) مصيدة زر الرجوع
        // بحوار تأكيد داخل التطبيق (البقاء/مغادرة)
        try {
            window.__allowExit = false;
            window.addEventListener('beforeunload', (e) => {
                if (window.__allowExit) return;
                try { e.preventDefault(); } catch (e2) {}
                try { e.returnValue = ''; } catch (e3) {}
            });
        } catch (e) {}
        try {
            if (window.history && history.pushState) {
                try { history.pushState({ streamitGuard: 1 }, ''); } catch (e) {}
                let __exitModal = null;
                const closeExitModal = () => { try { if (__exitModal) __exitModal.remove(); } catch (e) {} __exitModal = null; };
                window.addEventListener('popstate', () => {
                    if (window.__allowExit) return;
                    try { history.pushState({ streamitGuard: 1 }, ''); } catch (e) {}
                    closeExitModal();
                    try {
                        const ov = document.createElement('div');
                        ov.className = 'fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4';
                        ov.style.zIndex = '100';
                        const t = (typeof tLang === 'function') ? tLang : ((k) => k);
                        ov.innerHTML = '<div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-xs w-full p-5 flex flex-col gap-3 text-right shadow-2xl">'
                            + '<h3 class="text-sm font-extrabold text-slate-100">' + t('exitTitle') + '</h3>'
                            + '<p class="text-xs text-slate-400 leading-relaxed">' + t('exitMsg') + '</p>'
                            + '<div class="flex items-center justify-end gap-2 pt-1">'
                            + '<button data-exit="stay" class="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-4 py-2 rounded-xl font-bold transition cursor-pointer">' + t('exitStay') + '</button>'
                            + '<button data-exit="leave" class="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs px-4 py-2 rounded-xl font-bold transition cursor-pointer">' + t('exitLeave') + '</button>'
                            + '</div></div>';
                        ov.addEventListener('click', (ev) => {
                            const b = ev.target.closest ? ev.target.closest('[data-exit]') : null;
                            if (!b && ev.target !== ov) return;
                            const act = b ? b.getAttribute('data-exit') : 'stay';
                            closeExitModal();
                            if (act === 'leave') { try { window.__allowExit = true; history.back(); } catch (e) {} }
                        });
                        document.body.appendChild(ov);
                        __exitModal = ov;
                    } catch (e) {}
                });
            }
        } catch (e) {}
