        // ===== إضافات Stremio: بحث + روابط (اقتراحات فقط — لا تمس المكتبة أبداً) =====
        // بروتوكول Stremio القياسي بلا أي تخصيص لرابط: manifest.json ← catalog/search
        // ← meta ← stream. عناوين stremio:// تُحوَّل إلى https://. الاقتراحات كائنات
        // منفصلة كلياً عن parsedItems/pendingRawItems فلا تراها أدوات التوثيق.
        const STREMIO_DEFAULTS = [
            'https://v3-cinemeta.strem.io/manifest.json',
            'https://torrentio.strem.fun/sort=seeders|language=arabic|qualityfilter=brremux,dolbyvision,hdrall,dolbyvisionwithhdr,threed,4k,scr,cam|sizefilter=1550mb/manifest.json',
            'https://torrentsdb.com/eyJzb3J0Ijoic2VlZGVycyIsImxhbmd1YWdlIjpbImFyYWJpYyJdLCJxdWFsaXR5ZmlsdGVyIjpbImNhbSIsInNjciIsImJycmVtdXgiLCJoZHJhbGwiLCJkb2xieXZpc2lvbiIsImRvbGJ5dmlzaW9ud2l0aGhkciIsIjRrIl0sInNpemVmaWx0ZXIiOiIxNTUwIn0=/manifest.json'
        ];
        var stremioAddons = []; // [{base, enabled}]
        var stremioManifestCache = {}; // base -> manifest
        var stremioSug = []; // اقتراحات البحث الحالي
        var stremioSearchToken = 0;
        var stremioActiveQ = null;
        var stremioDebT = 0;
        var stremioDlgState = null; // {key} حوار الاقتراح المفتوح
        function stremioBaseOf(u) {
            try {
                let s = String(u || '').trim().replace(/^stremio:\/\//i, 'https://');
                s = s.replace(/\/+$/, '').replace(/\/manifest\.json$/i, '').replace(/\/+$/, '');
                if (!/^https?:\/\//i.test(s)) return '';
                return s;
            } catch (e) { return ''; }
        }
        function stremioHost(base) {
            try { return new URL(base).host; } catch (e) { return String(base || '').slice(0, 40); }
        }
        async function stremioGet(url, ms) {
            const ctrl = new AbortController();
            const to = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, ms || 10000);
            try {
                const r = await fetch(url, { signal: ctrl.signal });
                if (!r || !r.ok) throw new Error('http ' + (r && r.status));
                return await r.json();
            } finally { try { clearTimeout(to); } catch (e) {} }
        }
        function stremioLoadAddons() {
            try {
                const raw = localStorage.getItem('streamit_stremio_addons_v1');
                if (raw !== null) {
                    try {
                        const a = JSON.parse(raw);
                        if (Array.isArray(a)) {
                            stremioAddons = a.filter(x => x && x.base).map(x => ({ base: String(x.base), enabled: x.enabled !== false }));
                            return;
                        }
                    } catch (e) {}
                }
            } catch (e) {}
            stremioAddons = STREMIO_DEFAULTS.map(b => ({ base: stremioBaseOf(b), enabled: true }));
            try { localStorage.setItem('streamit_stremio_addons_v1', JSON.stringify(stremioAddons)); } catch (e) {}
        }
        function stremioSaveAddons() {
            try { localStorage.setItem('streamit_stremio_addons_v1', JSON.stringify(stremioAddons)); } catch (e) {}
            try { saveItemsToStorage(); } catch (e) {}
        }
        async function stremioManifest(addon) {
            try {
                if (stremioManifestCache[addon.base]) return stremioManifestCache[addon.base];
                const m = await stremioGet(addon.base + '/manifest.json', 12000);
                if (m && (m.resources || m.catalogs)) {
                    stremioManifestCache[addon.base] = m;
                    return m;
                }
            } catch (e) {}
            return null;
        }
        function stremioRoles(m) {
            const r = { catalog: false, meta: false, stream: false, searchCatalogs: [] };
            try {
                (m.resources || []).forEach(x => {
                    const n = (typeof x === 'string') ? x : (x && x.name);
                    if (n === 'catalog') r.catalog = true;
                    if (n === 'meta') r.meta = true;
                    if (n === 'stream') r.stream = true;
                });
                (m.catalogs || []).forEach(c => {
                    const sup = c.extraSupported || [];
                    const ex = (c.extra || []).map(e => (typeof e === 'string') ? e : (e && e.name));
                    if (sup.indexOf('search') >= 0 || ex.indexOf('search') >= 0) r.searchCatalogs.push(c);
                });
            } catch (e) {}
            return r;
        }
        function stremioSupportsId(m, type, id) {
            try {
                const types = m.types || [];
                if (types.length && types.indexOf(type) < 0) return false;
                const res = m.resources || [];
                for (const x of res) {
                    if (!x || typeof x === 'string') continue;
                    if (x.name === 'stream') {
                        if (x.types && x.types.indexOf(type) < 0) return false;
                        if (x.idPrefixes && x.idPrefixes.length) {
                            if (!x.idPrefixes.some(p => String(id).indexOf(p) === 0)) return false;
                        }
                        return true;
                    }
                }
                if (res.indexOf('stream') >= 0) return true;
            } catch (e) {}
            return false;
        }
        function stremioNormMeta(mt, forceType) {
            try {
                return {
                    type: mt.type || forceType || 'movie',
                    id: String(mt.id || ''),
                    name: String(mt.name || ''),
                    year: String(mt.year || mt.releaseInfo || '').slice(0, 4),
                    poster: String(mt.poster || ''),
                    _meta: mt
                };
            } catch (e) { return null; }
        }
        function stremioOnQuery() {
            try { clearTimeout(stremioDebT); } catch (e) {}
            stremioDebT = setTimeout(() => {
                try {
                    const inp = document.getElementById('listSearchInput');
                    const q = inp ? inp.value.trim() : '';
                    if (!q || q.length < 2 || (typeof navState !== 'undefined' && navState.level !== 1)) return;
                    try { if (typeof currentFilter !== 'undefined' && currentFilter === 'live') { stremioClearBox(); return; } } catch (e) {}
                    runStremioSearch(q);
                } catch (e) {}
            }, 500);
        }
        function stremioClearBox() {
            try { stremioSearchToken++; } catch (e) {}
            stremioActiveQ = null;
            stremioSug = [];
            try { const b = document.getElementById('stremioSugBox'); if (b) { b.classList.add('hidden'); b.classList.remove('flex'); b.innerHTML = ''; b.dataset.q = ''; } } catch (e) {}
        }
        function stremioSyncBox() {
            // تُستدعى بعد كل refreshApp: إخفاء عند عدم الصلاحية، وإلا إظهار
            // الموجود أو إطلاق بحث (مزاح 500ms) عند الحاجة.
            try {
                const box = document.getElementById('stremioSugBox');
                if (!box) return;
                const inp = document.getElementById('listSearchInput');
                const q = inp ? inp.value.trim() : '';
                if (!q || q.length < 2 || (typeof navState !== 'undefined' && navState.level !== 1)) { stremioClearBox(); return; }
                if (box.dataset.q === q && box.innerHTML) { box.classList.remove('hidden'); box.classList.add('flex'); return; }
                if (stremioActiveQ !== q) stremioOnQuery();
                else if (box.innerHTML) { box.classList.remove('hidden'); box.classList.add('flex'); }
            } catch (e) {}
        }
        function stremioSugKey(s) { return s.type + ':' + s.id; }
        function stremioPaintBox(q, loading, hint) {
            try {
                const box = document.getElementById('stremioSugBox');
                if (!box) return;
                box.dataset.q = q;
                box.classList.remove('hidden');
                box.classList.add('flex');
                let h = '<div class="bg-slate-950 border border-sky-900/60 rounded-xl px-3 py-2.5 flex flex-col gap-1">'
                    + '<div class="text-xs font-extrabold text-sky-300 flex items-center gap-1.5"><i class="fa-solid fa-lightbulb"></i> ' + tLang('stremioSugTitle') + '</div>'
                    + '<div class="text-[10px] text-slate-500">' + tLang('stremioSugSub') + '</div></div>'
                    + '<div id="stremioSugRows" class="flex flex-col gap-2"></div>';
                if (loading) h += '<div id="stremioSugLoading" class="text-center py-3 text-slate-400 text-xs flex items-center justify-center gap-2"><i class="fa-solid fa-spinner fa-spin text-sky-400"></i> ' + tLang('stremioSugLoading') + '</div>';
                if (hint) h += '<div class="text-center py-2 text-amber-300/90 text-[11px]">' + hint + '</div>';
                box.innerHTML = h;
            } catch (e) {}
        }
        function stremioAddRow(s) {
            try {
                const rows = document.getElementById('stremioSugRows');
                if (!rows) return;
                const r = document.createElement('div');
                r.className = 'flex items-center gap-2.5 px-2.5 py-2 bg-slate-900 border border-sky-900/50 rounded-xl cursor-pointer hover:border-sky-500/50 transition text-right';
                r.setAttribute('data-stremio-sug', stremioSugKey(s));
                const badge = s.type === 'series' ? tLang('tabTv') : tLang('tabMovie');
                r.innerHTML = (s.poster ? '<img src="' + s.poster.replace(/"/g, '&quot;') + '" loading="lazy" class="w-10 h-14 object-cover rounded-lg bg-slate-950 flex-shrink-0" alt="">' : '<div class="w-10 h-14 rounded-lg bg-slate-950 flex items-center justify-center flex-shrink-0 text-slate-600"><i class="fa-solid fa-film"></i></div>')
                    + '<div class="flex-1 min-w-0"><div class="text-xs font-bold text-slate-100 truncate">' + escImp(s.name) + '</div>'
                    + '<div class="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5"><span>' + escImp(s.year || '') + '</span><span class="px-1.5 py-px rounded bg-sky-950 text-sky-300 border border-sky-800/80 font-bold">' + badge + '</span>'
                    + '<span class="text-emerald-300 font-bold">🔗 ' + s.streams.length + ' ' + tLang('stremioSrc') + '</span></div></div>'
                    + '<span class="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80 flex-shrink-0">' + tLang('stremioSugBadge') + '</span>';
                r.addEventListener('click', (e) => { try { e.stopPropagation(); } catch (x) {} try { openStremioSug(stremioSugKey(s)); } catch (x) {} });
                rows.appendChild(r);
                try {
                    // شارات الإضافات الموفرة لهذا العنصر
                    const ab = document.createElement('div');
                    ab.className = 'flex items-center gap-1 px-2.5 -mt-1 flex-wrap';
                    (s._addons || []).slice(0, 3).forEach(nm => {
                        const b = document.createElement('span');
                        b.className = 'text-[8px] font-bold px-1.5 py-px rounded bg-violet-950 text-violet-300 border border-violet-800/80 max-w-[110px] truncate';
                        b.setAttribute('dir', 'ltr');
                        b.textContent = nm;
                        ab.appendChild(b);
                    });
                    if ((s._addons || []).length > 3) {
                        const m = document.createElement('span');
                        m.className = 'text-[8px] text-slate-500';
                        m.textContent = '+' + (s._addons.length - 3);
                        ab.appendChild(m);
                    }
                    if ((s._addons || []).length) rows.appendChild(ab);
                } catch (e) {}
            } catch (e) {}
        }
        function stremioNormText(x) {
            try { return String(x || '').toLowerCase().replace(/[''"\u2018\u2019\u201c\u201d]/g, '').replace(/[^a-z0-9\u0600-\u06ff\u4e00-\u9fff ]+/g, ' ').replace(/\s+/g, ' ').trim(); } catch (e) { return ''; }
        }
        function stremioStrictFilter(cands, q) {
            // ترشيح صارم ضد النتائج الغريبة: كل رموز البحث حاضرة، والأقل كلمات دخيلة أولاً
            try {
                const qn = stremioNormText(q);
                let toks = qn.split(' ').filter(t => t && (t.length >= 2 || /[\u0600-\u06ff\u4e00-\u9fff]/.test(t)));
                toks = toks.filter(t => !/^(19|20)\d{2}$/.test(t));
                if (!toks.length) toks = qn.split(' ').filter(Boolean);
                if (!toks.length) return cands || [];
                const qYear = (String(q).match(/(19|20)\d{2}/) || [])[0] || '';
                const scored = (cands || []).map(c => {
                    const cn = stremioNormText(c.name);
                    const cw = cn.split(' ').filter(Boolean);
                    const cset = {};
                    cw.forEach(w => { cset[w] = 1; });
                    let hit = 0;
                    toks.forEach(t => { if (cset[t] || cn.indexOf(t) >= 0) hit++; });
                    const extra = cw.filter(w => toks.indexOf(w) < 0).length;
                    return { c, hit, extra, exact: cn.indexOf(qn) >= 0, sameYear: !!(qYear && String(c.year || '') === qYear) };
                });
                let tier = scored.filter(x => x.hit === toks.length && x.extra <= Math.max(2, toks.length));
                if (!tier.length) tier = scored.filter(x => x.hit >= Math.max(1, Math.ceil(toks.length / 2)) && x.extra <= 8);
                tier.sort((a, b) => {
                    const d = ((b.sameYear ? 1 : 0) - (a.sameYear ? 1 : 0)) || ((b.exact ? 1 : 0) - (a.exact ? 1 : 0)) || (a.extra - b.extra);
                    if (d) return d;
                    return ((b.c.streams || []).length) - ((a.c.streams || []).length);
                });
                return tier.map(x => x.c);
            } catch (e) { return cands || []; }
        }
        var STREMIO_Q_ORDER = ['4K', '1080p', '720p', 'SD', 'CAM', 'OTHER'];
        function stremioQualityOf(st) {
            // تصنيف جودة العرض من الاسم الكامل: 4K / 1080p / 720p / SD / CAM / أخرى
            try {
                const t = ' ' + ((st.full || '') + ' ' + (st.label || '') + ' ' + (st.sub || '')).toLowerCase().replace(/[._\-+|/()[\]]+/g, ' ').replace(/\s+/g, ' ') + ' ';
                const has = (re) => re.test(t);
                let res = '';
                if (has(/ 2160 ?p | 4k | uhd /)) res = '4K';
                else if (has(/ 1080 ?p | 1080 /)) res = '1080p';
                else if (has(/ 720 ?p | 720 /)) res = '720p';
                else if (has(/ 480 ?p | 576 ?p | dvd | dvdrip | hdtv /)) res = 'SD';
                if (has(/cam|hdcam|hdts|hd ts|telesync|tsrip|screener|dvdscr|telecine|\bts\b|\br5\b|\bscr\b/)) {
                    if (res !== '4K' && res !== '1080p' && res !== '720p') return 'CAM';
                }
                if (has(/ xvid | divx | dvdrip | dvdscr | hdrip | bdrip | brrip | webrip | web dlrip | web dl | hdtv | tvrip | pdtv | sdtv | vhsrip | vhs /)) return 'SD';
                return res || 'OTHER';
            } catch (e) { return 'OTHER'; }
        }
        function stremioQName(q) { try { return q === 'OTHER' ? tLang('stremioQOther') : q; } catch (e) { return q; } }
        function stremioSeedN(st) { const n = st ? +st.seeders : NaN; return isNaN(n) ? -1 : n; }
        function stremioGroupStreams(streams) {
            // كل الروابط ظاهرة بحرية، مرتبة بالأعلى seeders أولاً (بلا عدّاد معلن في الآخر)، وسقف 50 لكل جودة
            const g = { '4K': [], '1080p': [], '720p': [], 'SD': [], 'CAM': [], 'OTHER': [] };
            (streams || []).forEach(st => { try { if (st) g[stremioQualityOf(st)].push(st); } catch (e) {} });
            return STREMIO_Q_ORDER.map(q => {
                const items = g[q].sort((a, b) => stremioSeedN(b) - stremioSeedN(a)).slice(0, 50);
                return { q, items };
            }).filter(x => x.items.length);
        }
        function stremioTitleTokens(s) {
            try { return stremioNormText(s.name).split(' ').filter(t => t.length >= 3); } catch (e) { return []; }
        }
        function stremioMovieRelevant(out, cand) {
            // إسقاط روابط لا تعود للفيلم (اسم الإصدار بلا أي رمز من عنوانه ولا سنته)
            try {
                const toks = stremioTitleTokens(cand);
                if (!toks.length || !out.length) return out;
                const yr = String(cand.year || '');
                const f = out.filter(st => {
                    const t = stremioNormText((st.full || '') + ' ' + (st.label || ''));
                    if (toks.some(tk => t.indexOf(tk) >= 0)) return true;
                    return !!(yr.length === 4 && t.indexOf(yr) >= 0);
                });
                return f.length ? f : out;
            } catch (e) { return out; }
        }
        function stremioRelevantStreams(streams, s, ep) {
            // إسقاط روابط حلقة أخرى تسربت (رمز SxxExx مختلف)، مع إبقاء الحزم الشاملة بلا رمز
            try {
                if (!ep || !s || s.type !== 'series') return streams || [];
                const S = +ep.season, E = +ep.episode;
                return (streams || []).filter(st => {
                    const t = ' ' + ((st.full || '') + ' ' + (st.label || '')).toLowerCase().replace(/[._\-]+/g, ' ') + ' ';
                    const codes = t.match(/s(\d{1,2})\s?e(\d{1,3})/g) || [];
                    if (!codes.length) return true;
                    return codes.some(c => { const m = c.match(/s(\d{1,2})\s?e(\d{1,3})/); return m && +m[1] === S && +m[2] === E; });
                });
            } catch (e) { return streams || []; }
        }
        async function stremioEpStreams(s, ep, provs) {
            try {
                s._epCache = s._epCache || {};
                const code = 'S' + String(ep.season).padStart(2, '0') + 'E' + String(ep.episode).padStart(2, '0');
                if (s._epCache[code]) return s._epCache[code];
                const p = provs || await stremioLiveProviders();
                const raw = await stremioStreamsFor(s, { season: ep.season, episode: ep.episode }, p.streamers, p.metaProviders);
                const rel = stremioRelevantStreams(raw, s, ep);
                s._epCache[code] = rel;
                return rel;
            } catch (e) { return []; }
        }
        function stremioFolderEl(titleHtml, subHtml, fill) {
            // مجلد قابل للطي/الفتح، يُبنى محتواه كسلاً عند أول فتح (fill قد تكون async)
            const box = document.createElement('div');
            box.className = 'bg-slate-900 border border-slate-800 rounded-lg overflow-hidden shrink-0';
            const h = document.createElement('button');
            h.className = 'w-full px-2.5 py-2 flex items-center justify-between gap-2 cursor-pointer';
            h.innerHTML = '<span class="text-xs font-bold text-slate-200 text-right">' + titleHtml + (subHtml ? ' <span class="text-slate-500 font-normal">' + subHtml + '</span>' : '') + '</span><i class="fa-solid fa-chevron-down text-slate-500 text-[10px] flex-shrink-0"></i>';
            const ctn = document.createElement('div');
            ctn.className = 'hidden px-2 pb-2 flex-col gap-1';
            let loaded = false;
            h.addEventListener('click', async () => {
                const open = ctn.classList.contains('hidden');
                ctn.classList.toggle('hidden');
                ctn.classList.toggle('flex', open);
                if (open && !loaded) {
                    loaded = true;
                    ctn.innerHTML = '';
                    ctn.appendChild(stremioLoadingRow());
                    try {
                        await fill(ctn);
                    } catch (e) {
                        try { ctn.innerHTML = '<div class="text-center py-2 text-slate-500 text-[11px]">' + tLang('stremioNoStreams') + '</div>'; } catch (e2) {}
                    }
                }
            });
            box.appendChild(h);
            box.appendChild(ctn);
            return { box, ctn };
        }
        function stremioQFolderBox(g) {
            const f = stremioFolderEl(escImp(stremioQName(g.q)), '(' + g.items.length + ' ' + tLang('stremioSrc') + ')', (ctn) => {
                ctn.innerHTML = '';
                g.items.forEach(st => ctn.appendChild(stremioStreamRow(st)));
            });
            return f.box;
        }
        var STREMIO_SERVICES = [
            { name: 'ZbigZ', url: 'https://zbigz.com/', feat: 'stremioFeatZ' },
            { name: 'WebTor', url: 'https://webtor.io/', feat: 'stremioFeatW' },
            { name: 'Seedr', url: 'https://www.seedr.cc/', feat: 'stremioFeatS' }
        ];
        function stremioOpenLink(st) {
            // ديالوغ الرابط: نسخه + 3 منصات مجانية للتحميل (النقر على المنصة ينسخ ثم يفتحها)
            try {
                const old = document.getElementById('stremioLinkDlg');
                if (old) old.remove();
                const isMag = /^magnet:/i.test(st.link || '');
                const ov = document.createElement('div');
                ov.id = 'stremioLinkDlg';
                ov.className = 'fixed inset-0 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4';
                ov.style.zIndex = '120';
                let cards = '';
                STREMIO_SERVICES.forEach((sv, i) => {
                    const feats = String(tLang(sv.feat) || '').split('|').map(f => f.trim()).filter(Boolean);
                    cards += '<div class="bg-slate-950 border border-slate-800 rounded-xl p-3 flex flex-col gap-1.5">'
                        + '<div class="flex items-center justify-between gap-2"><span class="text-xs font-extrabold text-sky-300" dir="ltr">' + escImp(sv.name) + '</span>'
                        + '<a data-svc="' + i + '" href="' + escImp(sv.url) + '" target="_blank" rel="noopener" class="bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] px-3 py-1.5 rounded-lg font-bold cursor-pointer flex-shrink-0">' + tLang('stremioOpenSite') + '</a></div>'
                        + '<ul class="flex flex-col gap-0.5">' + feats.map(f => '<li class="text-[10px] text-slate-400">• ' + escImp(f) + '</li>').join('') + '</ul></div>';
                });
                ov.innerHTML = '<div class="bg-slate-900 border border-sky-900/60 rounded-2xl max-w-md w-full p-4 flex flex-col gap-3 text-right max-h-[85vh] overflow-y-auto">'
                    + '<div class="flex items-center justify-between gap-2"><span class="text-xs font-extrabold text-slate-100">' + tLang('stremioLinkTitle') + '</span>'
                    + '<span class="text-[9px] font-bold px-1.5 py-0.5 rounded ' + (isMag ? 'bg-purple-950 text-purple-300 border border-purple-800/80' : 'bg-sky-950 text-sky-300 border border-sky-800/80') + '">' + (isMag ? tLang('stremioIsMagnet') : tLang('stremioIsDirect')) + '</span></div>'
                    + '<div class="text-[11px] text-slate-300 font-bold truncate">' + escImp(st.label || '') + '</div>'
                    + '<div class="flex gap-2"><input id="stremioLinkInput" type="text" readonly dir="ltr" class="flex-1 min-w-0 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-[11px] text-slate-200 focus:outline-none">'
                    + '<button id="stremioLinkCopy" class="bg-sky-700 hover:bg-sky-600 text-white text-[11px] px-3 py-2 rounded-xl font-bold cursor-pointer flex-shrink-0">' + tLang('stremioCopyBtn') + '</button></div>'
                    + '<div class="text-[10px] text-slate-500">' + tLang('stremioSvcHint') + '</div>'
                    + cards
                    + '<button id="stremioLinkClose" class="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-2 rounded-xl font-bold cursor-pointer">' + tLang('stremioBack') + '</button></div>';
                document.body.appendChild(ov);
                const inp = document.getElementById('stremioLinkInput');
                if (inp) {
                    inp.value = st.link || '';
                    inp.addEventListener('click', () => { try { inp.select(); } catch (e) {} });
                }
                const cp = document.getElementById('stremioLinkCopy');
                if (cp) cp.addEventListener('click', () => { stremioCopyLink(st.link || ''); });
                ov.querySelectorAll('[data-svc]').forEach(b => b.addEventListener('click', () => {
                    // الرابط <a target=_blank> يفتح المنصة بتبويب جديد، وهنا ننسخ رابط العنصر تلقائياً
                    try { stremioCopyLink(st.link || ''); } catch (e) {}
                }));
                const cb = document.getElementById('stremioLinkClose');
                if (cb) cb.addEventListener('click', () => { try { ov.remove(); } catch (e) {} });
                ov.addEventListener('click', (e) => { if (e.target === ov) { try { ov.remove(); } catch (e2) {} } });
            } catch (e) {}
        }
        async function runStremioSearch(q) {
            const token = ++stremioSearchToken;
            stremioActiveQ = q;
            stremioSug = [];
            // فلترة حسب تبويب المكتبة: مسلسلات ← مسلسلات فقط، أفلام ← أفلام فقط، مباشر ← بلا اقتراحات
            let wantStremio = '';
            try {
                const cf = (typeof currentFilter !== 'undefined') ? currentFilter : '';
                if (cf === 'live') { stremioClearBox(); stremioActiveQ = null; return; }
                wantStremio = cf === 'tv' ? 'series' : (cf === 'movie' ? 'movie' : '');
            } catch (e) {}
            if (!stremioAddons.length) { try { stremioLoadAddons(); } catch (e) {} }
            stremioPaintBox(q, true, '');
            const enabled = stremioAddons.filter(a => a && a.enabled && stremioBaseOf(a.base));
            if (!enabled.length) {
                if (token === stremioSearchToken) stremioPaintBox(q, false, tLang('stremioNoRes'));
                stremioActiveQ = null;
                return;
            }
            let mans = [];
            try { mans = await Promise.all(enabled.map(async a => ({ a, m: await stremioManifest(a) }))); } catch (e) {}
            if (token !== stremioSearchToken) return;
            const roles = mans.filter(x => x.m).map(x => ({ a: x.a, m: x.m, r: stremioRoles(x.m) }));
            if (!roles.length) {
                if (token === stremioSearchToken) stremioPaintBox(q, false, tLang('stremioNoRes'));
                stremioActiveQ = null;
                return;
            }
            const metas = new Map();
            const searchers = roles.filter(x => x.r.searchCatalogs.length);
            const ql = q.toLowerCase();
            if (!searchers.length) {
                // بلا فهارس بحث: ترشيح عميل لفهارس كاملة (احتياطي عام)
                for (const x of roles) {
                    if (!x.r.catalog) continue;
                    for (const c of (x.m.catalogs || []).slice(0, 4)) {
                        if (c.type !== 'movie' && c.type !== 'series') continue;
                    if (wantStremio && c.type !== wantStremio) continue;
                        try {
                            const d = await stremioGet(x.a.base + '/catalog/' + c.type + '/' + c.id + '.json', 10000);
                            (d.metas || []).forEach(mt => {
                                if (metas.size >= 40) return;
                                if (String(mt.name || '').toLowerCase().indexOf(ql) >= 0 && mt.id && !metas.has(mt.id)) {
                                    const n = stremioNormMeta(mt, c.type);
                                    if (n) metas.set(mt.id, n);
                                }
                            });
                        } catch (e) {}
                        if (token !== stremioSearchToken) return;
                    }
                }
            } else {
                const jobs = [];
                searchers.forEach(x => {
                    x.r.searchCatalogs.filter(c => !wantStremio || c.type === wantStremio).slice(0, 4).forEach(c => {
                        jobs.push((async () => {
                            try {
                                const d = await stremioGet(x.a.base + '/catalog/' + c.type + '/' + c.id + '/search=' + encodeURIComponent(q) + '.json', 10000);
                                return (d.metas || []).map(mt => stremioNormMeta(mt, c.type)).filter(Boolean);
                            } catch (e) { return []; }
                        })());
                    });
                });
                let lists = [];
                try { lists = await Promise.all(jobs); } catch (e) {}
                if (token !== stremioSearchToken) return;
                lists.forEach(l => l.forEach(n => { if (metas.size < 40 && n.id && !metas.has(n.id)) metas.set(n.id, n); }));
            }
            // ترشيح صارم للصلة (يسقط الغريبة كمثل Ismo) قبل فحص التوفر
            const rankedAll = stremioStrictFilter([...metas.values()], q);
            const ranked = wantStremio ? rankedAll.filter(c => c.type === wantStremio) : rankedAll;
            if (!ranked.length) {
                if (token === stremioSearchToken) {
                    const needMeta = !roles.some(x => x.r.catalog || x.r.meta);
                    stremioPaintBox(q, false, needMeta ? tLang('stremioNeedMeta') : tLang('stremioNoRes'));
                }
                stremioActiveQ = null;
                return;
            }
            // التحقق من توفر روابط فعلية (أول 10 فقط) + عرض تدريجي
            stremioPaintBox(q, true, '');
            const streamers = roles.filter(x => x.r.stream);
            const metaProviders = roles.filter(x => x.r.meta);
            const cands = ranked.slice(0, 10);
            await Promise.all(cands.map(async (cand) => {
                if (token !== stremioSearchToken) return;
                const streams = await stremioStreamsFor(cand, null, streamers, metaProviders);
                if (token !== stremioSearchToken) return;
                const good = (streams || []).slice().sort((a, b) => stremioSeedN(b) - stremioSeedN(a));
                if (good.length) {
                    cand.streams = good;
                    cand._addons = [...new Set(good.map(s => s.addon))];
                    stremioSug.push(cand);
                    try { stremioAddRow(cand); } catch (e) {}
                }
            }));
            if (token !== stremioSearchToken) return;
            // إزالة مؤشر التحميل وإظهار "لا نتائج" عند الفراغ
            try {
                const box = document.getElementById('stremioSugBox');
                if (box) {
                    const ld = document.getElementById('stremioSugLoading');
                    if (ld) ld.remove();
                    if (!stremioSug.length) stremioPaintBox(q, false, tLang('stremioNoRes'));
                }
            } catch (e) {}
            stremioActiveQ = null;
        }
        async function stremioMetaFor(cand, metaProviders) {
            try {
                if (cand._fullMeta) return cand._fullMeta;
                if (cand._meta && cand._meta.videos) { cand._fullMeta = cand._meta; return cand._fullMeta; }
                for (const x of (metaProviders || [])) {
                    try {
                        const d = await stremioGet(x.a.base + '/meta/' + cand.type + '/' + encodeURIComponent(cand.id) + '.json', 10000);
                        if (d && d.meta) { cand._fullMeta = d.meta; return d.meta; }
                    } catch (e) {}
                }
            } catch (e) {}
            return null;
        }
        // ===== معلومات العنصر عبر إضافات الميتا أولاً (cinemeta وغيرها)، وTMDB احتياط فقط =====
        async function stremioCatalogRoles() {
            // كل الإضافات المفعّلة التي توفر فهارس أو ميتا
            try {
                if (!stremioAddons.length) { try { stremioLoadAddons(); } catch (e) {} }
                const enabled = stremioAddons.filter(a => a && a.enabled && stremioBaseOf(a.base));
                if (!enabled.length) return [];
                let mans = [];
                try { mans = await Promise.all(enabled.map(async a => ({ a, m: await stremioManifest(a) }))); } catch (e) {}
                return mans.filter(x => x.m).map(x => ({ a: x.a, m: x.m, r: stremioRoles(x.m) })).filter(x => x.r.catalog || x.r.meta);
            } catch (e) { return []; }
        }
        function stremioMetaToDoc(md, type) {
            // تحويل ميتا Stremio إلى نفس شكل نتيجة TMDB (متوافق مع renderSearchResults و pickBestAutoDoc)
            try {
                const title = String(md.name || md.title || '').trim();
                if (!title) return null;
                const g = Array.isArray(md.genres) ? md.genres : [];
                let poster = String(md.poster || md.logo || '');
                if (!poster) { try { poster = generateSvgAvatar(title); } catch (e) {} }
                return {
                    id: 'stremio:' + type + ':' + String(md.id || ''),
                    title: title,
                    originalTitle: String(md.originalTitle || ''),
                    year: String(md.releaseInfo || md.year || '').slice(0, 4),
                    poster: poster,
                    backdrop: String(md.background || ''),
                    overview: String(md.description || tLang('noDescItem')),
                    rating: (md.imdbRating != null && String(md.imdbRating) !== '') ? String(md.imdbRating) : 'N/A',
                    genres: g.join((typeof appLang !== 'undefined' && appLang === 'ar') ? '، ' : ', '),
                    status: String(md.status || ''),
                    _src: 'stremio'
                };
            } catch (e) { return null; }
        }
        async function stremioMetaSearch(query, type) {
            // بحث معلومات فيلم/مسلسل عبر إضافات الميتا — تُرجع مرشحين موثقين، أو [] ليعمل TMDB كاحتياط
            const out = [];
            try {
                const q = String(query || '').trim();
                if (!q || q.length < 2) return out;
                const roles = await stremioCatalogRoles();
                if (!roles.length) return out;
                const metas = new Map();
                const ql = q.toLowerCase();
                const searchable = (x, c) => {
                    try { return (x.r.searchCatalogs || []).some(s => s && s.type === c.type && s.id === c.id); } catch (e) { return false; }
                };
                for (const x of roles) {
                    try {
                        const cats = ((x.m && x.m.catalogs) || []).filter(c => c && c.type === type).slice(0, 4);
                        for (const c of cats) {
                            try {
                                if (metas.size >= 30) break;
                                if (searchable(x, c)) {
                                    const d = await stremioGet(x.a.base + '/catalog/' + c.type + '/' + c.id + '/search=' + encodeURIComponent(q) + '.json', 10000);
                                    (d.metas || []).forEach(mt => { if (mt && mt.id && !metas.has(x.a.base + mt.id)) { const n = stremioNormMeta(mt, type); if (n) metas.set(x.a.base + mt.id, n); } });
                                } else {
                                    const d = await stremioGet(x.a.base + '/catalog/' + c.type + '/' + c.id + '.json', 10000);
                                    (d.metas || []).forEach(mt => {
                                        if (metas.size >= 30 || !mt || !mt.id || metas.has(x.a.base + mt.id)) return;
                                        if (String(mt.name || '').toLowerCase().indexOf(ql) >= 0) { const n = stremioNormMeta(mt, type); if (n) metas.set(x.a.base + mt.id, n); }
                                    });
                                }
                            } catch (e) {}
                        }
                    } catch (e) {}
                    if (metas.size >= 30) break;
                }
                if (!metas.size) return out;
                const ranked = stremioStrictFilter([...metas.values()], q).slice(0, 8);
                if (!ranked.length) return out;
                const metaProviders = roles.filter(x => x.r.meta);
                for (const cand of ranked) {
                    try { await stremioMetaFor(cand, metaProviders); } catch (e) {}
                    try {
                        const full = cand._fullMeta || cand._meta || {};
                        const doc = stremioMetaToDoc(Object.assign({}, full, { id: cand.id, name: cand.name, year: cand.year, poster: cand.poster }), type);
                        if (doc) out.push(doc);
                    } catch (e) {}
                }
            } catch (e) {}
            return out;
        }
        function stremioVideosOf(meta) {            try {
                const vs = (meta && meta.videos) || [];
                return vs.filter(v => v && (v.season > 0 || v.episode > 0)).map(v => ({
                    season: +v.season || 0,
                    episode: +v.episode || 0,
                    title: String(v.title || v.name || ''),
                    id: String(v.id || '')
                })).sort((a, b) => (a.season - b.season) || (a.episode - b.episode));
            } catch (e) { return []; }
        }
        async function stremioStreamsFor(cand, ep, streamers, metaProviders) {
            // ep: null للفيلم (ولفحص التوفر للمسلسل تُستخدم الحلقة الأولى) أو {season, episode}
            const out = [];
            try {
                const provs = (streamers && streamers.length ? streamers : []);
                if (!provs.length) return out;
                let sid = cand.id;
                if (cand.type === 'series') {
                    let s = ep && ep.season, e = ep && ep.episode;
                    if (!(s > 0) || !(e > 0)) {
                        const meta = await stremioMetaFor(cand, metaProviders);
                        const vs = stremioVideosOf(meta);
                        if (!vs.length) return out;
                        s = vs[0].season; e = vs[0].episode;
                    }
                    sid = cand.id + ':' + s + ':' + e;
                }
                const jobs = provs.filter(x => { try { return stremioSupportsId(x.m, cand.type, cand.id); } catch (e) { return false; } })
                    .map(async (x) => {
                        try {
                            const d = await stremioGet(x.a.base + '/stream/' + cand.type + '/' + encodeURIComponent(sid) + '.json', 12000);
                            return (d.streams || []).map(st => stremioNormStream(st, x));
                        } catch (e) { return []; }
                    });
                let lists = [];
                try { lists = await Promise.all(jobs); } catch (e) {}
                lists.forEach(l => l.forEach(st => { if (st && st.link) out.push(st); }));
            } catch (e) {}
            if (cand.type !== 'series') return stremioMovieRelevant(out, cand);
            return out;
        }
        function stremioNormStream(st, x) {
            try {
                const name = String(st.name || '').replace(/\n/g, ' / ');
                const title = String(st.title || '');
                const lines = title.split('\n').map(s => s.trim()).filter(Boolean);
                const filename = (st.behaviorHints && st.behaviorHints.filename) || '';
                const link = stremioLinkOf(st, filename);
                if (!link) return null;
                const sub = (lines[1] || lines[0] || '').slice(0, 90);
                const sizeM = title.match(/💾\s*([0-9.]+\s*[GM]B)/);
                const seedM = title.match(/👤\s*([0-9]+)/);
                return {
                    addon: (x && (x.a.addonName || x.m.name)) || stremioHost((x && x.a.base) || ''),
                    label: (lines[0] || name || 'Stream').slice(0, 90),
                    sub: sub,
                    size: sizeM ? sizeM[1] : '',
                    seeders: seedM ? parseInt(seedM[1], 10) : null,
                    link: link,
                    full: (title + ' ' + name).slice(0, 500)
                };
            } catch (e) { return null; }
        }
        function stremioLinkOf(st, filename) {
            try {
                if (st.url) return String(st.url);
                const ih = String(st.infoHash || '');
                if (!ih) return '';
                let m = 'magnet:?xt=urn:btih:' + ih;
                const dn = filename || (String(st.title || '').split('\n')[0] || '').trim();
                if (dn) m += '&dn=' + encodeURIComponent(dn);
                (st.sources || []).forEach(s => {
                    const t = String(s || '');
                    if (/^tracker:/i.test(t)) m += '&tr=' + encodeURIComponent(t.replace(/^tracker:/i, ''));
                });
                return m;
            } catch (e) { return ''; }
        }
        function stremioCopyLink(link) {
            const done = () => { try { showStatus(tLang('stremioCopied'), 'success'); } catch (e) {} };
            const fail = () => { try { showStatus(tLang('stremioCopyFail'), 'error'); } catch (e) {} };
            try {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(link).then(done, () => stremioCopyFallback(link, done, fail));
                } else stremioCopyFallback(link, done, fail);
            } catch (e) { try { stremioCopyFallback(link, done, fail); } catch (e2) { fail(); } }
        }
        function stremioCopyFallback(text, done, fail) {
            try {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.setAttribute('readonly', '');
                ta.style.position = 'fixed'; ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.focus();
                ta.select();
                try { ta.setSelectionRange(0, ta.value.length); } catch (e) {}
                const ok = document.execCommand('copy');
                ta.remove();
                if (ok) { done(); return; }
            } catch (e) {}
            try { stremioShowManualCopy(text); done(); } catch (e) { fail(); }
        }
        function stremioShowManualCopy(text) {
            try {
                let ov = document.getElementById('stremioManualCopy');
                if (ov) ov.remove();
                ov = document.createElement('div');
                ov.id = 'stremioManualCopy';
                ov.className = 'fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4';
                ov.style.zIndex = '100';
                ov.innerHTML = '<div class="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-4 flex flex-col gap-3">'
                    + '<div class="text-xs font-bold text-slate-200">' + tLang('stremioManualCopy') + '</div>'
                    + '<input id="stremioManualCopyInput" type="text" readonly dir="ltr" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-[11px] text-slate-200 focus:outline-none">'
                    + '<button id="stremioManualCopyClose" class="bg-sky-700 hover:bg-sky-600 text-white text-xs px-3 py-2 rounded-xl font-bold cursor-pointer">' + tLang('stremioBack') + '</button></div>';
                document.body.appendChild(ov);
                const inp = document.getElementById('stremioManualCopyInput');
                if (inp) {
                    inp.value = text;
                    inp.focus();
                    inp.select();
                    try { inp.setSelectionRange(0, inp.value.length); } catch (e) {}
                    inp.addEventListener('click', () => { try { inp.select(); } catch (e) {} });
                }
                const cb = document.getElementById('stremioManualCopyClose');
                if (cb) cb.addEventListener('click', () => { try { ov.remove(); } catch (e) {} });
                ov.addEventListener('click', (e) => { if (e.target === ov) { try { ov.remove(); } catch (e2) {} } });
            } catch (e) {}
        }
        // ===== حوار الاقتراح: فيلم ← قائمة روابط مباشرة / مسلسل ← مجلد ← مواسم ← حلقات =====
        function stremioDlgEls() {
            return {
                modal: document.getElementById('stremioSugModal'),
                head: document.getElementById('stremioSugHead'),
                body: document.getElementById('stremioSugBody'),
                back: document.getElementById('stremioSugBack')
            };
        }
        function stremioStreamRow(st) {
            const r = document.createElement('div');
            r.className = 'flex items-center gap-2 px-2.5 py-2 bg-slate-900 border border-slate-800 rounded-lg cursor-pointer hover:border-emerald-500/40 transition text-right';
            r.innerHTML = '<i class="fa-solid fa-link text-emerald-400 text-xs flex-shrink-0"></i>'
                + '<div class="flex-1 min-w-0"><div class="text-[11px] font-bold text-slate-200 truncate">' + escImp(st.label) + '</div>'
                + '<div class="text-[10px] text-slate-500 truncate">' + escImp([st.sub, st.size].filter(Boolean).join(' • ')) + '</div></div>'
                + '<span class="text-[8px] font-bold px-1.5 py-0.5 rounded bg-violet-950 text-violet-300 border border-violet-800/80 flex-shrink-0 max-w-[90px] truncate" dir="ltr">' + escImp(st.addon || '') + '</span>'
                + '<span class="text-[9px] text-slate-500 flex-shrink-0">' + tLang('stremioDetails') + '</span>';
            r.addEventListener('click', (e) => { try { e.stopPropagation(); } catch (x) {} stremioOpenLink(st); });
            return r;
        }
        function stremioLoadingRow() {
            const d = document.createElement('div');
            d.className = 'text-center py-4 text-slate-400 text-xs';
            d.innerHTML = '<i class="fa-solid fa-spinner fa-spin text-sky-400"></i> ' + tLang('stremioSugLoading');
            return d;
        }
        async function openStremioSug(key) {
            const s = stremioSug.find(x => stremioSugKey(x) === key);
            if (!s) return;
            const { modal, head, body, back } = stremioDlgEls();
            if (!modal || !head || !body) return;
            stremioDlgState = { key };
            try {
                head.innerHTML = (s.poster ? '<img src="' + s.poster.replace(/"/g, '&quot;') + '" class="w-12 h-[72px] object-cover rounded-lg bg-slate-950 flex-shrink-0" alt="">' : '')
                    + '<div class="flex-1 min-w-0"><div class="text-sm font-extrabold text-slate-100 truncate">' + escImp(s.name) + '</div>'
                    + '<div class="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5"><span>' + escImp(s.year || '') + '</span>'
                    + '<span class="px-1.5 py-px rounded bg-sky-950 text-sky-300 border border-sky-800/80 font-bold">' + (s.type === 'series' ? tLang('tabTv') : tLang('tabMovie')) + '</span></div></div>';
            } catch (e) {}
            try { if (back) back.classList.add('hidden'); } catch (e) {}
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            body.innerHTML = '';
            body.appendChild(stremioLoadingRow());
            if (s.type !== 'series') {
                // فيلم: مجلد الفيلم ← مجلدات الجودات ← الروابط
                let streams = s.streams || [];
                if (!streams.length) {
                    const provs = await stremioLiveProviders();
                    streams = await stremioStreamsFor(s, null, provs.streamers, provs.metaProviders);
                    try { s.streams = streams; } catch (e) {}
                }
                body.innerHTML = '';
                if (!streams.length) {
                    body.innerHTML = '<div class="text-center py-4 text-slate-500 text-xs">' + tLang('stremioNoStreams') + '</div>';
                    return;
                }
                stremioGroupStreams(streams).forEach(g => body.appendChild(stremioQFolderBox(g)));
                return;
            }
            // مسلسل: مواسم (جودات الموسم + حلقات) — بلا مجلد جودات للمسلسل كاملاً
            let meta = null;
            try {
                const provs = await stremioLiveProviders();
                meta = await stremioMetaFor(s, provs.metaProviders);
                s._provs = provs;
            } catch (e) {}
            const vs = stremioVideosOf(meta);
            body.innerHTML = '';
            if (!vs.length) {
                body.innerHTML = '<div class="text-center py-4 text-slate-500 text-xs">' + tLang('stremioNoStreams') + '</div>';
                return;
            }
            const secT = document.createElement('div');
            secT.className = 'text-[11px] font-extrabold text-slate-400 px-1 pt-1';
            secT.textContent = tLang('stremioSeasons');
            body.appendChild(secT);
            const seasons = [...new Set(vs.map(v => v.season))].sort((a, b) => a - b);
            seasons.forEach(sn => {
                const eps = vs.filter(v => v.season === sn);
                // داخل الموسم: جودات الموسم بالأعلى + مجلدات الحلقات تحتها
                const f = stremioFolderEl(escImp(tLang('seasonLabel') + ' ' + sn), '(' + eps.length + ' ' + tLang('episodesWord') + ')', async (ctn) => {
                    ctn.innerHTML = '';
                    let provs = null;
                    try { provs = s._provs || await stremioLiveProviders(); } catch (e) {}
                    let lists = [];
                    try { lists = await Promise.all(eps.map(ep => stremioEpStreams(s, ep, provs))); } catch (e) {}
                    const all = [];
                    lists.forEach(l => (l || []).forEach(st => all.push(st)));
                    const groups = stremioGroupStreams(all);
                    if (groups.length) {
                        const qh = document.createElement('div');
                        qh.className = 'text-[10px] font-extrabold text-sky-300/90 px-1 pt-1';
                        qh.textContent = tLang('stremioQTitle');
                        ctn.appendChild(qh);
                        groups.forEach(g => ctn.appendChild(stremioQFolderBox(g)));
                    }
                    const eh = document.createElement('div');
                    eh.className = 'text-[10px] font-extrabold text-slate-400 px-1 pt-1';
                    eh.textContent = tLang('stremioEpisodes');
                    ctn.appendChild(eh);
                    eps.forEach(ep => ctn.appendChild(stremioEpRow(s, ep)));
                });
                body.appendChild(f.box);
            });
        }
        function stremioEpRow(s, ep) {
            // مجلد الحلقة ← مجلدات جوداتها ← الروابط (الضغط على رابط يفتح ديالوغ التحميل)
            const code = 'S' + String(ep.season).padStart(2, '0') + 'E' + String(ep.episode).padStart(2, '0');
            const title = '<span class="text-emerald-500/90 font-bold">' + code + '</span> <span class="font-normal text-slate-300">' + escImp(ep.title || ('#' + ep.episode)) + '</span>';
            const f = stremioFolderEl(title, '', async (ctn) => {
                ctn.innerHTML = '';
                let arr = [];
                try {
                    const provs = s._provs || await stremioLiveProviders();
                    arr = await stremioEpStreams(s, ep, provs);
                } catch (e) {}
                const groups = stremioGroupStreams(arr);
                if (!groups.length) { ctn.innerHTML = '<div class="text-[10px] text-slate-500 px-1">' + tLang('stremioNoStreams') + '</div>'; return; }
                groups.forEach(g => ctn.appendChild(stremioQFolderBox(g)));
            });
            return f.box;
        }
        async function stremioLiveProviders() {
            if (!stremioAddons.length) { try { stremioLoadAddons(); } catch (e) {} }
            const enabled = stremioAddons.filter(a => a && a.enabled && stremioBaseOf(a.base));
            let mans = [];
            try { mans = await Promise.all(enabled.map(async a => ({ a, m: await stremioManifest(a) }))); } catch (e) {}
            const roles = mans.filter(x => x.m).map(x => ({ a: x.a, m: x.m, r: stremioRoles(x.m) }));
            return { streamers: roles.filter(x => x.r.stream), metaProviders: roles.filter(x => x.r.meta) };
        }
        function closeStremioSug() {
            try {
                const m = document.getElementById('stremioSugModal');
                if (m) { m.classList.add('hidden'); m.classList.remove('flex'); }
            } catch (e) {}
            stremioDlgState = null;
        }
        // ===== إعدادات الإضافات: إضافة / تفعيل / تعطيل / حذف =====
        function renderStremioAddons() {
            try {
                const list = document.getElementById('stremioAddonList');
                if (!list) return;
                list.innerHTML = '';
                if (!stremioAddons.length) {
                    list.innerHTML = '<div class="text-center py-2 text-slate-500 text-[11px]">' + tLang('stremioNoAddons') + '</div>';
                    return;
                }
                stremioAddons.forEach((a, idx) => {
                    const name = (a.name || stremioHost(a.base));
                    const row = document.createElement('div');
                    row.className = 'flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-3 py-2';
                    row.innerHTML = '<i class="fa-solid fa-puzzle-piece text-sky-400 text-xs flex-shrink-0"></i>'
                        + '<div class="flex-1 min-w-0"><div class="text-xs font-bold text-slate-200 truncate">' + escImp(name) + '</div>'
                        + '<div class="text-[10px] text-slate-500 truncate" dir="ltr">' + escImp(a.base) + '</div></div>'
                        + '<label class="flex items-center gap-1 cursor-pointer flex-shrink-0"><input type="checkbox" data-stremio-toggle="' + idx + '" class="w-4 h-4 accent-emerald-500 cursor-pointer"' + (a.enabled ? ' checked' : '') + '></label>'
                        + '<button data-stremio-del="' + idx + '" class="text-rose-400 hover:text-rose-300 text-xs px-1.5 cursor-pointer flex-shrink-0"><i class="fa-solid fa-trash-can"></i></button>';
                    list.appendChild(row);
                });
            } catch (e) {}
        }
        async function stremioAddFromInput() {
            try {
                const inp = document.getElementById('stremioAddInput');
                if (!inp) return;
                const base = stremioBaseOf(inp.value);
                if (!base) { try { showStatus(tLang('stremioInvalid'), 'error'); } catch (e) {} return; }
                if (stremioAddons.some(a => stremioBaseOf(a.base) === base)) { try { showStatus(tLang('stremioExists'), 'error'); } catch (e) {} return; }
                inp.disabled = true;
                let m = null;
                try { m = await stremioGet(base + '/manifest.json', 12000); } catch (e) {}
                inp.disabled = false;
                if (!m || (!m.resources && !m.catalogs)) { try { showStatus(tLang('stremioInvalid'), 'error'); } catch (e) {} return; }
                stremioAddons.push({ base, enabled: true, name: m.name || '' });
                try { delete stremioManifestCache[base]; stremioManifestCache[base] = m; } catch (e) {}
                inp.value = '';
                stremioSaveAddons();
                renderStremioAddons();
                try { showStatus(tLang('stremioAdded'), 'success'); } catch (e) {}
            } catch (e) {}
        }
        function stremioInit() {
            try { stremioLoadAddons(); } catch (e) {}
            try { renderStremioAddons(); } catch (e) {}
            try {
                const btn = document.getElementById('stremioAddBtn');
                if (btn && !btn._stremioWired) {
                    btn._stremioWired = true;
                    btn.addEventListener('click', () => { stremioAddFromInput(); });
                }
                const inp = document.getElementById('stremioAddInput');
                if (inp && !inp._stremioWired) {
                    inp._stremioWired = true;
                    inp.addEventListener('keypress', (e) => { if (e.key === 'Enter') stremioAddFromInput(); });
                }
                const list = document.getElementById('stremioAddonList');
                if (list && !list._stremioWired) {
                    list._stremioWired = true;
                    list.addEventListener('change', (e) => {
                        const t = e.target;
                        if (t && t.matches && t.matches('[data-stremio-toggle]')) {
                            const i = parseInt(t.getAttribute('data-stremio-toggle'), 10);
                            if (stremioAddons[i]) { stremioAddons[i].enabled = !!t.checked; stremioSaveAddons(); }
                        }
                    });
                    list.addEventListener('click', (e) => {
                        const b = e.target.closest ? e.target.closest('[data-stremio-del]') : null;
                        if (b) {
                            const i = parseInt(b.getAttribute('data-stremio-del'), 10);
                            if (stremioAddons[i]) { stremioAddons.splice(i, 1); stremioSaveAddons(); renderStremioAddons(); }
                        }
                    });
                }
                const cb = document.getElementById('stremioSugClose');
                if (cb && !cb._stremioWired) { cb._stremioWired = true; cb.addEventListener('click', closeStremioSug); }
                const md = document.getElementById('stremioSugModal');
                if (md && !md._stremioWired) {
                    md._stremioWired = true;
                    md.addEventListener('click', (e) => { if (e.target === md) closeStremioSug(); });
                }
            } catch (e) {}
        }

        // بدء متأخر: كتلة الإقلاع في 11-scroll تعمل قبل تحليل هذا الملف، لذا نهيئ هنا.
        try { if (!window.__stremioBooted && typeof stremioInit === 'function') { window.__stremioBooted = true; stremioInit(); } } catch (e) {}
