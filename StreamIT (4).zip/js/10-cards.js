        // ===== تعليم الروابط المكسورة: حلقة مكسورة ⇒ شارة عليها، =====
        // ===== وموسم كامل مكسور ⇒ الشارة على مجلد الموسم فقط (تُخفى عن حلقاته) =====
        let __deadSeasonCache = null;
        function deadSeasonSet() {
            if (__deadSeasonCache) return __deadSeasonCache;
            const byS = new Map();
            try {
                (parsedItems || []).forEach(it => {
                    if (!it || it.category !== 'tv' || !it.url) return;
                    const k = groupKeyOf(it) + ':' + (it.seasonNumber || 1);
                    let o = byS.get(k); if (!o) { o = { t: 0, d: 0 }; byS.set(k, o); }
                    o.t++; if (it.linkState === 'dead') o.d++;
                });
            } catch (e) {}
            const s = new Set();
            try { byS.forEach((o, k) => { if (o.t > 0 && o.d === o.t) s.add(k); }); } catch (e) {}
            __deadSeasonCache = s;
            return s;
        }
        function invalidateDeadSeasonCache() { __deadSeasonCache = null; }
        function deadBadgeHtml(big) {
            return '<span class="' + (big ? 'text-[10px]' : 'text-[9px]') + ' font-bold px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/80 shrink-0">🔗 ' + tLang('linkDead') + '</span>';
        }
        function epDeadBadgeHidden(ep) {
            try {
                if (!ep || ep.linkState !== 'dead') return false;
                return deadSeasonSet().has(groupKeyOf(ep) + ':' + (ep.seasonNumber || 1));
            } catch (e) { return false; }
        }
        // Show Card Component (ListView Mode)
        function createShowListViewCard(show) {
            const card = document.createElement('div');
            card.className = "p-3 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded-2xl flex items-center gap-3.5 shadow-lg transition text-right group relative";

            const ratingVal = show.rating || (show.tmdbDetails ? show.tmdbDetails.rating : null);
            let genresVal = show.genres || (show.tmdbDetails ? show.tmdbDetails.genres : null); try { if (!genresVal) genresVal = tLang('genresFallback'); } catch (e) { if (!genresVal) genresVal = 'General'; }
            const shp = showProgress(show.items || []);
            const showL = showLoc(show);

            card.innerHTML = `
                <!-- Poster -->
                <div class="relative w-20 h-28 bg-slate-900 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer poster-action border border-slate-800">
                    <img loading="lazy" decoding="async" src="${show.poster}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" onerror="this.src='${generateSvgAvatar(show.title)}'">
                    <div class="absolute top-1 start-1 bg-amber-950/90 text-amber-400 text-[9px] font-bold px-1.5 py-0.5 rounded border border-amber-800/80">
                        ${tLang('badgeSeries')}
                    </div>
                    ${isShowFav(show) ? '<div class="absolute bottom-1 end-1 w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-xs font-black shadow-lg" title="fav">★</div>' : ''}
                </div>

                <!-- Info Details -->
                <div class="flex flex-col gap-1 min-w-0 flex-grow">
                    <div class="flex items-center justify-between gap-2">
                        <h4 dir="auto" class="flex-1 min-w-0 font-extrabold text-sm text-slate-100 truncate cursor-pointer main-click-area hover:text-emerald-400 transition" title="${escHtml(showL.title || show.title)}">
                            ${isShowFav(show) ? '<span class="text-amber-400">★ </span>' : ''}${escHtml(showL.title || show.title)}
                        </h4>

                        <div class="relative dropdown-container flex-shrink-0 z-20">
                            <button class="menu-btn w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 flex items-center justify-center transition cursor-pointer">
                                <i class="fa-solid fa-ellipsis-vertical text-xs"></i>
                            </button>
                            <div class="dropdown-menu hidden absolute end-0 top-8 w-40 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-30 flex-col overflow-hidden text-xs">
                                <button class="opt-details w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-circle-info text-sky-400 w-3.5"></i> ${tLang('details')}
                                </button>
                                <button class="opt-search w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-arrows-rotate text-amber-400 w-3.5"></i> ${tLang('searchDoc')}
                                </button>
                                <button class="opt-export w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-file-export text-emerald-400 w-3.5"></i> ${tLang('exportM3U8')}
                                </button>
                                <button class="opt-fav w-full text-right px-3 py-2 hover:bg-slate-800 text-amber-300 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-star w-3.5"></i> <span class="opt-fav-label">${tLang('favAdd')}</span>
                                </button>
                                <div class="border-t border-slate-800"></div>
                                <button class="opt-delete w-full text-right px-3 py-2 hover:bg-rose-950/60 text-rose-400 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-trash-can w-3.5"></i> ${tLang('del')}
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Meta Specs Row -->
                    <div class="flex flex-wrap items-center gap-2 text-[11px]">
                        ${isShowFav(show) ? '<span class="bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800/80 font-bold">★ ' + tLang('favBadge') + '</span>' : ''}
                        ${show.year ? `<span class="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-emerald-400 font-bold">${show.year}</span>` : ''}
                        
                        ${ratingVal ? `
                            <span class="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-amber-400 font-bold flex items-center gap-1">
                                <i class="fa-solid fa-star text-[10px]"></i> ${ratingVal}
                            </span>
                        ` : ''}

                        <span class="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/80 font-bold">
                            ${show.episodesCount} ${tLang('episodesWord')}
                        </span>
                        ${shp.w > 0 ? '<span class="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-emerald-400 font-bold">✓ ' + shp.w + '/' + shp.t + '</span>' : ''}
                        ${ (typeof lastWatched !== 'undefined' && lastWatched.show === show.key) ? '<span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + tLang('lastWatched') + '</span>' : ''}

                        <span class="text-slate-400 text-[10px] truncate max-w-[140px] min-w-0">${escHtml(genresText(showL.genres) || genresVal)}</span>
                    </div>

                    <!-- Overview / Description -->
                    <p class="text-[11px] text-slate-400 line-clamp-2 leading-relaxed mt-0.5 break-words" dir="auto">
                        ${escHtml(showL.overview || show.overview || '') || tLang('noDescShow')}
                    </p>
                </div>
            `;

            card.querySelectorAll('.main-click-area').forEach(el => {
                el.addEventListener('click', () => {
                    const goShow = () => {
                        navState.level = 2;
                        navState.showTitle = show.title;
                        navState.showKey = show.key;
                        listSearchInput.value = '';
                        listSearchQuery = '';
                        clearListSearchBtn.classList.add('hidden');
                        inSelectionMode = false; selectedKeys.clear();
                        disarmDeleteBtn();
                        refreshApp();
                    };
                    // اقتراح التوثيق لمرة واحدة عند أول ضغطة على مسلسل جديد غير موثق
                    const needSuggest = (show.items || []).some(i => i.docAsked === false && !isItemDocumented(i));
                    if (needSuggest) {
                        openDocSuggest('tv', { showKey: show.key, title: show.title, query: show.title }, goShow);
                        return;
                    }
                    goShow();
                });
            });

            setupCardMenu(card, show, true);
            return card;
        }

        // Single Item ListView Component (Movies / Live)
        function createSingleItemListViewCard(item) {
            const card = document.createElement('div');
            card.className = "p-3 bg-slate-950 border border-slate-800 hover:border-purple-500/50 rounded-2xl flex items-center gap-3.5 shadow-lg transition text-right group relative";

            const ratingVal = item.rating || (item.tmdbDetails ? item.tmdbDetails.rating : null);
            let genresVal = item.genres || (item.tmdbDetails ? item.tmdbDetails.genres : null); try { if (!genresVal) genresVal = tLang('genresFallback'); } catch (e) { if (!genresVal) genresVal = 'General'; }
            const mvWatched = item.category === 'movie' && !!item.watchedAt;
            const mvIsLast = item.category === 'movie' && !!((typeof lastWatched !== 'undefined') && lastWatched.movie === item.id);
            const liveIsLast = item.category === 'live' && !!((typeof lastWatched !== 'undefined') && lastWatched.live === item.id);
            const itL = locDoc(item);

            card.innerHTML = `
                <!-- Poster -->
                <div class="relative w-20 h-28 bg-slate-900 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer poster-action border border-slate-800">
                    <img loading="lazy" decoding="async" src="${item.poster || generateSvgAvatar(item.cleanTitle)}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300" onerror="this.src='${generateSvgAvatar(item.cleanTitle)}'">
                    

                    ${item.category === 'movie' ? `
                    <div class="absolute top-1 start-1 bg-purple-950/90 text-purple-300 text-[9px] font-bold px-1.5 py-0.5 rounded border border-purple-800/80">
                        ${tLang('badgeMovie')}
                    </div>
                    ` : ''}
                    ${item.category === 'live' ? `
                    <div class="absolute top-1 start-1 bg-sky-950/90 text-sky-300 text-[9px] font-bold px-1.5 py-0.5 rounded border border-sky-800/80">
                        ${tLang('badgeLive')}
                    </div>
                    ` : ''}
                    ${item.isFavorite ? '<div class="absolute bottom-1 end-1 w-6 h-6 rounded-full bg-amber-500 text-slate-950 flex items-center justify-center text-xs font-black shadow-lg">★</div>' : ''}
                    ${item.category === 'movie' ? '<button class="eye-toggle absolute bottom-1 start-1 w-7 h-7 rounded-lg bg-slate-950/85 hover:bg-slate-800 border border-slate-700 flex items-center justify-center transition cursor-pointer" title="' + tLang('watched') + '"><i class="fa-solid ' + (mvWatched ? 'fa-eye text-emerald-400' : 'fa-eye-slash text-slate-500') + ' text-xs"></i></button>' : ''}
                </div>

                <!-- Info Details -->
                <div class="flex flex-col gap-1 min-w-0 flex-grow">
                    <div class="flex items-center justify-between gap-2">
                        <h4 dir="auto" class="flex-1 min-w-0 font-extrabold text-sm text-slate-100 truncate cursor-pointer play-trigger hover:text-purple-400 transition" title="${escHtml(itL.title || dispName(item))}">
                            ${item.isFavorite ? '<span class="text-amber-400">★ </span>' : ''}${escHtml(itL.title || dispName(item))}
                        </h4>

                        <div class="relative dropdown-container flex-shrink-0 z-20">
                            <button class="menu-btn w-7 h-7 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-100 flex items-center justify-center transition cursor-pointer">
                                <i class="fa-solid fa-ellipsis-vertical text-xs"></i>
                            </button>
                            <div class="dropdown-menu hidden absolute end-0 top-8 w-40 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl z-30 flex-col overflow-hidden text-xs">
                                <button class="opt-details w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-circle-info text-sky-400 w-3.5"></i> ${tLang('details')}
                                </button>
                                <button class="opt-search w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-arrows-rotate text-amber-400 w-3.5"></i> ${tLang('searchDoc')}
                                </button>
                                <button class="opt-export w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-200 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-file-export text-emerald-400 w-3.5"></i> ${tLang('exportM3U8')}
                                </button>
                                <button class="opt-fav w-full text-right px-3 py-2 hover:bg-slate-800 text-amber-300 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-star w-3.5"></i> <span class="opt-fav-label">${tLang('favAdd')}</span>
                                </button>
                                <div class="border-t border-slate-800"></div>
                                <button class="opt-delete w-full text-right px-3 py-2 hover:bg-rose-950/60 text-rose-400 flex items-center gap-2 transition cursor-pointer">
                                    <i class="fa-solid fa-trash-can w-3.5"></i> ${tLang('del')}
                                </button>
                            </div>
                        </div>
                    </div>

                    ${item.category === 'live' && item.isFavorite ? '<div class="flex flex-wrap items-center gap-2 text-[11px]"><span class="bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800/80 font-bold">★ ' + tLang('favBadge') + '</span></div>' : ''}
                    ${item.category === 'live' ? '<div class="flex flex-wrap items-center gap-2 text-[11px]"><span class="bg-sky-950 text-sky-300 px-2 py-0.5 rounded border border-sky-800/80 font-bold shrink-0">' + tLang('badgeLive') + '</span>' + (item.linkState === 'dead' ? deadBadgeHtml(true) : '') + (liveIsLast ? '<span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + tLang('lastWatched') + '</span>' : '') + '</div>' : ''}
                    ${item.category === 'movie' ? `
                    <!-- Meta Specs Row -->
                    <div class="flex flex-wrap items-center gap-2 text-[11px]">
                        ${item.isFavorite ? '<span class="bg-amber-950 text-amber-300 px-2 py-0.5 rounded border border-amber-800/80 font-bold shrink-0">★ ' + tLang('favBadge') + '</span>' : ''}
                        ${item.linkState === 'dead' ? deadBadgeHtml(true) : ''}
                        ${mvWatched ? '<span class="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800/80 font-bold shrink-0">✓ ' + tLang('watched') + '</span>' : ''}
                        ${item.year ? `<span class="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-emerald-400 font-bold">${item.year}</span>` : ''}
                        ${item.durationMin ? `<span class="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-sky-300 font-bold">⏱ ${Math.round(item.durationMin)} ${tLang('minShort')}</span>` : ''}
                        
                        ${ratingVal ? `
                            <span class="bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-amber-400 font-bold flex items-center gap-1">
                                <i class="fa-solid fa-star text-[10px]"></i> ${ratingVal}
                            </span>
                        ` : ''}

                        <span class="text-slate-400 text-[10px] truncate max-w-[160px] min-w-0">${escHtml(genresText(itL.genres) || genresVal)}</span>
                        ${mvIsLast ? '<span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + tLang('lastWatched') + '</span>' : ''}
                    </div>

                    <!-- Overview / Description -->
                    <p class="text-[11px] text-slate-400 line-clamp-2 leading-relaxed mt-0.5 break-words" dir="auto">
                        ${escHtml(itL.overview || item.overview || '') || tLang('noDescMovie')}
                    </p>
                    ` : ''}
                </div>
            `;

            const playAction = () => {
                const goPlay = () => openExternalPlayerModal(dispName(item), item.url, item);
                // اقتراح التوثيق لمرة واحدة عند أول ضغطة مزدوجة على فيلم جديد غير موثق
                if (item.category === 'movie' && item.docAsked === false && !isItemDocumented(item)) {
                    openDocSuggest('movie', { itemId: item.id, title: (item.cleanTitle || ''), query: (item.cleanTitle || '') }, goPlay);
                    return;
                }
                goPlay();
            };
            card.querySelectorAll('.play-trigger').forEach(el => {
                bindDoubleOpen(el, playAction, 'ring-purple-500');
            });
            // الضغط على الغلاف = نفس سلوك العنوان (تسليح ثم مشغّل)، والقائمة عبر زر ⋮ فقط
            const posterEl = card.querySelector('.poster-action');
            if (posterEl) bindDoubleOpen(posterEl, playAction, 'ring-purple-500');

            setupSingleItemMenu(card, item);
            return card;
        }

        // Season Folder Card Component
        function createSeasonFolderCard(season) {
            const sp = seasonProgress(season.episodesList);
            const seps = (season.episodesList || []).filter(e => e && e.url);
            const seasonAllDead = seps.length > 0 && seps.every(e => e.linkState === 'dead');
            const card = document.createElement('div');
            card.className = "p-3.5 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-xl flex items-center justify-between text-right cursor-pointer transition shadow-md group";
            
            card.innerHTML = `
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-lg bg-amber-950/60 border border-amber-800/80 text-amber-400 flex items-center justify-center font-bold text-sm">
                        S${season.seasonNumber}
                    </div>
                    <div>
                        <h4 class="font-bold text-xs text-slate-200 group-hover:text-amber-400 transition">${tLang('seasonLabel')} ${season.seasonNumber}</h4>
                        ${seasonAllDead ? '<span class="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/80">🔗 ' + tLang('linkDead') + '</span>' : ''}
                        ${sp.w === sp.t && sp.t > 0 ? '<span class="text-[10px] text-emerald-400 font-bold">✓ ' + tLang('fullyWatched') + '</span>' : (sp.w > 0 ? '<span class="text-[10px] text-emerald-400/80">' + sp.w + '/' + sp.t + ' ' + tLang('watched') + '</span>' : '<span class="text-[10px] text-slate-400">' + sp.t + ' ' + tLang('episodesWord') + '</span>')}
                    </div>
                </div>
                <i class="fa-solid fa-chevron-left flip-rtl text-slate-500 text-xs group-hover:text-amber-400 transition"></i>
            `;

            card.addEventListener('click', () => {
                navState.level = 3;
                navState.seasonNumber = season.seasonNumber;
                listSearchInput.value = '';
                listSearchQuery = '';
                clearListSearchBtn.classList.add('hidden');
                inSelectionMode = false; selectedKeys.clear();
                disarmDeleteBtn();
                refreshApp();
            });

            return card;
        }

        // Episode Item Card Component
        function createEpisodeCard(ep) {
            const card = document.createElement('div');
            card.className = "p-3 bg-slate-950 border border-slate-800 hover:border-emerald-500/50 rounded-xl flex items-center justify-between text-right transition shadow-sm cursor-pointer";
            
            const epNumL = ep.episodeNumber || 1;
            // عرض اسم الحلقة فقط بجانب الرقم الأخضر (بلا "الحلقة N" وبلا أيقونة)
            const displayBase = ep.episodeTitle || ep.cleanTitle || ep.rawTitle || ('#' + epNumL);
            const displayTitle = (ep.dupIndex && ep.dupIndex > 0) ? (displayBase + ' (' + ep.dupIndex + ')') : displayBase;
            const displayTitleSafe = String(displayTitle).replace(/</g, '&lt;').replace(/"/g, '&quot;');
            const epSk = groupKeyOf(ep);
            const epWatched = !!ep.watchedAt;
            const epIsLast = !!((typeof lastWatched !== 'undefined') && lastWatched.shows && lastWatched.shows[epSk] === ep.id);

            card.innerHTML = `
                <div class="flex items-center gap-3 min-w-0 flex-grow">
                    <div class="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 text-emerald-400 flex items-center justify-center font-bold text-xs flex-shrink-0 ep-num-badge cursor-pointer select-none" title="${tLang('tPinHint')}">
                        ${epNumL}
                    </div>
                    <div class="min-w-0 flex-grow">
                        <h4 class="font-bold text-xs text-slate-200 truncate" title="${displayTitleSafe}">
                            ${displayTitleSafe}
                        </h4>
                    </div>
                </div>
                <div class="flex items-center gap-1 flex-shrink-0">
                    <button class="eye-toggle w-6 h-6 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 flex items-center justify-center transition cursor-pointer flex-shrink-0" title="${tLang('watched')}">
                        <i class="fa-solid ${epWatched ? 'fa-eye text-emerald-400' : 'fa-eye-slash text-slate-500'} text-xs"></i>
                    </button>
                    ${epIsLast ? '<span class="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + tLang('lastWatched') + '</span>' : ''}
                    ${(ep.linkState === 'dead' && !epDeadBadgeHidden(ep)) ? deadBadgeHtml(false) : ''}
                    ${ep.durationMin ? '<span class="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-900 text-sky-300 border border-slate-700">⏱ ' + Math.round(ep.durationMin) + ' ' + tLang('minShort') + '</span>' : ''}
                    ${epWatched ? '<i class="fa-solid fa-circle-check text-emerald-500 text-xs"></i>' : ''}
                </div>
            `;

            // ضغطة مزدوجة على رقم الحلقة = تثبيت التقدم حتى هنا؛ ضغطتان على البطاقة = ديالوغ المشغلات
            const numBadge = card.querySelector('.ep-num-badge');
            if (numBadge) numBadge.addEventListener('dblclick', (e) => {
                e.stopPropagation();
                try { e.preventDefault(); } catch (e2) {}
                setProgressUpTo(ep);
            });
            bindDoubleOpen(card, () => { openExternalPlayerModal(displayTitle, ep.url, ep); }, 'ring-emerald-500');

            card.querySelector('.eye-toggle').addEventListener('click', (e) => {
                e.stopPropagation();
                toggleEpisodeWatched(ep);
            });

            return card;
        }

        function setupCardMenu(card, show, isGroup) {
            const menuBtn = card.querySelector('.menu-btn');
            const menu = card.querySelector('.dropdown-menu');

            menuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isHidden = menu.classList.contains('hidden');
                closeAllMenus();
                if (isHidden) { try { positionSmartMenu(menu, menuBtn); } catch (e2) { menu.classList.remove('hidden'); } }
            });

            // الضغط على صورة الغلاف = نفس سلوك العنوان (دخول المسلسل)، والقائمة عبر زر ⋮ فقط
            const posterTrig = card.querySelector('.poster-action');
            if (posterTrig) posterTrig.addEventListener('click', (e) => {
                e.stopPropagation();
                const t = card.querySelector('.main-click-area');
                if (t) t.click();
            });

            card.querySelector('.opt-details').addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                showFullExtractedDetails(show);
            });

            card.querySelector('.opt-search').addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                pendingRawItems = [{ key: show.key, showKey: show.key, cleanTitle: show.title, parsedShowTitle: show.title }];
                currentCategory = 'tv';
                isReDocumenting = true;
                openMetadataModal();
            });

            card.querySelector('.opt-export').addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                exportAllDataToM3U8(show.items);
            });

            (function () {
                const fb = card.querySelector('.opt-fav');
                if (fb) {
                    try {
                        const lbl = fb.querySelector('.opt-fav-label');
                        if (lbl) lbl.textContent = isShowFav(show) ? tLang('favRemove') : tLang('favAdd');
                    } catch (e) {}
                    fb.addEventListener('click', (e) => { e.stopPropagation(); closeAllMenus(); toggleFavShow(show.key); });
                }
            })();

            card.querySelector('.opt-delete').addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                selectedKeys.delete('show:' + show.key);
                parsedItems = parsedItems.filter(i => groupKeyOf(i) !== show.key);
                try { if (typeof pruneLastWatched === 'function') pruneLastWatched(); } catch (e2) {}
                saveItemsToStorage();
                try { if (typeof saveLastWatched === 'function') saveLastWatched(); } catch (e2) {}
                refreshApp();
                showStatus(tLang('tShowDeleted'), "info");
            });
        }

        function setupSingleItemMenu(card, item) {
            const menuBtn = card.querySelector('.menu-btn');
            const menu = card.querySelector('.dropdown-menu');

            menuBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isHidden = menu.classList.contains('hidden');
                closeAllMenus();
                if (isHidden) { try { positionSmartMenu(menu, menuBtn); } catch (e2) { menu.classList.remove('hidden'); } }
            });

            // (الغلاف لم يعد يفتح القائمة: سلوكه معرّف مع العنوان، والقائمة عبر زر ⋮ فقط)

            if (item.category === 'live') {
                // المباشر: التفاصيل/التوثيق/التصدير محذوفة، وتبقى المفضلة + الحذف
                ['.opt-details', '.opt-search', '.opt-export'].forEach(s => { const b = card.querySelector(s); if (b) b.remove(); });
                const sep = card.querySelector('.dropdown-menu .border-t');
                if (sep) sep.remove();
            }

            const qd = card.querySelector('.opt-details');
            if (qd) qd.addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                showFullExtractedDetails(item);
            });

            const qs = card.querySelector('.opt-search');
            if (qs) qs.addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                pendingRawItems = [item];
                currentCategory = item.category;
                isReDocumenting = true;
                openMetadataModal();
            });

            const qx = card.querySelector('.opt-export');
            if (qx) qx.addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                exportAllDataToM3U8([item]);
            });

            (function () {
                const fb = card.querySelector('.opt-fav');
                if (fb) {
                    try {
                        const lbl = fb.querySelector('.opt-fav-label');
                        if (lbl) lbl.textContent = item.isFavorite ? tLang('favRemove') : tLang('favAdd');
                    } catch (e) {}
                    fb.addEventListener('click', (e) => { e.stopPropagation(); closeAllMenus(); toggleFavItem(item.id); });
                }
            })();

            const qe = card.querySelector('.eye-toggle');
            if (qe) qe.addEventListener('click', (e) => {
                e.stopPropagation();
                toggleMovieWatched(item);
            });

            if (item.category === 'movie' && item.watchedAt) {
                const rb = document.createElement('button');
                rb.className = "opt-unwatch w-full text-right px-3 py-2 hover:bg-slate-800 text-slate-400 flex items-center gap-2 transition cursor-pointer";
                rb.innerHTML = '<i class="fa-solid fa-eye-slash w-3.5"></i> ' + tLang('makeUnwatched');
                rb.addEventListener('click', (ev) => {
                    ev.stopPropagation();
                    closeAllMenus();
                    item.watchedAt = 0;
                    if (lastWatched.movie === item.id) lastWatched.movie = null;
                    if (lastWatched.live === item.id) lastWatched.live = null;
                    try { if (lastWatched.current && lastWatched.current.kind === 'movie' && lastWatched.current.id === item.id) lastWatched.current = null; } catch (e) {}
                    saveItemsToStorage();
                    saveLastWatched();
                    refreshApp();
                    showStatus(tLang('tMarkedUnw'), "info");
                });
                const qd2 = card.querySelector('.opt-delete');
                if (qd2) qd2.before(rb);
            }

            card.querySelector('.opt-delete').addEventListener('click', (e) => {
                e.stopPropagation();
                closeAllMenus();
                selectedKeys.delete('id:' + item.id);
                parsedItems = parsedItems.filter(i => i.id !== item.id);
                try { if (typeof pruneLastWatched === 'function') pruneLastWatched(); } catch (e2) {}
                saveItemsToStorage();
                try { if (typeof saveLastWatched === 'function') saveLastWatched(); } catch (e2) {}
                refreshApp();
                showStatus(tLang('tItemDeleted'), "info");
            });
        }
