
        function parseM3UString(m3uContent) {
            const lines = m3uContent.split(/\r?\n/);
            const items = [];
            let currentMeta = null;

            lines.forEach(line => {
                line = line.trim();
                if (line.startsWith('#EXTINF:')) {
                    currentMeta = parseExtInf(line);
                } else if (line.length > 0 && !line.startsWith('#')) {
                    const rawTitle = currentMeta?.title || extractNameFromUrl(line);
                    let parsedInfo = null;
                    try { parsedInfo = smartParseMedia(rawTitle, line); }
                    catch(e) { parsedInfo = null; }
                    if (!parsedInfo) {
                        const fb = parseMediaNamePattern(rawTitle, line);
                        parsedInfo = { showTitle: fb.title || rawTitle, showKey: fb.showKey || normalizeShowKey(fb.title || rawTitle), seasonNumber: fb.season || 1, episodeNumber: fb.episode || 1, episodeTitle: fb.episodeTitle || "", resolution: fb.resolution || "", quality: fb.quality || "", codec: fb.codec || "", group: fb.group || "", audio: fb.audio || "", languages: fb.languages || [], hdr: fb.hdr || "", edition: fb.edition || "", year: fb.year || "", isSeries: !!fb.isSeries };
                    }
                    const showName = parsedInfo.showTitle || rawTitle;
                    const epNum = parsedInfo.episodeNumber || 1;
                    const epLabel = parsedInfo.episodeTitle ? parsedInfo.episodeTitle : (parsedInfo.isSeries ? '' : showName);

                    items.push({
                        id: 'item_' + Math.random().toString(36).substr(2, 9),
                        rawTitle: rawTitle,
                        cleanTitle: showName,
                        parsedShowTitle: showName,
                        showKey: parsedInfo.showKey || normalizeShowKey(showName),
                        isSeriesHint: !!parsedInfo.isSeries,
                        seasonNumber: parsedInfo.seasonNumber || 1,
                        episodeNumber: epNum,
                        episodeTitle: epLabel,
                        resolution: parsedInfo.resolution || '',
                        quality: parsedInfo.quality || '',
                        codec: parsedInfo.codec || '',
                        group: parsedInfo.group || '',
                        audio: parsedInfo.audio || '',
                        languages: parsedInfo.languages || [],
                        hdr: parsedInfo.hdr || '',
                        edition: parsedInfo.edition || '',
                        url: line,
                        logo: currentMeta?.logo || '',
                        poster: currentMeta?.poster || currentMeta?.logo || '',
                        overview: currentMeta?.overview || '',
                        metaTitle: currentMeta?.metaTitle || '',
                        year: parsedInfo.year || currentMeta?.year || '',
                        category: currentMeta?.category || 'tv',
                        extinfRaw: currentMeta?.raw || line
                    });
                    currentMeta = null;
                }
            });

            return items;
        }

        function parseExtInf(line) {
            // العنوان = ما بعد أول فاصلة *خارج* علامات الاقتباس (سمات مثل
            // http-user-agent قد تحوي فواصل داخل الاقتباس فتفسد العنوان)
            let title = '';
            let inQ = false, cut = -1;
            for (let i = 0; i < line.length; i++) {
                const c = line[i];
                if (c === '"') inQ = !inQ;
                else if (c === ',' && !inQ) { cut = i; break; }
            }
            if (cut !== -1) title = line.slice(cut + 1).trim();
            const logoMatch = line.match(/(?:tvg-logo|poster|cover)="([^"]*)"/i);
            const metaTitleMatch = line.match(/tvg-name="([^"]*)"/i);

            return {
                raw: line,
                title: title,
                logo: logoMatch ? logoMatch[1].trim() : '',
                poster: logoMatch ? logoMatch[1].trim() : '',
                metaTitle: metaTitleMatch ? metaTitleMatch[1].trim() : ''
            };
        }

        function extractNameFromUrl(url) {
            try {
                const segs = getUrlSegments(url);
                if (segs.length > 0) {
                    let filename = stripMediaExt(segs[segs.length - 1]);
                    try { filename = decodeURIComponent(filename); } catch(e) {}
                    if (filename && filename.length >= 2 && !/^(-1|,)/.test(filename)) return filename;
                }
                return url;
            } catch(e) {
                return url;
            }
        }

        /* 
         * Advanced Link-Based Filename & Metadata Extractor
         * Extracts clean titles, season numbers, episode numbers, and qualities direct from URL structure.
         */
        function parseMediaNamePattern(rawText, urlText = "") {
            try {
                const s = smartParseMedia(rawText, urlText);
                return { title: s.showTitle, season: s.seasonNumber, episode: s.episodeNumber, resolution: s.resolution, quality: s.quality, codec: s.codec, group: s.group, audio: s.audio, languages: s.languages, hdr: s.hdr, edition: s.edition, episodeTitle: s.episodeTitle || "", year: s.year, showKey: s.showKey, isSeries: s.isSeries };
            } catch(e) {
                return { title: rawText || "", season: 1, episode: 1, resolution: "", quality: "", codec: "", group: "", audio: "", languages: [], hdr: "", edition: "", episodeTitle: "", year: "", showKey: "", isSeries: false };
            }
        }

