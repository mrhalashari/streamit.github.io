        // ===== اقتراح التوثيق لمرة واحدة (بعد الإضافة، عند أول ضغطة على عنصر جديد غير موثق) =====
        let suggestState = null; // {kind:'tv'|'movie', showKey?, title?, itemId?, query?}
        let pendingDocAction = null;
        function openDocSuggest(kind, opts, afterAction) {
            suggestState = { kind, showKey: opts.showKey || null, title: opts.title || '', itemId: opts.itemId || null, query: opts.query || opts.title || '' };
            pendingDocAction = afterAction || null;
            currentCategory = kind;
            isReDocumenting = false;
            selectedMetadata = null;
            metaCategoryBadge.textContent = kind === 'tv' ? tLang('catTv') : tLang('catMovie');
            metaCategoryBadge.className = kind === 'tv' ?
                'text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-400 border border-amber-800' :
                'text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-950 text-purple-400 border border-purple-800';
            try { docSuggestNote.classList.remove('hidden'); } catch (e) {}
            metaSearchStage.classList.remove('hidden');
            metaDetailsStage.classList.add('hidden');
            metaDetailsStage.classList.remove('flex');
            metadataModal.classList.remove('hidden');
            metadataModal.classList.add('flex');
            const q = extractCleanQueryName(suggestState.query);
            metaSearchInput.value = q;
            executeApiSearch(q);
        }
        // تطبيق حقول التوثيق على عنصر واحد (مشترك بين كل مسارات التوثيق)
        function applyDocFields(item, md) {
            if (!item || !md) return false;
            try {
                item.poster = md.poster;
                item.overview = md.overview;
                item.metaTitle = md.title;
                item.year = md.year || item.year;
                item.rating = md.rating;
                item.genres = md.genres;
                item.tmdbDetails = md;
                item.docAsked = true;
                try { if (md.id && !md._src && !item.i18n && !md.__i18nFired) { md.__i18nFired = true; fillItemI18n(item, (item.category === 'movie' ? 'movie' : 'tv'), md.id); } } catch (e9) {}
                return true;
            } catch (e) { return false; }
        }
        function applySuggestMetadata(md) {
            if (!suggestState) return;
            if (suggestState.kind === 'tv' && suggestState.showKey) {
                const sk = suggestState.showKey;
                parsedItems.forEach(item => {
                    if (item.category === 'tv' && groupKeyOf(item) === sk) {
                        if (md) applyDocFields(item, md);
                        else { try { item.docAsked = true; } catch (e) {} }
                    }
                });
            } else if (suggestState.kind === 'movie' && suggestState.itemId) {
                const it = parsedItems.find(i => i.id === suggestState.itemId);
                if (it) {
                    if (md) applyDocFields(it, md);
                    else { try { it.docAsked = true; } catch (e2) {} }
                }
            }
            saveItemsToStorage();
        }
        function closeSuggestRunAction() {
            metadataModal.classList.add('hidden');
            metadataModal.classList.remove('flex');
            try { docSuggestNote.classList.add('hidden'); } catch (e) {}
            const act = pendingDocAction;
            suggestState = null;
            pendingDocAction = null;
            saveItemsToStorage();
            refreshApp();
            if (act) { try { act(); } catch (e) {} }
        }
        confirmAddBtn.addEventListener('click', async () => {
            if (suggestState) {
                const had = !!selectedMetadata;
                // التوثيق يعمل دائماً بلا بوابة رابط (حتى للرابط المكسور)
                applySuggestMetadata(selectedMetadata);
                closeSuggestRunAction();
                showStatus(had ? tLang('tDocOk') : tLang('tDocSkip'), had ? "success" : "info");
                return;
            }
            commitImportedItems(selectedMetadata);
        });
        cancelMetaBtn.addEventListener('click', () => {
            if (suggestState) {
                applySuggestMetadata(null);
                closeSuggestRunAction();
                return;
            }
            pendingRawItems = [];
            isReDocumenting = false;
            try { docSuggestNote.classList.add('hidden'); } catch (e) {}
            metadataModal.classList.add('hidden');
            metadataModal.classList.remove('flex');
        });

        // إعادة التوثيق اليدوي فقط (⋮ بحث وتوثيق).
        // الإصلاح الجذري: المطابقة بالمعرّف لا بمفتاح المجموعة — الفيلم لا يحمل
        // showKey/key فكانت المطابقة القديمة تفشل بصمت ولا يُطبَّق شيء.
        // (فيلم ⇒ نفس العنصر مع بوابة رابط؛ حلقة ⇒ كامل مسلسلها؛ مجلد ⇒ كامل المجلد)
        async function commitImportedItems(metadata) {
            if (!isReDocumenting) return;
            const ref = (pendingRawItems && pendingRawItems[0]) || {};
            let touched = 0;
            const applyShow = (gk) => {
                (parsedItems || []).forEach(item => {
                    if (item.category === 'tv' && groupKeyOf(item) === gk) {
                        if (metadata && applyDocFields(item, metadata)) touched++;
                    }
                });
            };
            const closeRedoc = (ok) => {
                try { saveItemsToStorage(); } catch (e) {}
                metadataModal.classList.add('hidden');
                metadataModal.classList.remove('flex');
                try { docSuggestNote.classList.add('hidden'); } catch (e) {}
                pendingRawItems = [];
                isReDocumenting = false;
                try { refreshApp(); } catch (e) {}
                try { showStatus(ok ? tLang('tRedocOk') : tLang('redocNone'), ok ? "success" : "error"); } catch (e2) {}
            };
            if (ref.id) {
                const target = (parsedItems || []).find(i => i.id === ref.id);
                if (target && metadata) {
                    if (target.category === 'movie') {
                        // التوثيق يعمل دائماً بلا بوابة رابط (حتى للمكسور)
                        if (applyDocFields(target, metadata)) touched = 1;
                    } else if (target.category === 'tv') {
                        applyShow(groupKeyOf(target));
                    }
                }
            } else {
                const wantKey = ref.showKey || ref.key || "";
                if (wantKey) {
                    (parsedItems || []).forEach(item => {
                        if (item.category === currentCategory && groupKeyOf(item) === wantKey) {
                            if (metadata && applyDocFields(item, metadata)) touched++;
                        }
                    });
                }
            }
            // المسلسلات: حدّث حالة روابط الحلقات الناقصة (للتعليم) بلا حجب
            if (touched > 0 && ref && ref.id !== undefined) {
                try {
                    const gk = ref.id ? groupKeyOf((parsedItems || []).find(i => i.id === ref.id) || {}) : (ref.showKey || ref.key || '');
                    if (gk) {
                        const missing = (parsedItems || []).filter(i => i && i.category === 'tv' && groupKeyOf(i) === gk && !i.linkState && i.url);
                        if (missing.length) {
                            let mi = 0;
                            const mw = async () => { while (mi < missing.length) { const e2 = missing[mi++]; try { await ensureLinkState(e2, 6000); } catch (e3) {} } };
                            try { await Promise.all([mw(), mw(), mw()]); } catch (e4) {}
                            try { if (typeof invalidateDeadSeasonCache === 'function') invalidateDeadSeasonCache(); } catch (e5) {}
                        }
                    }
                } catch (e) {}
            }
            closeRedoc(touched > 0);
        }

        // الإضافة المباشرة من ديالوغ الاختيار: الفئة محددة لكل عنصر من قسمه (والمشبوهة من منسدلتها)
        function commitImportSelection() {
            try { importAbort = true; } catch (e) {}
            try { if (typeof stopSmartSweep === 'function') stopSmartSweep(); } catch (e) {}
            const sel = new Set(importSelected);
            // المشبوهة: أي رابط محدد ما زالت فئته 'غير محدد' ⇒ رفض التأكيد
            // وإجبار المستخدم على اختيار فئة من الثلاثة أولاً (تُبرز قوائمه)
            try {
                const badSus = ((typeof importGroups !== 'undefined' && importGroups && importGroups.sus) || []).filter(it => it && sel.has(it.id) && ((typeof importCatById !== 'undefined' && importCatById.get(it.id)) || 'none') === 'none');
                if (badSus.length) {
                    showStatus(tLang('impForceCat'), "error");
                    try {
                        badSus.forEach(it => {
                            const s = document.querySelector('#impSusList select[data-imp-catchange="' + it.id + '"]');
                            if (s) { s.classList.add('ring-2', 'ring-rose-500'); try { s.focus({ preventScroll: true }); } catch (e2) {} setTimeout(() => { try { s.classList.remove('ring-2', 'ring-rose-500'); } catch (e3) {} }, 3000); }
                        });
                    } catch (e) {}
                    return;
                }
            } catch (e) {}
            const items = (pendingRawItems || []).filter(i => sel.has(i.id));
            if (!items.length) {
                showStatus(tLang('tPickOne'), "error");
                return;
            }
            const prepared = items.map(item => {
                const cat = importCatById.get(item.id) || 'movie';
                const updated = { ...item, category: cat };
                if (cat === 'live') {
                    // المباشر استثناء: الاسم الفعلي من ملف M3U فقط، بلا استخراج من الرابط ولا parser
                    const liveName = String(item.rawTitle || '').replace(/^-1,?\s*/, '').trim() || item.url;
                    updated.cleanTitle = liveName;
                    updated.parsedShowTitle = liveName;
                    updated.showKey = normalizeShowKey(liveName) || ('live_' + updated.id);
                    updated.episodeTitle = liveName;
                    updated.seasonNumber = 1;
                    updated.episodeNumber = 1;
                    updated.year = '';
                    updated.resolution = '';
                    updated.quality = '';
                    updated.codec = '';
                    updated.group = '';
                    updated.audio = '';
                    updated.languages = [];
                    updated.hdr = '';
                    updated.edition = '';
                }
                if (!updated.poster) updated.poster = generateSvgAvatar(updated.cleanTitle);
                return updated;
            });
            // دمج تلقائي: حلقات تنتمي لمسلسل موثق ترث بياناته (بدل ديالوغ الدمج القديم)
            const docByShow = new Map();
            parsedItems.forEach(p => {
                if (p.category === 'tv' && p.tmdbDetails) {
                    const k = groupKeyOf(p);
                    if (!docByShow.has(k)) docByShow.set(k, p);
                }
            });
            prepared.forEach(u => {
                if (u.category === 'tv') {
                    const d = docByShow.get(u.showKey || groupKeyOf(u));
                    if (d) {
                        u.poster = d.poster || u.poster;
                        u.overview = d.overview || u.overview;
                        u.metaTitle = d.metaTitle || u.metaTitle;
                        u.year = d.year || u.year;
                        u.rating = d.rating || u.rating;
                        u.genres = d.genres || u.genres;
                        u.tmdbDetails = d.tmdbDetails || null;
                        try { if (!u.i18n && d.i18n) u.i18n = d.i18n; } catch (e9) {}
                    }
                }
                // الجديد غير الموثّق يُقترح توثيقه مرة واحدة عند أول ضغطة
                if (!isItemDocumented(u) && u.docAsked === undefined) u.docAsked = false;
            });
            // منع التكرار على مستوى الفئة: نفس الرابط يُتجاوز، ونفس الهوية برابط مختلف → حوار الروابط
            let addedCount = 0;
            let skippedCount = 0;
            const urlsByCat = { tv: new Set(), movie: new Set(), live: new Set() };
            parsedItems.forEach(p => { if (urlsByCat[p.category]) urlsByCat[p.category].add(String(p.url || '').trim()); });
            const toAdd = [];
            const linkConflicts = [];
            prepared.forEach(updated => {
                const cat = updated.category;
                const url = String(updated.url || '').trim();
                if (urlsByCat[cat] && urlsByCat[cat].has(url)) { skippedCount++; return; }
                const ident = identityOf(updated);
                if (toAdd.some(u => identityOf(u) === ident)) { skippedCount++; return; }
                const already = parsedItems.find(p => p.category === cat && identityOf(p) === ident);
                if (already) { linkConflicts.push({ existing: already, updated }); return; }
                toAdd.push(updated);
                if (urlsByCat[cat]) urlsByCat[cat].add(url);
            });
            if (linkConflicts.length > 0) {
                pendingLinksState = { conflicts: linkConflicts, toAdd, skippedCount };
                renderUpdateLinksDialog(linkConflicts);
                importSelectModal.classList.add('hidden');
                importSelectModal.classList.remove('flex');
                updateLinksModal.classList.remove('hidden');
                updateLinksModal.classList.add('flex');
                return;
            }
            toAdd.forEach(u => { parsedItems.push(u); addedCount++; });
            try { if (typeof maybeAutoDoc === 'function') maybeAutoDoc(toAdd.slice()); } catch (e) {}
            importSelectModal.classList.add('hidden');
            importSelectModal.classList.remove('flex');
            finishCommit(addedCount, skippedCount, 0);
        }

        // ===== التوثيق التلقائي للجديد (مفعّل افتراضياً): مطابقة ذكية بثلاث عزلات (اسم فسنة فمتوسط دقائق) =====
        // تعريف "الموثّق": توثيق TMDB، أو (عنوان موثق + وصف حقيقي غير الافتراضي + تقييم/نوع).
        // أي عنصر بلا وصف غير الافتراضي وبلا معطيات توثيق كاملة ⇒ غير موثق ويُعاد توثيقه.
        function isItemDocumented(it) {
            try {
                if (!it) return false;
                if (it.tmdbDetails) return true;
                const noD = (typeof tLang === 'function') ? String(tLang('noDescItem')) : '';
                const ov = String(it.overview || '').trim();
                if (it.metaTitle && ov && ov !== noD.trim() && (it.rating || it.genres)) return true;
            } catch (e) {}
            return false;
        }
        var autoDocOn = false;
        try { autoDocOn = localStorage.getItem('streamit_autodoc_v1') !== '0'; } catch (e) {}
        function isAutoDocOn() { return !!autoDocOn; }
        function setAutoDocOn(v) {
            autoDocOn = !!v;
            try { localStorage.setItem('streamit_autodoc_v1', autoDocOn ? '1' : '0'); } catch (e) {}
            try { const _t0 = document.getElementById('autoDocToggle'); if (_t0) _t0.checked = autoDocOn; } catch (e) {}
            try { saveItemsToStorage(); } catch (e) {}
        }
        // فحص الاستيراد: استخراج المدد (افتراضياً ON) + فحص القوائم داخل المكسور (افتراضياً OFF)
        var impDurOn = true;
        try { impDurOn = localStorage.getItem('streamit_impdur_v1') !== '0'; } catch (e) {}
        var impPlOn = false;
        try { impPlOn = localStorage.getItem('streamit_imppl_v1') === '1'; } catch (e) {}
        function isImpDurOn() { return !!impDurOn; }
        function isImpPlOn() { return !!impPlOn; }
        function setImpDurOn(v) {
            impDurOn = !!v;
            try { localStorage.setItem('streamit_impdur_v1', impDurOn ? '1' : '0'); } catch (e) {}
            try { const _t = document.getElementById('impDurToggle'); if (_t) _t.checked = impDurOn; } catch (e) {}
            try { saveItemsToStorage(); } catch (e) {}
        }
        function setImpPlOn(v) {
            impPlOn = !!v;
            try { localStorage.setItem('streamit_imppl_v1', impPlOn ? '1' : '0'); } catch (e) {}
            try { const _t = document.getElementById('impPlToggle'); if (_t) _t.checked = impPlOn; } catch (e) {}
            try { saveItemsToStorage(); } catch (e) {}
        }
        // الفحص الذكي اللحظي بعد فتح ديالوغ الاستيراد (افتراضياً ON):
        // فحص عمل الروابط + فحص نوع المحتوى — يحدّث الشارات والتحديد أولاً بأول.
        var smartAliveOn = true;
        try { smartAliveOn = localStorage.getItem('streamit_smartalive_v1') !== '0'; } catch (e) {}
        var smartKindOn = true;
        try { smartKindOn = localStorage.getItem('streamit_smartkind_v1') !== '0'; } catch (e) {}
        function isSmartAliveOn() { return !!smartAliveOn; }
        function isSmartKindOn() { return !!smartKindOn; }
        function setSmartAliveOn(v) {
            smartAliveOn = !!v;
            try { localStorage.setItem('streamit_smartalive_v1', smartAliveOn ? '1' : '0'); } catch (e) {}
            try { const _t = document.getElementById('smartAliveToggle'); if (_t) _t.checked = smartAliveOn; } catch (e) {}
            try { saveItemsToStorage(); } catch (e) {}
        }
        function setSmartKindOn(v) {
            smartKindOn = !!v;
            try { localStorage.setItem('streamit_smartkind_v1', smartKindOn ? '1' : '0'); } catch (e) {}
            try { const _t = document.getElementById('smartKindToggle'); if (_t) _t.checked = smartKindOn; } catch (e) {}
            try { saveItemsToStorage(); } catch (e) {}
        }
        // ===== صحة الروابط: فحص الحالة وتخزينها على العنصر (ok/dead/unknown) =====
        // تُعاد القراءة المخزنة إن كانت حديثة (7 أيام)؛ أي محاولة توثيق تفحص أولاً.
        async function ensureLinkState(item, ms) {
            try {
                if (!item || !item.url) return 'unknown';
                if ((item.linkState === 'ok' || item.linkState === 'dead') && item.linkCheckedAt && (Date.now() - item.linkCheckedAt < 7 * 864e5)) return item.linkState;
                let h = null;
                try { h = await probeLinkFull(item.url, ms || 8000); } catch (e) { h = null; }
                if (h) {
                    try {
                        item.linkState = h.state;
                        item.linkCheckedAt = Date.now();
                        if (h.minutes != null && isFinite(+h.minutes) && item.durationMin == null) item.durationMin = Math.round(+h.minutes * 10) / 10;
                    } catch (e) {}
                    try { saveItemsToStorage(); } catch (e) {}
                    return h.state;
                }
            } catch (e) {}
            return 'unknown';
        }
        // (زر فحص يدوي لا يوجد — الفحص تلقائي: عند الاستيراد المرحلي،
        // وعند التوثيق التلقائي (للمدد والشارات فقط، بلا حجب) — عبر ensureLinkState أدناه.)
        async function tmdbSearchTop(query, type) {
            const out = [];
            try {
                const apiKey = tmdbEffectiveKey();
                const lang = (typeof tmdbLang === 'function' ? tmdbLang() : 'en-US');
                const r = await fetch('https://api.themoviedb.org/3/search/' + type + '?api_key=' + apiKey + '&query=' + encodeURIComponent(query) + '&language=' + lang + '&include_adult=false');
                if (!r.ok) return out;
                const data = await r.json();
                const list = (data && data.results ? data.results.slice(0, 5) : []);
                for (const it of list) {
                    try {
                        const dr = await fetch('https://api.themoviedb.org/3/' + type + '/' + it.id + '?api_key=' + apiKey + '&language=' + lang);
                        let d = it;
                        if (dr.ok) d = await dr.json();
                        if (!d.overview && lang !== 'en-US') {
                            try {
                                const er = await fetch('https://api.themoviedb.org/3/' + type + '/' + it.id + '?api_key=' + apiKey + '&language=en-US');
                                if (er.ok) { const ed = await er.json(); if (ed && ed.overview && !d.overview) d.overview = ed.overview; }
                            } catch (e2) {}
                        }
                        let rt = 0;
                        if (type === 'movie' && d.runtime) rt = d.runtime;
                        else if (type === 'tv' && d.episode_run_time && d.episode_run_time.length) rt = d.episode_run_time[0];
                        out.push({ id: d.id, title: d.title || d.name || d.original_title || tLang('tUnknownTitle'), originalTitle: d.original_title || d.original_name || '', year: (d.release_date || d.first_air_date || '').substring(0, 4), poster: d.poster_path ? ('https://image.tmdb.org/t/p/w500' + d.poster_path) : generateSvgAvatar(d.title || d.name || 'M'), backdrop: d.backdrop_path ? ('https://image.tmdb.org/t/p/w1280' + d.backdrop_path) : '', overview: d.overview || tLang('noDescItem'), rating: d.vote_average ? d.vote_average.toFixed(1) : 'N/A', genres: (d.genres && d.genres.length) ? d.genres.map(g => g.name).join(appLang === 'ar' ? '، ' : ', ') : '', status: d.status || '', runtimeMin: rt || 0, runtimes: ((type === 'tv' && d.episode_run_time && d.episode_run_time.length) ? d.episode_run_time.slice() : ((type === 'movie' && d.runtime) ? [d.runtime] : [])) });
                    } catch (e) {}
                }
            } catch (e) {}
            return out;
        }
        function autoDocTokens(s2) {
            return String(s2 || '').toLowerCase().replace(/[^a-z0-9 \u0600-\u06ff \u4e00-\u9fff \u0900-\u097f \s]/gi, ' ').split(/\s+/).filter(w => w.length > 1);
        }
        function autoDocYearOf(y) { const m = String(y || '').match(/(\d{4})/); return m ? parseInt(m[1], 10) : 0; }
        // مطابقة ذكية بثلاث عزلات: (1) الاسم أولاً، (2) سنة الإصدار إن توفرت، (3) متوسط الدقائق العادل
        // (للأفلام: مدة الفلم مقابل runtime؛ للمسلسلات: متوسط دقائق الحلقات المتوفرة مقابل متوسط episode_run_time)
        function pickBestAutoDoc(cands, name, probeMin, opts) {
            if (!cands || !cands.length) return null;
            opts = opts || {};
            const nt = autoDocTokens(extractCleanQueryName(name));
            const localYear = autoDocYearOf(opts.year);
            function candRt(c) {
                try {
                    const arr = (c.runtimes && c.runtimes.length) ? c.runtimes : ((c.runtimeMin) ? [c.runtimeMin] : []);
                    if (!arr.length) return 0;
                    let s = 0; for (let i = 0; i < arr.length; i++) s += (+arr[i] || 0);
                    return s / arr.length;
                } catch (e) { return 0; }
            }
            let probeMean = 0, probeN = 0;
            try {
                if (opts.probes && opts.probes.length) { let s = 0, n = 0; opts.probes.forEach(p => { p = +p; if (p > 0) { s += p; n++; } }); if (n) { probeMean = s / n; probeN = n; } }
                else if (probeMin) { probeMean = +probeMin; probeN = 1; }
            } catch (e) {}
            const scored = [];
            cands.forEach(c => {
                const ct = autoDocTokens(c.title + ' ' + (c.originalTitle || ''));
                const set = {};
                nt.forEach(w => { set[w] = true; });
                let hit = 0;
                ct.forEach(w => { if (set[w]) hit++; });
                const denom = Math.max(nt.length, ct.length, 1);
                const nameScore = hit / denom;
                if (nameScore < 0.34) return;
                let yearScore = 0, yearDrop = false;
                const cy = autoDocYearOf(c.year);
                if (localYear && cy) {
                    const dy = Math.abs(cy - localYear);
                    if (dy === 0) yearScore = 0.35;
                    else if (dy === 1) yearScore = 0.1;
                    else if (dy > 2) yearDrop = true;
                    else yearScore = -0.15;
                }
                if (yearDrop) return;
                let rtScore = 0;
                const cr = candRt(c);
                if (probeMean > 0 && cr > 0) {
                    const diff = Math.abs(cr - probeMean);
                    const wgt = (probeN >= 3 || opts.kind === 'movie') ? 1 : 0.6;
                    if (diff <= 5) rtScore = 0.5 * wgt;
                    else if (diff <= 12) rtScore = 0.25 * wgt;
                    else if (diff <= 25) rtScore = 0.1 * wgt;
                    else rtScore = -0.2;
                }
                scored.push({ c: c, total: nameScore + yearScore + rtScore });
            });
            if (!scored.length) return null;
            scored.sort((a, b) => b.total - a.total);
            const top = scored[0];
            if (!top || top.total < 0.34) return null;
            return top.c;
        }
        let __autoDocRunning = false;
        async function maybeAutoDoc(added) {
            if (!isAutoDocOn() || __autoDocRunning) return;
            // لا يمس الموثقة فعلاً (توثيق أو عنوان موثق + وصف حقيقي + معطيات كاملة).
            // المسلسلات والأفلام توثق مهما كانت حالة الرابط.
            const fresh = (added || []).filter(u => u && (u.category === 'movie' || u.category === 'tv') && !isItemDocumented(u));
            if (!fresh.length) return;
            __autoDocRunning = true;
            try { showStatus(tLang('tAutoStart'), "info"); } catch (e) {}
            let done = 0, touched = false;
            try {
                const movies = fresh.filter(u => u.category === 'movie');
                for (const m of movies) {
                    try {
                        const q = extractCleanQueryName(m.cleanTitle || m.rawTitle || m.url);
                        if (!q) { m.docAsked = true; touched = true; continue; }
                        // التوثيق يعمل دائماً بلا حجب (نقرأ الحالة للمدد والشارات فقط)
                        try { await ensureLinkState(m, 8000); } catch (e) {}
                        const probe = (m.durationMin != null && isFinite(+m.durationMin)) ? +m.durationMin : null;
                        // الأولوية لميتا Stremio — وTMDB احتياط فقط
                        let cands = [];
                        try { if (typeof stremioMetaSearch === 'function') cands = await stremioMetaSearch(q, 'movie'); } catch (e) {}
                        if (!cands.length) { try { cands = await tmdbSearchTop(q, 'movie'); } catch (e) {} }
                        const best = pickBestAutoDoc(cands, q, probe, { year: (m.year || ''), kind: 'movie' });
                        if (best) {
                            m.poster = best.poster; m.overview = best.overview; m.metaTitle = best.title; m.year = best.year || m.year; m.rating = best.rating; m.genres = best.genres; m.tmdbDetails = best;
                            try { if (best.id && !best._src && !m.i18n && !best.__i18nFired) { best.__i18nFired = true; fillItemI18n(m, 'movie', best.id); } } catch (e9) {}
                            done++;
                        }
                        m.docAsked = true; touched = true;
                    } catch (e) { try { m.docAsked = true; touched = true; } catch (e2) {} }
                }
                const tvFresh = fresh.filter(u => u.category === 'tv');
                const byShow = {};
                tvFresh.forEach(u => { const k = groupKeyOf(u); if (!byShow[k]) byShow[k] = []; byShow[k].push(u); });
                const skeys = Object.keys(byShow);
                for (const k of skeys) {
                    try {
                        const eps = byShow[k];
                        const rep2 = eps[0];
                        const q = extractCleanQueryName(rep2.parsedShowTitle || rep2.cleanTitle || '');
                        if (!q) { eps.forEach(x => { x.docAsked = true; }); touched = true; continue; }
                        // فحص روابط الحلقات (لمن حالته غير معروفة فقط): مدد للمطابقة + تعليم المكسور
                        const probes = [];
                        for (const ep of eps.slice(0, 3)) {
                            try {
                                const st2 = await ensureLinkState(ep, 7000);
                                if (st2 !== 'dead' && ep.durationMin != null && isFinite(+ep.durationMin)) probes.push(+ep.durationMin);
                            } catch (e) {}
                        }
                        probes.sort((a2, b2) => a2 - b2);
                        const med = probes.length ? probes[Math.floor(probes.length / 2)] : null;
                        // الأولوية لميتا Stremio — وTMDB احتياط فقط
                        let cands = [];
                        try { if (typeof stremioMetaSearch === 'function') cands = await stremioMetaSearch(q, 'series'); } catch (e) {}
                        if (!cands.length) { try { cands = await tmdbSearchTop(q, 'tv'); } catch (e) {} }
                        const best = pickBestAutoDoc(cands, q, med, { year: (rep2.year || ''), probes: probes, kind: 'tv' });
                        if (best) {
                            eps.forEach(x => { x.poster = best.poster; x.overview = best.overview; x.metaTitle = best.title; x.year = best.year || x.year; x.rating = best.rating; x.genres = best.genres; x.tmdbDetails = best; if (med) { try { x.durationMin = Math.round(med); } catch (e) {} } x.docAsked = true; });
                            try { if (best.id && !best._src && !best.__i18nFired) { best.__i18nFired = true; try { fillItemI18n(eps[0], 'tv', best.id); } catch (e9) {} } } catch (e8) {}
                            done++;
                        } else {
                            eps.forEach(x => { if (med && !x.durationMin) { try { x.durationMin = Math.round(med); } catch (e) {} } x.docAsked = true; });
                        }
                        touched = true;
                    } catch (e) { try { byShow[k].forEach(x => { x.docAsked = true; }); touched = true; } catch (e2) {} }
                }
            } catch (e) {}
            __autoDocRunning = false;
            try { if (touched) saveItemsToStorage(); refreshApp(); if (done > 0) showStatus(tLang('tAutoDone').replace('{n}', done), "success"); } catch (e) {}
        }
        function escHtml(s2) {
            return String(s2 == null ? '' : s2).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }
        var TMDB_LANGS = [['en', 'en-US'], ['ar', 'ar-SA'], ['zh', 'zh-CN'], ['hi', 'hi-IN']];
        async function fetchLocaleDocs(type, id) {
            const out = {};
            try {
                const apiKey = tmdbEffectiveKey();
                const jobs = TMDB_LANGS.map(function (pair) {
                    const k = pair[0], lang = pair[1];
                    return fetch('https://api.themoviedb.org/3/' + type + '/' + id + '?api_key=' + apiKey + '&language=' + lang).then(function (r) {
                        if (!r.ok) return;
                        return r.json().then(function (d) {
                            if (!d) return;
                            out[k] = { title: d.title || d.name || d.original_title || '', overview: d.overview || '', genres: (d.genres && d.genres.length) ? d.genres.map(function (g) { return g.name; }) : [] };
                        });
                    }).catch(function () {});
                });
                await Promise.all(jobs);
            } catch (e) {}
            return out;
        }
        function fillItemI18n(item, type, id) {
            try {
                fetchLocaleDocs(type, id).then(function (loc) {
                    if (!loc || !Object.keys(loc).length) return;
                    try { item.i18n = loc; } catch (e) {}
                    try { saveItemsToStorage(); refreshApp(); } catch (e) {}
                }).catch(function () {});
            } catch (e) {}
        }
        function locTitleOf(item) {
            try {
                const g = item && item.i18n;
                if (g) {
                    if (g[appLang] && g[appLang].title) return g[appLang].title;
                    if (g.en && g.en.title) return g.en.title;
                    const ks = Object.keys(g);
                    for (let qi = 0; qi < ks.length; qi++) { if (g[ks[qi]] && g[ks[qi]].title) return g[ks[qi]].title; }
                }
            } catch (e) {}
            return null;
        }
        function locDoc(item) {
            try {
                const g = (item && item.i18n) || null;
                if (g) {
                    const order = [appLang, 'en', 'ar', 'zh', 'hi'];
                    for (let oi = 0; oi < order.length; oi++) {
                        const d = g[order[oi]];
                        if (d && (d.title || d.overview || (d.genres && d.genres.length))) {
                            return { title: d.title || (item.metaTitle || ''), overview: d.overview || (item.overview || ''), genres: (d.genres && d.genres.length) ? d.genres : (item.genres || '') };
                        }
                    }
                }
            } catch (e) {}
            try {
                return { title: ((item && (item.metaTitle || '')) || ''), overview: ((item && (item.overview || (item.tmdbDetails ? item.tmdbDetails.overview : '') || '')) || ''), genres: ((item && (item.genres || (item.tmdbDetails ? item.tmdbDetails.genres : '') || '')) || '') };
            } catch (e) { return { title: '', overview: '', genres: '' }; }
        }
        function genresText(g) {
            try {
                if (!g) return '';
                if (Array.isArray(g)) return g.join(appLang === 'ar' ? '، ' : ', ');
                return String(g);
            } catch (e) { return ''; }
        }
        function showLoc(show) {
            try { return locDoc({ i18n: show.i18n || null, metaTitle: show.title || '', overview: show.overview || '', genres: show.genres || '' }); }
            catch (e) { return { title: show.title, overview: show.overview, genres: show.genres }; }
        }
        function showDisplayTitle(showKey, fallback) {
            try {
                const list = parsedItems || [];
                for (let si = 0; si < list.length; si++) {
                    const it = list[si];
                    if (it && it.category === 'tv' && groupKeyOf(it) === showKey) return dispName(it) || fallback;
                }
            } catch (e) {}
            return fallback;
        }
        function finishCommit(addedCount, skippedCount, updatedLinks, copiesCount) {
            updateLinksModal.classList.add('hidden');
            updateLinksModal.classList.remove('flex');
            metadataModal.classList.add('hidden');
            metadataModal.classList.remove('flex');
            try { importSelectModal.classList.add('hidden'); importSelectModal.classList.remove('flex'); } catch (e) {}
            pendingRawItems = [];
            pendingLinksState = null;
            importSelected = new Set();
            importGroups = null;
            navState = { level: 1, showTitle: null, showKey: null, seasonNumber: null };
            inSelectionMode = false; selectedKeys.clear();
            disarmDeleteBtn();
            refreshApp();

            // كتابة فورية موثقة قبل إعلان النجاح — حتى لا تختفي العناصر عند التحديث أبداً
            flushSave().then(ok => {
                let msg = tLang('tAdded').replace('{n}', addedCount);
                if (updatedLinks > 0) msg += ' (' + tLang('tUpdLinks').replace('{n}', updatedLinks) + ')';
                if (skippedCount > 0) msg += ' (' + tLang('tSkipped').replace('{n}', skippedCount) + ')';
                if (copiesCount > 0) msg += ' (' + tLang('tCopies').replace('{n}', copiesCount) + ')';
                if (!ok) msg += ' — ' + tLang('tSaveWarn');
                showStatus(msg, !ok ? "error" : ((addedCount > 0 || updatedLinks > 0) ? "success" : "info"));
            });
        }

        function renderUpdateLinksDialog(conflicts) {
            updateLinksList.innerHTML = '';
            conflicts.forEach(c => {
                const row = document.createElement('div');
                row.className = "bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 flex flex-col gap-0.5";
                const nm = c.updated.parsedShowTitle || c.updated.cleanTitle || '';
                const se = c.updated.category === 'tv' ? (' <span class="text-slate-500">S' + (c.updated.seasonNumber || 1) + 'E' + (c.updated.episodeNumber || 1) + '</span>') : '';
                row.innerHTML = '<div class="font-bold text-slate-100">' + String(nm).replace(/</g, '&lt;') + se + '</div>'
                    + '<div class="text-[10px] text-slate-500 break-all dir-ltr text-left">' + tLang('tOld') + String(c.existing.url).replace(/</g, '&lt;') + '</div>'
                    + '<div class="text-[10px] text-emerald-400/80 break-all dir-ltr text-left">' + tLang('tNew') + String(c.updated.url).replace(/</g, '&lt;') + '</div>';
                updateLinksList.appendChild(row);
            });
        }


