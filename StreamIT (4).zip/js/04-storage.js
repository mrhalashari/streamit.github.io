        // ===== StreamIT Storage Engine: IndexedDB (أساسي، سعة كبيرة) + مرآة localStorage =====
        // سبب المشكلة القديمة: قوائم المزودين تحوي آلاف العناصر مع صور data:URL مولّدة
        // فيتجاوز الحفظ حد localStorage (~5MB) ويفشل بصمت، ثم يخفي finishCommit رسالة
        // الخطأ برسالة نجاح — فتختفي العناصر عند التحديث. هذا المحرك يصلح ذلك جذرياً:
        // (1) لا يخزّن الصور المولّدة (يعيد توليدها حتمياً عند الإقلاع)، (2) IndexedDB
        // بسعة عشرات الميجابايت مع تحقق قراءة-بعد-كتابة، (3) مرآة localStorage فورية
        // للحماية من التحديث السريع، (4) إظهار تحذير صريح عند فشل الحفظ الدائم.
        const IDB_NAME = 'streamit_db_v1';
        const IDB_STORE = 'kv';
        const IDB_ITEMS_KEY = 'library';
        let idbDb = null;
        let storageBackend = 'memory';
        let saveTimer = null;
        let saveChain = Promise.resolve();
        let bootClean = true;
        var bootStoreReady = false; // يبقى صحيحاً حتى أول حفظ بعد الإقلاع (لأمان المحاولة الخلفية)
        function withTimeout(promise, ms, msg) {
            return Promise.race([promise, new Promise((_, rej) => setTimeout(() => rej(new Error(msg || 'timeout')), ms))]);
        }

        function idbOpen() {
            if (idbDb) return Promise.resolve(idbDb);
            return new Promise((resolve, reject) => {
                try {
                    if (!('indexedDB' in window)) { reject(new Error('no-idb')); return; }
                    const rq = indexedDB.open(IDB_NAME, 1);
                    rq.onupgradeneeded = () => { try { rq.result.createObjectStore(IDB_STORE); } catch (e) {} };
                    rq.onsuccess = () => { idbDb = rq.result; resolve(idbDb); };
                    rq.onerror = () => reject(rq.error || new Error('idb-open'));
                    rq.onblocked = () => reject(new Error('idb-blocked'));
                } catch (e) { reject(e); }
            });
        }
        function idbGet(key) {
            return idbOpen().then(db => new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(IDB_STORE, 'readonly');
                    const rq = tx.objectStore(IDB_STORE).get(key);
                    rq.onsuccess = () => resolve(rq.result || null);
                    rq.onerror = () => reject(rq.error || new Error('idb-get'));
                } catch (e) { reject(e); }
            }));
        }
        function idbSet(key, val) {
            return idbOpen().then(db => new Promise((resolve, reject) => {
                try {
                    const tx = db.transaction(IDB_STORE, 'readwrite');
                    tx.objectStore(IDB_STORE).put(val, key);
                    tx.oncomplete = () => resolve(true);
                    tx.onerror = () => reject(tx.error || new Error('idb-put'));
                    tx.onabort = () => reject(tx.error || new Error('idb-abort'));
                } catch (e) { reject(e); }
            }));
        }
        function stripVolatilePosters(items) {
            return (items || []).map(it => {
                if (it && typeof it.poster === 'string' && it.poster.startsWith('data:image/svg+xml')) {
                    const cp = { ...it };
                    delete cp.poster;
                    return cp;
                }
                return it;
            });
        }
        function rehydrateAvatars(items) {
            (items || []).forEach(it => { if (it && !it.poster) { try { it.poster = generateSvgAvatar(it.cleanTitle); } catch (e) {} } });
            return items || [];
        }
        function readLocalEnvelope() {
            try {
                const raw = localStorage.getItem(STORAGE_KEY);
                if (!raw) return null;
                const data = JSON.parse(raw);
                if (Array.isArray(data)) return { ts: 0, items: data, lastWatched: null, settings: null };
                if (data && Array.isArray(data.items)) return { ts: data.ts || 0, items: data.items, lastWatched: data.lastWatched || null, settings: data.settings || null };
            } catch (e) {}
            return null;
        }
        function writeLocalMirror(items, lw) {
            try {
                let _lg = 'en'; try { _lg = (typeof appLang !== 'undefined' ? appLang : (localStorage.getItem(LANG_KEY) || 'en')); } catch (e) {}
                localStorage.setItem(STORAGE_KEY, JSON.stringify({ v: 1, ts: Date.now(), items: stripVolatilePosters(items), lastWatched: lw || null, settings: { lang: _lg, autoDoc: isAutoDocOn(), impDur: (typeof isImpDurOn === 'function' ? isImpDurOn() : true), impPl: (typeof isImpPlOn === 'function' ? isImpPlOn() : false), smartAlive: (typeof isSmartAliveOn === 'function' ? isSmartAliveOn() : true), smartKind: (typeof isSmartKindOn === 'function' ? isSmartKindOn() : true), stremio: (typeof stremioAddons !== 'undefined' ? stremioAddons : []) } }));
                return true;
            } catch (e) { return false; }
        }
        async function writeVerifiedToIdb(items, lw) {
            let _lg2 = 'en'; try { _lg2 = (typeof appLang !== 'undefined' ? appLang : (localStorage.getItem(LANG_KEY) || 'en')); } catch (e) {}
            const payload = { v: 1, ts: Date.now(), items: stripVolatilePosters(items), lastWatched: lw || null, settings: { lang: _lg2, autoDoc: isAutoDocOn(), impDur: (typeof isImpDurOn === 'function' ? isImpDurOn() : true), impPl: (typeof isImpPlOn === 'function' ? isImpPlOn() : false), smartAlive: (typeof isSmartAliveOn === 'function' ? isSmartAliveOn() : true), smartKind: (typeof isSmartKindOn === 'function' ? isSmartKindOn() : true), stremio: (typeof stremioAddons !== 'undefined' ? stremioAddons : []) } };
            await idbSet(IDB_ITEMS_KEY, payload);
            const back = await idbGet(IDB_ITEMS_KEY);
            if (!back || !Array.isArray(back.items) || back.items.length !== items.length) throw new Error('idb-verify');
            return true;
        }
        function loadSavedItems() {
            const env = readLocalEnvelope();
            if (!env) return [];
            const items = rehydrateAvatars(env.items);
            items.forEach(it => { if (it && it.category === 'live') it.watchedAt = 0; });
            return items;
        }
        function saveItemsToStorage() {
            try { if (!bootStoreReady) return true; } catch (e) {}
            bootClean = false;
            writeLocalMirror(parsedItems, lastWatched);
            clearTimeout(saveTimer);
            saveTimer = setTimeout(() => { saveChain = saveChain.then(() => persistNow()).catch(() => {}); }, 300);
            return true;
        }
        async function persistNow() {
            clearTimeout(saveTimer);
            bootClean = false;
            try {
                await withTimeout(writeVerifiedToIdb(parsedItems, lastWatched), 8000, 'idb-write-timeout');
                storageBackend = 'indexeddb';
                window.__storageBackend = storageBackend;
                return true;
            } catch (e) {
                const okMirror = writeLocalMirror(parsedItems, lastWatched);
                storageBackend = okMirror ? 'localstorage' : 'memory';
                window.__storageBackend = storageBackend;
                return okMirror;
            }
        }
        function flushSave() {
            saveChain = saveChain.then(() => persistNow()).catch(() => false);
            return saveChain;
        }
        // ===== حالة الواجهة في IndexedDB (مفتاح مستقل خفيف حتى لا نعيد كتابة المكتبة مع كل حرف بحث) =====
        let uiIdbTimer = null;
        function queueUiIdbSave() {
            try {
                clearTimeout(uiIdbTimer);
                uiIdbTimer = setTimeout(() => {
                    try {
                        const snap = getUiSnapshot();
                        writeLocalUiSync(snap);
                        withTimeout(idbSet(IDB_UI_KEY, snap), 8000, 'idb-ui-timeout').catch(() => {});
                    } catch (e) {}
                }, 600);
            } catch (e) {}
        }
        async function bootUiState() {
            let idbUi = null;
            try {
                const v = await withTimeout(idbGet(IDB_UI_KEY), 3000, 'idb-ui-boot-timeout');
                if (v && typeof v === 'object') idbUi = v;
            } catch (e) {}
            let lsUi = null;
            try { lsUi = readLocalUi(); } catch (e) {}
            const pick = (idbUi && lsUi) ? (((idbUi.ts || 0) >= (lsUi.ts || 0)) ? idbUi : lsUi) : (idbUi || lsUi);
            if (pick) {
                try { applyUiState(pick); window.__uiAppliedTs = pick.ts || Date.now(); } catch (e) {}
                try { writeLocalUiSync(pick); } catch (e) {}
                if (!idbUi || (lsUi && (lsUi.ts || 0) > (idbUi.ts || 0))) { try { await withTimeout(idbSet(IDB_UI_KEY, pick), 8000, 'idb-ui-migrate'); } catch (e) {} }
            }
            return pick;
        }
        async function bootStorage() {
            let idbEnv = null;
            try {
                const v = await withTimeout(idbGet(IDB_ITEMS_KEY), 3000, 'idb-boot-timeout');
                if (v && Array.isArray(v.items)) idbEnv = { ts: v.ts || 0, items: v.items, lastWatched: v.lastWatched || null, settings: v.settings || null };
            } catch (e) {}
            const lsEnv = readLocalEnvelope();
            const lsTs = lsEnv ? (lsEnv.ts || 0) : -1;
            const chosen = (idbEnv && lsEnv) ? ((idbEnv.ts >= lsEnv.ts) ? idbEnv : lsEnv) : (idbEnv || lsEnv);
            if (chosen) {
                parsedItems = rehydrateAvatars(chosen.items);
                try {
                    const _sl = chosen.settings && chosen.settings.lang;
                    if (_sl === 'en' || _sl === 'ar' || _sl === 'zh' || _sl === 'hi') { appLang = _sl; try { localStorage.setItem(LANG_KEY, _sl); } catch (e) {} try { applyI18n(); } catch (e) {} }
                try { const _ad = chosen.settings && chosen.settings.autoDoc; autoDocOn = (_ad === undefined || _ad === true || _ad === 1 || _ad === '1'); try { localStorage.setItem('streamit_autodoc_v1', autoDocOn ? '1' : '0'); } catch (e3) {} try { const _t = document.getElementById('autoDocToggle'); if (_t) _t.checked = autoDocOn; } catch (e2) {} } catch (e) {}
                try { const _id = chosen.settings && chosen.settings.impDur; impDurOn = (_id === undefined || _id === true || _id === 1 || _id === '1'); try { localStorage.setItem('streamit_impdur_v1', impDurOn ? '1' : '0'); } catch (e3) {} try { const _t = document.getElementById('impDurToggle'); if (_t) _t.checked = impDurOn; } catch (e2) {} } catch (e) {}
                try { const _ip = chosen.settings && chosen.settings.impPl; impPlOn = (_ip === true || _ip === 1 || _ip === '1'); try { localStorage.setItem('streamit_imppl_v1', impPlOn ? '1' : '0'); } catch (e3) {} try { const _t = document.getElementById('impPlToggle'); if (_t) _t.checked = impPlOn; } catch (e2) {} } catch (e) {}
                try { const _sa = chosen.settings && chosen.settings.smartAlive; smartAliveOn = (_sa === undefined || _sa === true || _sa === 1 || _sa === '1'); try { localStorage.setItem('streamit_smartalive_v1', smartAliveOn ? '1' : '0'); } catch (e3) {} try { const _t = document.getElementById('smartAliveToggle'); if (_t) _t.checked = smartAliveOn; } catch (e2) {} } catch (e) {}
                try { const _sk = chosen.settings && chosen.settings.smartKind; smartKindOn = (_sk === undefined || _sk === true || _sk === 1 || _sk === '1'); try { localStorage.setItem('streamit_smartkind_v1', smartKindOn ? '1' : '0'); } catch (e3) {} try { const _t = document.getElementById('smartKindToggle'); if (_t) _t.checked = smartKindOn; } catch (e2) {} } catch (e) {}
                try {
                    const _sa3 = chosen.settings && chosen.settings.stremio;
                    if (Array.isArray(_sa3) && _sa3.length) {
                        stremioAddons = _sa3.filter(x => x && x.base).map(x => ({ base: String(x.base), enabled: x.enabled !== false }));
                        try { localStorage.setItem('streamit_stremio_addons_v1', JSON.stringify(stremioAddons)); } catch (e3) {}
                    }
                } catch (e) {}
                } catch (e) {}
                // آخر مشاهدة: النسخة الأحدث (ضمن الظرف الفائز) هي المرجع دائماً — نزامن مفتاح المشاهدة معها
                if (chosen.lastWatched) {
                    try { localStorage.setItem(WATCH_KEY, JSON.stringify(chosen.lastWatched)); } catch (e) {}
                    try { lastWatched = loadLastWatched(); } catch (e) { lastWatched = chosen.lastWatched; }
                }
                // المباشر بلا حالة مشاهَدةة (عين) — تُصفَّر هنا؛ وعلامة "آخر مشاهدة" محفوظة بذاكرته
                let scrubbedLive = false;
                parsedItems.forEach(it => { if (it && it.category === 'live' && it.watchedAt) { it.watchedAt = 0; scrubbedLive = true; } });
                // علامة "آخر مشاهدة" للقناة (live) تُحفظ ولا تُمسح — فقط حالة العين تُصفَّر أعلاه
                if (scrubbedLive) saveItemsToStorage();
                storageBackend = idbEnv ? 'indexeddb' : 'localstorage';
                if (!idbEnv && chosen.items.length) {
                    try { await withTimeout(writeVerifiedToIdb(parsedItems, lastWatched), 8000, 'idb-migrate-timeout'); storageBackend = 'indexeddb'; } catch (e) {}
                }
            } else {
                parsedItems = [];
                storageBackend = 'memory';
            }
            try { bootStoreReady = true; } catch (e) {}
            // حالة الواجهة: الأحدث يفوز بين IndexedDB و localStorage، ثم نتحقق من صلاحية التنقل
            try { await bootUiState(); } catch (e) {}
            try {
                if (typeof pruneLastWatched === 'function') { if (pruneLastWatched()) saveItemsToStorage(); }
            } catch (e) {}
            try {
                if (navState.level !== 1) {
                    const nk = navState.showKey || '';
                    const okShow = (parsedItems || []).some(i => i.category === 'tv' && groupKeyOf(i) === nk);
                    if (!okShow) navState = { level: 1, showTitle: null, showKey: null, seasonNumber: null };
                    else if (navState.level === 3) {
                        const okSea = (parsedItems || []).some(i => i.category === 'tv' && groupKeyOf(i) === nk && (i.seasonNumber || 1) === navState.seasonNumber);
                        if (!okSea) { navState.level = 2; navState.seasonNumber = null; }
                    }
                }
            } catch (e) {}
            window.__storageReady = true;
            window.__storageBackend = storageBackend;
            // محاولة خلفية صامتة: إن تعذّر IndexedDB لحظة الإقلاع (بطء/قفل من تبويب آخر)،
            // نعيد المحاولة ونعتمد بياناته فقط إن كانت أحدث ولم يحدث أي حفظ بعد الإقلاع.
            if (!idbEnv) {
                withTimeout(idbGet(IDB_ITEMS_KEY), 10000, 'idb-retry-timeout').then(v => {
                    if (!bootClean) return;
                    if (v && Array.isArray(v.items) && (v.ts || 0) > lsTs) {
                        parsedItems = rehydrateAvatars(v.items);
                        if (v.lastWatched) { try { lastWatched = v.lastWatched; } catch (e) {} }
                        storageBackend = 'indexeddb';
                        window.__storageBackend = storageBackend;
                        try { refreshApp(); } catch (e) {}
                    }
                }).catch(() => {});
            }
            return parsedItems;
        }

        function showStatus(msg, type = "info") {
            statusMessage.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-check-circle text-emerald-400' : (type === 'error' ? 'fa-triangle-exclamation text-rose-400' : 'fa-info-circle text-sky-400')}"></i> <span>${msg}</span>`;
            statusMessage.classList.remove('hidden');
            statusMessage.classList.add('flex');
            setTimeout(() => {
                statusMessage.classList.add('hidden');
                statusMessage.classList.remove('flex');
            }, 3500);
        }

        urlInput.addEventListener('input', () => {
            const val = urlInput.value.trim();
            if (val.length > 0) {
                clearBtn.classList.remove('hidden');
            } else {
                clearBtn.classList.add('hidden');
            }
            // أثناء عملية جارية الزر ملك لشريط التقدم: لا يُمس محتواه لأي سبب
            // (كتابة، لصق، فتح إعدادات/ملفات، تغيير لغة) — فقط يُعاد رسمه.
            if (typeof importProg !== 'undefined' && importProg) { try { progPaint(true); } catch (e) {} }
            else if (val.length > 0) {
                actionIcon.className = "fa-solid fa-cloud-arrow-down text-emerald-400";
                try { actionText.textContent = tLang('actionFetch'); } catch (e) { actionText.textContent = "Fetch link"; }
            } else {
                actionIcon.className = "fa-solid fa-file-circle-plus";
                try { actionText.textContent = tLang('actionAdd'); } catch (e) { actionText.textContent = "Add file"; }
            }
            try { if (typeof saveUiStateLight === 'function') saveUiStateLight(); } catch (e) {}
        });

        // اللصق الذكي: حقل <input> أحادي السطر يجرد فواصل الأسطر، فيكسر نص M3U الملصوق.
        // نعترض اللصق ونقرأ النص الخام من الحافظة مباشرة (يحافظ على الأسطر).
        // يقبل أيضاً: روابط متلاصقة بلا فواصل + نصاً حراً تُستخرج منه الروابط فقط.
        urlInput.addEventListener('paste', (e) => {
            try {
                const cd = e.clipboardData;
                const raw = cd ? (cd.getData('text/plain') || cd.getData('text') || '') : '';
                if (!raw) return;
                let smart = [];
                try { smart = extractUrlsSmart(raw); } catch (e2) { smart = []; }
                if (/#EXTINF/i.test(raw) || /^#EXTM3U/i.test(raw) || smart.length > 1 || (smart.length === 1 && hasGluedBoundary(raw))) {
                    e.preventDefault();
                    try { handleSmartInput(raw); } catch (e2) {}
                }
            } catch (e2) {}
        });

        clearBtn.addEventListener('click', () => {
            urlInput.value = '';
            urlInput.dispatchEvent(new Event('input'));
        });

        // ===== شريط تقدم الزر نفسه: النسبة + عدد المفحوص من الإجمالي (الإجمالي حي) =====
        // حالة واحدة دائمة importProg تملك الزر طوال العملية: أي كتابة أخرى على
        // الزر أثناءها تُتجاهل (الكتابة على الخانة، تغيير اللغة، فتح الإعدادات)،
        // والرسم مخنوق زمنياً (~150ms) حتى مع عشرات آلاف الروابط.
        let importProg = null; // {phase, done, total}
        let __progPaintT = 0;
        function progPhaseLabel(ph) {
            try {
                if (ph === 'resolve') return tLang('progResolve');
                if (ph === 'probe') return tLang('progProbe');
                if (ph === 'dur') return tLang('progDur');
                if (ph === 'verify') return tLang('progVerify');
                if (ph === 'size') return tLang('progSize');
                if (ph === 'class') return tLang('progClass');
                if (ph === 'render') return tLang('progRender');
            } catch (e) {}
            return '';
        }
        function progPaint(force) {
            try {
                if (!importProg) return;
                const now = Date.now();
                if (!force && (now - __progPaintT) < 150) return;
                __progPaintT = now;
                const d = Math.max(0, importProg.done | 0), t = Math.max(0, importProg.total | 0);
                const pct = t > 0 ? Math.max(0, Math.min(100, Math.round(d * 100 / t))) : 0;
                try { uploadProgressBar.style.width = pct + '%'; } catch (e) {}
                try { actionIcon.className = "fa-solid fa-spinner fa-spin z-10"; } catch (e) {}
                try { actionText.textContent = progPhaseLabel(importProg.phase) + ' ' + d + '/' + t + ' • ' + pct + '%'; } catch (e) {}
            } catch (e) {}
        }
        function progStart(phase, done, total) {
            importProg = { phase: phase, done: Math.max(0, done | 0), total: Math.max(0, total | 0) };
            try {
                actionBtn.disabled = true;
                actionBtn.classList.add('opacity-70', 'cursor-wait');
            } catch (e) {}
            try { showStatus(progPhaseLabel(phase), "info"); } catch (e) {}
            progPaint(true);
        }
        function progTick(n, totalOverride) {
            try {
                if (!importProg) return;
                importProg.done += (n == null ? 1 : n);
                if (totalOverride != null && isFinite(+totalOverride)) importProg.total = Math.max(0, Math.round(+totalOverride));
                progPaint(false);
            } catch (e) {}
        }
        function progSetPhase(phase, done, total) {
            try {
                if (!importProg) importProg = { phase: phase, done: 0, total: 0 };
                importProg.phase = phase;
                if (done != null && isFinite(+done)) importProg.done = Math.max(0, Math.round(+done));
                if (total != null && isFinite(+total)) importProg.total = Math.max(0, Math.round(+total));
                try { showStatus(progPhaseLabel(phase), "info"); } catch (e) {}
                progPaint(true);
            } catch (e) {}
        }
        function progEnd() {
            try { importProg = null; } catch (e) {}
            try { uploadProgressBar.style.width = '0%'; } catch (e) {}
            setActionLoading(false);
        }

        // حالة تحميل صادقة: مؤشر مستمر حتى انتهاء العملية فعلياً (بلا محاكاة نسب مزيفة)
        function setActionLoading(on) {
            try {
                if (!on && importProg) return; // شريط التقدم يملك الزر حتى progEnd
                actionBtn.disabled = !!on;
                actionBtn.classList.toggle('opacity-70', !!on);
                actionBtn.classList.toggle('cursor-wait', !!on);
                if (on) {
                    if (importProg) { progPaint(true); return; }
                    try { actionIcon.className = "fa-solid fa-spinner fa-spin z-10"; } catch (e) {}
                    try { actionText.textContent = tLang('loading'); } catch (e) { actionText.textContent = 'Loading...'; }
                } else {
                    try { uploadProgressBar.style.width = '0%'; } catch (e) {}
                    urlInput.dispatchEvent(new Event('input'));
                }
            } catch (e) {}
        }

        actionBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (typeof importProg !== 'undefined' && importProg) { try { showStatus(tLang('tBusy'), "error"); } catch (e2) {} return; }
            const urlVal = urlInput.value.trim();
            if (urlVal !== '') {
                handleSmartInput(urlVal);
            } else {
                fileInput.click();
            }
        });

        fileInput.addEventListener('change', (e) => {
            const files = Array.from(e.target.files);
            if (!files.length) return;
            if (typeof importProg !== 'undefined' && importProg) { try { showStatus(tLang('tBusy'), "error"); } catch (e2) {} try { fileInput.value = ''; } catch (e3) {} return; }
            setActionLoading(true);
            let readCount = 0;
            let tempExtracted = [];

            files.forEach(file => {
                const reader = new FileReader();
                reader.onload = (event) => {
                    const items = parseM3UString(event.target.result);
                    tempExtracted = tempExtracted.concat(items);
                    readCount++;

                    if (readCount === files.length) {
                        fileInput.value = '';
                        try {
                            if (typeof runStagedImport === 'function') runStagedImport(tempExtracted);
                            else { setActionLoading(false); if (tempExtracted.length > 0) { pendingRawItems = tempExtracted; isReDocumenting = false; openImportDialog(); } else showStatus(tLang('tNoValid'), "error"); }
                        } catch (e) { try { setActionLoading(false); showStatus(tLang('tNoValid'), "error"); } catch (e2) {} }
                    }
                };
                reader.onerror = () => {
                    readCount++;
                    if (readCount === files.length) {
                        fileInput.value = '';
                        try {
                            if (typeof runStagedImport === 'function') runStagedImport(tempExtracted);
                            else { setActionLoading(false); if (tempExtracted.length > 0) { pendingRawItems = tempExtracted; isReDocumenting = false; openImportDialog(); } else showStatus(tLang('tNoValid'), "error"); }
                        } catch (e) { try { setActionLoading(false); showStatus(tLang('tNoValid'), "error"); } catch (e2) {} }
                    }
                };
                reader.readAsText(file);
            });
        });

        // ===== استخراج ذكي للروابط: يقبل النص الحر + الروابط المتلاصقة بلا فواصل =====
        // يجد كل بداية http(s)://، ويفصل رابطاً جديداً عندها إلا إذا سبقها ما يدل
        // على أنها جزء من الرابط نفسه (رابط متداخل داخل استعلام: ?url=, &next= ...).
        // هكذا يُفهم ...mp4https://... كرابطين، بينما ?url=https://... رابط واحد.
        function extractUrlsSmart(text) {
            const src = String(text || '');
            const starts = [];
            try {
                const re = /https?:\/\//gi;
                let m;
                while ((m = re.exec(src))) starts.push(m.index);
            } catch (e) { return []; }
            if (!starts.length) return [];
            const isBoundary = starts.map((s, i) => {
                if (i === 0) return true;
                const prev = src[s - 1] || '';
                if (/[=:?&\/('"\[]/.test(prev)) return false;
                return true;
            });
            const boundIdx = [];
            for (let i = 0; i < starts.length; i++) if (isBoundary[i]) boundIdx.push(i);
            const out = [];
            for (let k = 0; k < boundIdx.length; k++) {
                const s = starts[boundIdx[k]];
                const nextS = (k + 1 < boundIdx.length) ? starts[boundIdx[k + 1]] : src.length;
                const tail = src.slice(s, nextS);
                let cut = -1;
                try { cut = tail.search(/[\s,،;'"<>\]()\[{}\\|^`]/); } catch (e) { cut = -1; }
                const epos = cut >= 0 ? s + cut : nextS;
                let u = src.slice(s, epos).replace(/[.,;:!?)\]}'"،؛…‌‏]+$/, '');
                if (/^https?:\/\/([^\/\s]{1,256}\.[^\/\s]{1,64}|localhost)(:\d+)?(\/|$|\?|#)/i.test(u)) out.push(u);
            }
            const seen = new Set(), res = [];
            out.forEach(u => { if (!seen.has(u)) { seen.add(u); res.push(u); } });
            return res;
        }
        // هل يوجد رابط ملتصق ببداية رابط آخر بلا فاصل (نهاية رابط = بداية https)؟
        function hasGluedBoundary(text) {
            const src = String(text || '');
            const starts = [];
            try {
                const re = /https?:\/\//gi;
                let m;
                while ((m = re.exec(src))) starts.push(m.index);
            } catch (e) { return false; }
            for (let i = 1; i < starts.length; i++) {
                const prev = src[starts[i] - 1] || '';
                if (/[=:?&\/('"\[]/.test(prev)) continue;
                if (/[\s,،;'"<>\]()\[{}\\|^`]/.test(prev)) continue;
                return true;
            }
            return false;
        }

        // خانة ذكية: نص M3U مباشر، أو رابط قائمة، أو روابط مقاطع متعددة مختلطة،
        // أو روابط متلاصقة بلا فواصل، أو نص حر تُستخرج منه الروابط فقط.
        async function handleSmartInput(text) {
            const t = String(text || '').trim();
            if (!t) { try { showStatus(tLang('clipInvalid'), "error"); } catch (e) {} return; }
            if (typeof importProg !== 'undefined' && importProg) { try { showStatus(tLang('tBusy'), "error"); } catch (e) {} return; }
            if (/#EXTINF/i.test(t) || /^#EXTM3U/i.test(t)) {
                // نص قائمة M3U/M3U8 ملصق مباشرة
                setActionLoading(true);
                try {
                    const items = parseM3UString(t);
                    urlInput.value = '';
                    urlInput.dispatchEvent(new Event('input'));
                    try {
                        if (items.length && typeof runStagedImport === 'function') await runStagedImport(items);
                        else if (items.length > 0) { pendingRawItems = items; isReDocumenting = false; openImportDialog(); }
                        else showStatus(tLang('tNoValid'), "error");
                    } catch (e) { try { showStatus(tLang('tNoValid'), "error"); } catch (e2) {} }
                } catch (e) { try { showStatus(tLang('tNoValid'), "error"); } catch (e2) {} }
                finally { if (typeof importProg === 'undefined' || !importProg) { try { setActionLoading(false); } catch (e) {} } }
                return;
            }
            let urls = [];
            try { urls = extractUrlsSmart(t); } catch (e) { urls = []; }
            if (!urls.length) { try { showStatus(tLang('clipInvalid'), "error"); } catch (e) {} return; }
            if (urls.length === 1 && !hasGluedBoundary(t)) {
                // مسار الرابط المفرد: التعرف على المحتوى أولاً (قائمة/مقطع/ميت) ثم التوجيه
                try { await resolveSingleUrl(urls[0]); } catch (e) { try { showStatus(tLang('tCors'), "error"); } catch (e2) {} }
                finally { if (typeof importProg === 'undefined' || !importProg) { try { setActionLoading(false); } catch (e) {} } }
                return;
            }
            // عدة روابط: فوري بلا شبكة (URL-Only) — بناء العناصر من الروابط مباشرة
            // ثم التصنيف من الاسم فقط. progEnd قبل runStagedImport حتى لا
            // تراها عملية جارية (tBusy) فيبقى الزر عالقاً على "جارٍ التعرف".
            setActionLoading(true);
            try {
                progStart('resolve', 0, urls.length);
                const out = [];
                for (let i = 0; i < urls.length; i++) {
                    try { out.push(markClipLiveHint(buildClipItem(urls[i], null), null)); } catch (e) {}
                    try { progTick(1); } catch (e) {}
                }
                urlInput.value = '';
                try { urlInput.dispatchEvent(new Event('input')); } catch (e) {}
                try { progEnd(); } catch (e2) {}
                if (out.length && typeof runStagedImport === 'function') await runStagedImport(out);
                else { try { showStatus(tLang('clipInvalid'), "error"); } catch (e3) {} }
            } catch (e) { try { progEnd(); } catch (e2) {} try { showStatus(tLang('clipInvalid'), "error"); } catch (e3) {} }
        }

        // (كشف الامتداد القديم حُذف — التعرف على المحتوى يتم بالشمّ الفعلي عبر sniffUrlContent)

        // فحص شامل لرابط واحد: الحالة (يعمل/مكسور/غير مؤكد) + الدقائق الفعلية + هل هو بث.
        // بصمات البث الحي (مُدروسة عملياً على مثال republic مقابل مقطع عادي):
        // (1) مدة Infinity، (2) المدة تنمو مع الزمن — وحدها تنمو، أما العادي
        // فمدته ثابتة تماماً، (3) تلميح الشبكة من الشمّ (تجاهل Range + بث مفتوح).
        // ملاحظة: preload=auto إجباري — مع metadata قد يتوقف الجلب فلا يظهر النمو.
        function probeLinkFull(url, ms, opts) {
            ms = ms || 7000;
            const growthMs = (opts && opts.growthMs != null) ? opts.growthMs : 1200;
            const growthOnlySuspect = !!(opts && opts.growthOnlySuspect);
            const suspectGrowth = !!(opts && opts.suspect);
            return new Promise((resolve) => {
                let done = false, v = null, hls = null, timer = null;
                const fin = (r) => {
                    if (done) return; done = true;
                    try { clearTimeout(timer); } catch (e) {}
                    try { if (hls) hls.destroy(); } catch (e) {}
                    try { if (v) { v.pause(); v.removeAttribute('src'); try { v.load(); } catch (e2) {} try { v.remove(); } catch (e3) {} } } catch (e) {}
                    resolve(r);
                };
                timer = setTimeout(() => fin({ state: 'unknown', minutes: null, live: /live|stream|\.m3u8/i.test(String(url)) }), ms);
                try {
                    const u = String(url || '');
                    const isHls = /\.m3u8($|\?)|m3u8/i.test(u);
                    if (isHls && typeof Hls !== 'undefined' && Hls.isSupported()) {
                        v = document.createElement('video');
                        v.muted = true; v.preload = 'auto';
                        try {
                            hls = new Hls({ maxBufferLength: 2 });
                            hls.on(Hls.Events.MANIFEST_PARSED, () => {
                                let live = true;
                                try { live = !!(hls.levels && hls.levels.length && hls.levels[0] && hls.levels[0].details && hls.levels[0].details.live); } catch (e) {}
                                fin({ state: 'ok', minutes: null, live: live });
                            });
                            hls.on(Hls.Events.ERROR, (ev, data) => {
                                try { if (data && data.fatal) fin({ state: 'dead', minutes: null, live: true }); } catch (e) {}
                            });
                            hls.loadSource(u);
                            hls.attachMedia(v);
                        } catch (e) { fin({ state: 'unknown', minutes: null, live: true }); }
                        return;
                    }
                    v = document.createElement('video');
                    v.muted = true; v.playsInline = true; v.preload = 'auto';
                    v.onloadedmetadata = () => {
                        let mins = null;
                        try {
                            const d = v.duration;
                            if (d === Infinity) { fin({ state: 'ok', minutes: null, live: true }); return; }
                            else if (isFinite(d) && d > 0) mins = d / 60;
                            else { fin({ state: 'unknown', minutes: null, live: /live|stream|\.m3u8/i.test(u) }); return; }
                        } catch (e) { fin({ state: 'unknown', minutes: null, live: false }); return; }
                        // وضع الخلفية السريع: روابط VOD الواضحة (مدة محدودة بلا شبهة بث) تُقبل فوراً بلا انتظار نمو
                        if (growthOnlySuspect && !suspectGrowth && isFinite(mins)) { fin({ state: 'ok', minutes: mins, live: false }); return; }
                        // نافذة تأكيد النمو: البث الحي يمدّد مدته باستمرار، والعادي ثابت
                        const d0 = v.duration;
                        setTimeout(() => {
                            if (done) return;
                            try {
                                const d1 = v.duration;
                                if (d1 === Infinity || (isFinite(d1) && isFinite(d0) && (d1 - d0) >= 0.4)) { fin({ state: 'ok', minutes: null, live: true }); return; }
                            } catch (e) {}
                            fin({ state: 'ok', minutes: mins, live: false });
                        }, growthMs);
                    };
                    v.onerror = () => fin({ state: 'dead', minutes: null, live: false });
                    v.src = u;
                    try { v.load(); } catch (e) {}
                } catch (e) { fin({ state: 'unknown', minutes: null, live: false }); }
            });
        }

        function nameFromClipUrl(url) {
            try {
                let path = '';
                try { path = new URL(url).pathname.split('/').filter(Boolean).pop() || ''; } catch (e) { const p = String(url).split('/').filter(Boolean); path = p.length ? p[p.length - 1] : ''; }
                try { path = decodeURIComponent(path); } catch (e) {}
                path = path.split('?')[0].split('#')[0];
                path = path.replace(/\.(mp4|mkv|avi|wmv|flv|m4v|mov|mpg|mpeg|vob|webm|ts|m3u8|mpd|php\d*)$/i, '');
                let name = path.replace(/[._\-+]+/g, ' ').replace(/\s+/g, ' ').trim();
                if (!name) { try { name = new URL(url).hostname.replace(/^www\./, ''); } catch (e) { name = url; } }
                return name;
            } catch (e) { return url; }
        }

        function buildClipItem(url, probe) {
            const name = nameFromClipUrl(url);
            let pi = null;
            try { pi = smartParseMedia(name, url); } catch (e) { pi = null; }
            let cat = 'movie';
            try {
                const d0 = detectContentType({ url: url, rawTitle: name, extinfRaw: '', isSeriesHint: !!(pi && pi.isSeries) });
                if (d0 === 'tv' || (pi && pi.isSeries)) cat = 'tv';
                else if (d0 === 'live' || (probe && probe.live)) cat = 'live';
                else if (d0 === 'movie') cat = 'movie';
                else if (/\.(mp4|mkv|avi|wmv|flv|m4v|mov|mpg|mpeg|vob|webm)$/i.test(url)) cat = 'movie';
                else cat = (probe && probe.live) || /live|stream|\.m3u8|\.ts($|\?)/i.test(url) ? 'live' : 'movie';
            } catch (e) {}
            let year = '';
            try { year = (pi && pi.year) || ''; if (!year) { const m = String(name + ' ' + url).match(/\b(19\d{2}|20[0-2]\d)\b/); if (m) year = m[1]; } } catch (e) {}
            let clean = (pi && (pi.showTitle || pi.title)) || name;
            let showKey = '';
            try { showKey = (pi && pi.showKey) || normalizeShowKey(clean); } catch (e) { showKey = clean; }
            const isSeries = (cat === 'tv');
            return {
                id: 'clip_' + Math.random().toString(36).substr(2, 9),
                rawTitle: name,
                cleanTitle: clean,
                parsedShowTitle: clean,
                showKey: showKey,
                isSeriesHint: isSeries,
                seasonNumber: (pi && pi.seasonNumber) || 1,
                episodeNumber: (pi && pi.episodeNumber) || 1,
                episodeTitle: (pi && pi.episodeTitle) || (isSeries ? '' : clean),
                resolution: (pi && pi.resolution) || '',
                quality: (pi && pi.quality) || '',
                codec: (pi && pi.codec) || '',
                group: (pi && pi.group) || '',
                audio: (pi && pi.audio) || '',
                languages: (pi && pi.languages) || [],
                hdr: (pi && pi.hdr) || '',
                edition: (pi && pi.edition) || '',
                url: url,
                logo: '', poster: '', overview: '',
                metaTitle: '',
                year: year,
                category: cat,
                docAsked: false,
                extinfRaw: 'manual:' + url
            };
        }

        // ===== كشف محتوى الرابط أولاً: قائمة أم مقطع أم صفحة أم ميت — دون تنزيل كامل =====
        // يقرأ أول ~8KB فقط (Range) ثم يلغي التدفق فوراً: لا تنزيل لمقاطع
        // ضخمة بالغلط. يعمل حتى مع خوادم تتجاهل Range (ترد 200 + بداية التدفق).
        // kinds: 'playlist' | 'video' | 'other' | 'dead' | 'unknown'
        // liveHint: تلميح بث حي من الشبكة (200 بلا Range ولا طول معلن + نوع فيديو)
        function sniffUrlContent(url, ms) {
            ms = ms || 8000;
            const out = { kind: 'unknown', head: '', contentType: '', liveHint: false, text: null };
            const u = String(url || '').trim();
            if (!u) return Promise.resolve(out);
            return (async () => {
                try {
                    const ctrl = new AbortController();
                    const to = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, ms);
                    let res = null;
                    try {
                        res = await fetch(u, { headers: { 'Range': 'bytes=0-8191' }, signal: ctrl.signal, redirect: 'follow' });
                    } finally { try { clearTimeout(to); } catch (e) {} }
                    if (!res) return out;
                    try { out.contentType = String(res.headers.get('content-type') || '').toLowerCase(); } catch (e) {}
                    let cr = '', cl = '', ar = '';
                    try { cr = String(res.headers.get('content-range') || ''); cl = String(res.headers.get('content-length') || ''); ar = String(res.headers.get('accept-ranges') || '').toLowerCase(); } catch (e) {}
                    if (res.status === 200 && !cr && !cl && ar !== 'bytes' && /video\/|audio\/mpeg/i.test(out.contentType)) out.liveHint = true;
                    let buf = null, done = false, got206 = (res.status === 206);
                    try {
                        const reader = res.body.getReader();
                        const rr = await Promise.race([
                            reader.read(),
                            new Promise((_, rej) => setTimeout(() => rej(new Error('read-timeout')), 6000))
                        ]);
                        buf = rr.value || null; done = !!rr.done;
                        try { await reader.cancel(); } catch (e) {}
                    } catch (e) { try { if (res.body) await res.body.cancel(); } catch (e2) {} }
                    if ((!buf || !buf.length) && !got206) {
                        out.kind = (res.status >= 200 && res.status < 400) ? 'unknown' : 'dead';
                        return out;
                    }
                    if (!buf || !buf.length) { out.kind = 'unknown'; return out; }
                    let head = '';
                    try {
                        const n = Math.min(buf.length, 1024);
                        const chars = [];
                        for (let i = 0; i < n; i++) { const c = buf[i]; chars.push(c === 10 ? '\n' : ((c >= 32 && c < 127) ? String.fromCharCode(c) : '.')); }
                        head = chars.join('');
                    } catch (e) {}
                    out.head = head;
                    const hs = head.replace(/^\uFEFF/, '').replace(/^\s+/, '');
                    const isM3U = /^#EXTM3U/i.test(hs);
                    // قائمة وسائط HLS (مقاطع مجزأة) = دفق واحد قابل للتشغيل، ليست دليل قنوات
                    const isMediaPl = /#EXT-X-TARGETDURATION|#EXT-X-MEDIA-SEQUENCE|#EXT-X-ENDLIST/i.test(head) && !/#EXT-X-STREAM-INF/i.test(head);
                    if (isM3U && isMediaPl) { out.kind = 'video'; return out; }
                    if (isM3U) {
                        out.kind = 'playlist';
                        if (done && buf.length < 2000000) {
                            try {
                                const t = new TextDecoder('utf-8').decode(buf);
                                if (/^#EXTM3U/i.test(t.replace(/^\uFEFF/, '').replace(/^\s+/, ''))) out.text = t;
                            } catch (e) {}
                        }
                        return out;
                    }
                    let isVideo = false;
                    try {
                        if (buf.length > 12) {
                            const b4 = String.fromCharCode(buf[4], buf[5], buf[6], buf[7]);
                            if (b4 === 'ftyp' || b4 === 'moov' || b4 === 'styp') isVideo = true;
                            if (buf[0] === 0x46 && buf[1] === 0x4C && buf[2] === 0x56) isVideo = true; // FLV
                            if (buf[0] === 0x1A && buf[1] === 0x45 && buf[2] === 0xDF && buf[3] === 0xA3) isVideo = true; // MKV/WebM
                            if (buf[0] === 0x47 && buf.length > 376 && buf[188] === 0x47) isVideo = true; // MPEG-TS
                            const riff = String.fromCharCode(buf[0], buf[1], buf[2], buf[3]);
                            if (riff === 'RIFF' && String.fromCharCode(buf[8], buf[9], buf[10], buf[11]) === 'AVI ') isVideo = true;
                            if (buf[0] === 0x4F && buf[1] === 0x67 && buf[2] === 0x67 && buf[3] === 0x53) isVideo = true; // Ogg
                        }
                    } catch (e) {}
                    if (!isVideo && /^(video|audio)\//i.test(out.contentType) && !/mpegurl|m3u/i.test(out.contentType)) isVideo = true;
                    if (isVideo) { out.kind = 'video'; return out; }
                    if (/^\s*[{[]/.test(hs) || /^\s*<!doctype|^\s*<html|^\s*<head/i.test(hs) || /text\/html/i.test(out.contentType)) { out.kind = 'other'; return out; }
                    out.kind = 'unknown';
                    return out;
                } catch (e) { return out; }
            })();
        }
        // تنزيل نصي كامل بسقف صارم (افتراضياً 12MB) مع إلغاء التدفق بعده — للقوائم فقط
        // budgetMs: ميزانية الإلغاء الكلي (افتراضي 60s؛ التحقق من الميت يستعمل أقل)
        function fetchFullText(url, cap, onTick, budgetMs) {
            cap = cap || 12 * 1024 * 1024;
            const budget = (budgetMs != null && isFinite(+budgetMs) && +budgetMs > 0) ? +budgetMs : 60000;
            return (async () => {
                const ctrl = new AbortController();
                const to = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, budget);
                try {
                    const res = await fetch(url, { signal: ctrl.signal, redirect: 'follow' });
                    if (!res.ok) throw new Error('http-' + res.status);
                    const reader = res.body.getReader();
                    const chunks = [];
                    let total = 0;
                    for (let k = 0; k < 4000; k++) {
                        const rr = await Promise.race([
                            reader.read(),
                            new Promise((_, rej) => setTimeout(() => rej(new Error('read-timeout')), 10000))
                        ]);
                        if (rr.value) { chunks.push(rr.value); total += rr.value.length; if (onTick) { try { onTick(total); } catch (e) {} } }
                        if (rr.done || total >= cap) break;
                    }
                    try { await reader.cancel(); } catch (e) {}
                    const all = new Uint8Array(total);
                    let o = 0;
                    chunks.forEach(c => { all.set(c, o); o += c.length; });
                    return new TextDecoder('utf-8').decode(all);
                } finally { try { clearTimeout(to); } catch (e) {} }
            })();
        }
        function isM3UText(t) {
            try { return !!t && /^#EXTM3U/i.test(String(t).replace(/^\uFEFF/, '').replace(/^\s+/, '')); } catch (e) { return false; }
        }
        function isHlsMediaPlaylist(t) {
            try { return /#EXT-X-TARGETDURATION|#EXT-X-MEDIA-SEQUENCE/i.test(String(t)) && !/#EXT-X-STREAM-INF/i.test(String(t)); } catch (e) { return false; }
        }
        // ===== فحص استجابة سريع (fetch خفيف، بلا عناصر فيديو): الحالة + النوع + مدة الشغال =====
        // طلب واحد خفيف لكل رابط: الترويسات أولاً (الحالة/النوع)، ثم أول ~48KB
        // عند الحاجة (بصمة قائمة/فيديو/مدة mp4-m3u8 من نفس البايتات). توازٍ 24
        // ومهلة 3s — يكفي ~11k رابط ضمن 5 دقائق. CORS المحظور ⇒ unknown
        // (يُحسم لاحقاً بعنصر فيديو في الخلفية بعد فتح الديالوغ مباشرة).
        function isAudioUrl(u) { try { return /\.(mp3|m4a|aac|oga|ogg|wav|flac|wma|opus|aiff|amr)($|\?)/i.test(String(u || '')); } catch (e) { return false; } }
        function isVideoishUrl(u) { try { return /\.(mp4|m4v|mov|mkv|webm|avi|flv|wmv|m3u8|mpd|ts)($|\?)/i.test(String(u || '')); } catch (e) { return false; } }
        function sniffFast(url, ms) {
            ms = (ms && isFinite(+ms) && +ms > 0) ? +ms : 3000;
            const out = { kind: 'unknown', head: '', contentType: '', liveHint: false, durationMin: null, live: false };
            const u = String(url || '').trim();
            if (!u) return Promise.resolve(out);
            return (async () => {
                const ctrl = new AbortController();
                const to = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, ms);
                const drop = async (res) => { try { if (res && res.body) await res.body.cancel(); } catch (e) {} };
                try {
                    const res = await fetch(u, { headers: { 'Range': 'bytes=0-0' }, signal: ctrl.signal, redirect: 'follow' });
                    if (!res) { out.kind = 'unknown'; return out; }
                    if (!res.ok) { try { await drop(res); } catch (e) {} out.kind = 'dead'; return out; }
                    let ct = '', cr = '', cl = '', ar = '';
                    try { ct = String(res.headers.get('content-type') || '').toLowerCase(); } catch (e) {}
                    try { cr = String(res.headers.get('content-range') || ''); cl = String(res.headers.get('content-length') || ''); ar = String(res.headers.get('accept-ranges') || '').toLowerCase(); } catch (e) {}
                    out.contentType = ct;
                    if (res.status === 200 && !cr && !cl && ar !== 'bytes' && /video\//i.test(ct)) out.liveHint = true;
                    const extAudio = isAudioUrl(u);
                    // حسم فوري من الترويسات بلا قراءة جسم (الأسرع)
                    if (/^audio\//i.test(ct) && !/mpegurl|m3u/i.test(ct)) { await drop(res); out.kind = 'audio'; return out; }
                    if (/text\/html|application\/json|application\/xml|text\/xml/i.test(ct)) { await drop(res); out.kind = 'other'; return out; }
                    // قراءة أول ~48KB (3 دفعات بمهلة قصيرة لكل دفعة) ثم إلغاء فوري
                    let bytes = null, truncated = false;
                    try {
                        const reader = res.body.getReader();
                        const chunks = [];
                        let total = 0;
                        for (let k = 0; k < 3; k++) {
                            const rr = await Promise.race([
                                reader.read(),
                                new Promise((_, rej) => setTimeout(() => rej(new Error('chunk-timeout')), 1000))
                            ]);
                            if (rr.value) { chunks.push(rr.value); total += rr.value.length; }
                            if (rr.done) break;
                            if (total >= 49152) { truncated = true; break; }
                        }
                        try { await reader.cancel(); } catch (e) {}
                        if (total > 0) {
                            bytes = new Uint8Array(total);
                            let o = 0;
                            chunks.forEach(c => { bytes.set(c, o); o += c.length; });
                        }
                    } catch (e) { try { if (res.body) await res.body.cancel(); } catch (e2) {} }
                    if (!bytes || !bytes.length) {
                        if (extAudio) { out.kind = 'audio'; return out; }
                        if (/\.m3u($|\?)/i.test(u)) { out.kind = 'playlist'; return out; }
                        if (/\.m3u8($|\?)/i.test(u)) { out.kind = 'video'; return out; }
                        if (/video\//i.test(ct) || isVideoishUrl(u)) { out.kind = 'video'; return out; }
                        out.kind = 'unknown';
                        return out;
                    }
                    out._truncated = truncated;
                    return parseSniffBytes(u, bytes, out, ct);
                } catch (e) { out.kind = 'unknown'; return out; }
                finally { try { clearTimeout(to); } catch (e) {} }
            })();
        }
        function parseSniffBytes(u, bytes, out, ct) {
            const extM3U8 = /\.m3u8($|\?)/i.test(u);
            const extMP4 = /\.(mp4|m4v|mov)($|\?)/i.test(u);
            const extMKV = /\.(mkv|webm)($|\?)/i.test(u);
            const truncated = !!out._truncated;
            try { delete out._truncated; } catch (e) {}
            let head = '';
            try {
                const n = Math.min(bytes.length, 1024);
                const ch = [];
                for (let i = 0; i < n; i++) { const c = bytes[i]; ch.push(c === 10 ? '\n' : ((c >= 32 && c < 127) ? String.fromCharCode(c) : '.')); }
                head = ch.join('');
            } catch (e) {}
            out.head = head;
            const hs = head.replace(/^\uFEFF/, '').replace(/^\s+/, '');
            const isM3U = /^#EXTM3U/i.test(hs);
            if (isM3U) {
                const hasStreamInf = /#EXT-X-STREAM-INF/i.test(head);
                const isMedia = /#EXT-X-TARGETDURATION|#EXT-X-MEDIA-SEQUENCE|#EXT-X-ENDLIST/i.test(head) && !hasStreamInf;
                if (isMedia) {
                    out.kind = 'video';
                    try {
                        const txt = new TextDecoder('utf-8').decode(bytes);
                        const d = parseM3U8DurationFromText(txt);
                        if (d && d.minutes != null && isFinite(d.minutes)) out.durationMin = d.minutes;
                        else if (d && d.live && !truncated) out.live = true;
                    } catch (e) {}
                    return out;
                }
                if (hasStreamInf) { out.kind = 'video'; return out; } // رئيسية HLS — تُحسم دقائقها بالخلفية
                out.kind = 'playlist';
                return out;
            }
            let isVideo = false;
            try {
                if (bytes.length > 12) {
                    const b4 = String.fromCharCode(bytes[4], bytes[5], bytes[6], bytes[7]);
                    if (b4 === 'ftyp' || b4 === 'moov' || b4 === 'styp') isVideo = true;
                    if (bytes[0] === 0x46 && bytes[1] === 0x4C && bytes[2] === 0x56) isVideo = true; // FLV
                    if (bytes[0] === 0x1A && bytes[1] === 0x45 && bytes[2] === 0xDF && bytes[3] === 0xA3) isVideo = true; // MKV/WebM
                    if (bytes[0] === 0x47 && bytes.length > 376 && bytes[188] === 0x47) isVideo = true; // MPEG-TS
                    if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46) { // RIFF
                        const fcc = String.fromCharCode(bytes[8], bytes[9], bytes[10], bytes[11]);
                        if (fcc === 'AVI ') isVideo = true;
                        else if (fcc === 'WAVE') { out.kind = 'audio'; return out; }
                    }
                    if (bytes[0] === 0x4F && bytes[1] === 0x67 && bytes[2] === 0x67 && bytes[3] === 0x53) isVideo = true; // Ogg
                }
            } catch (e) {}
            if (!isVideo && /^(video|application\/octet-stream)/i.test(ct || '') && !/mpegurl|m3u/i.test(ct || '')) isVideo = true;
            if (isVideo) {
                out.kind = 'video';
                if (extMP4) { try { const m = parseMp4DurationFromBytes(bytes); if (m != null && isFinite(m)) out.durationMin = m; } catch (e) {} }
                else if (extMKV) { try { const m = parseWebmDurationFromBytes(bytes); if (m != null && isFinite(m)) out.durationMin = m; } catch (e) {} }
                return out;
            }
            if (/^\s*[{[]/.test(hs) || /^\s*<!doctype|^\s*<html|^\s*<head/i.test(hs) || /text\/html|application\/json|application\/xml/i.test(ct || '')) { out.kind = 'other'; return out; }
            if (/^audio\//i.test(ct || '')) { out.kind = 'audio'; return out; }
            if (isAudioUrl(u)) { out.kind = 'audio'; return out; }
            if (isVideoishUrl(u)) { out.kind = 'video'; return out; }
            if (/\.m3u($|\?)/i.test(u)) { out.kind = 'playlist'; return out; }
            if (extM3U8) { out.kind = 'video'; return out; }
            out.kind = 'unknown';
            return out;
        }
        // مدة قائمة HLS الوسائطية: مجموع EXTINF (دقائق)، أو بث حي بلا ENDLIST
        function parseM3U8DurationFromText(t) {
            try {
                const s = String(t || '');
                if (!/^#EXTM3U/i.test(s.replace(/^\uFEFF/, '').replace(/^\s+/, ''))) return null;
                if (/#EXT-X-STREAM-INF/i.test(s)) return null; // رئيسية — ليست مدة
                const end = /^#EXT-X-ENDLIST/im.test(s);
                let sum = 0, n = 0;
                const re = /^#EXTINF:\s*([0-9.]+)/gim;
                let m;
                while ((m = re.exec(s))) { const v = parseFloat(m[1]); if (isFinite(v)) { sum += v; n++; } }
                if (n > 0 && end) return { minutes: sum / 60, live: false };
                if (!end) return { minutes: null, live: true };
                return null;
            } catch (e) { return null; }
        }
        // مدة MP4/MOV من بايتات البداية (أو الذيل): صندوق moov ← mvhd (دقائق)
        function parseMp4DurationFromBytes(bytes) {
            try {
                const n = bytes.length;
                if (n < 32) return null;
                const tag = (i) => String.fromCharCode(bytes[i], bytes[i + 1], bytes[i + 2], bytes[i + 3]);
                let off = 0, moovOff = -1, moovEnd = -1;
                while (off + 8 <= n) {
                    const size = (bytes[off] * 16777216) + (bytes[off + 1] << 16) + (bytes[off + 2] << 8) + bytes[off + 3];
                    const t = tag(off + 4);
                    if (t === 'moov') { moovOff = off; moovEnd = (size > 0 && isFinite(size)) ? Math.min(n, off + size) : n; break; }
                    if (!(size >= 8) || size === 1) break;
                    off += size;
                    if (off > 131072) break;
                }
                if (moovOff < 0) return null;
                const end = Math.min(moovEnd, moovOff + 131072, n);
                for (let i = moovOff + 4; i + 24 <= end; i++) {
                    if (bytes[i] === 0x6D && bytes[i + 1] === 0x76 && bytes[i + 2] === 0x68 && bytes[i + 3] === 0x64) { // 'mvhd'
                        // v0: version(1)+flags(3)+creation(4)+mod(4)+timescale(4)+duration(4)
                        // v1: version(1)+flags(3)+creation(8)+mod(8)+timescale(4)+duration(8)
                        const v = bytes[i + 4];
                        let timescale = 0, dur = 0;
                        if (v === 1) {
                            if (i + 36 > end) return null;
                            timescale = (bytes[i + 24] * 16777216) + (bytes[i + 25] << 16) + (bytes[i + 26] << 8) + bytes[i + 27];
                            const hi = (bytes[i + 28] * 16777216) + (bytes[i + 29] << 16) + (bytes[i + 30] << 8) + bytes[i + 31];
                            const lo = (bytes[i + 32] * 16777216) + (bytes[i + 33] << 16) + (bytes[i + 34] << 8) + bytes[i + 35];
                            dur = hi * 4294967296 + lo;
                        } else {
                            if (i + 24 > end) return null;
                            timescale = (bytes[i + 16] * 16777216) + (bytes[i + 17] << 16) + (bytes[i + 18] << 8) + bytes[i + 19];
                            dur = (bytes[i + 20] * 16777216) + (bytes[i + 21] << 16) + (bytes[i + 22] << 8) + bytes[i + 23];
                        }
                        if (timescale > 0 && dur > 0) return (dur / timescale) / 60;
                        return null;
                    }
                }
                return null;
            } catch (e) { return null; }
        }
        // مدة WebM/MKV: عنصر Duration (وحدات TimecodeScale الافتراضية 1ms) — أفضل جهد
        function parseWebmDurationFromBytes(bytes) {
            try {
                const n = Math.min(bytes.length, 65536);
                for (let i = 0; i + 8 < n; i++) {
                    if (bytes[i] === 0x44 && bytes[i + 1] === 0x89) {
                        const b = bytes[i + 2];
                        if (!b) continue;
                        let len = 0;
                        for (let k = 0; k < 8; k++) { if (b & (0x80 >> k)) { len = k + 1; break; } }
                        if (len < 1 || len > 8) continue;
                        let size = b & (0xFF >> len);
                        for (let k = 1; k < len; k++) size = (size << 8) | bytes[i + 2 + k];
                        if (size !== 4 && size !== 8) continue;
                        const dataOff = i + 2 + len;
                        if (dataOff + size > n) continue;
                        let val = 0;
                        try {
                            if (size === 4) val = new DataView(bytes.buffer, bytes.byteOffset + dataOff, 4).getFloat32(0, false);
                            else val = new DataView(bytes.buffer, bytes.byteOffset + dataOff, 8).getFloat64(0, false);
                        } catch (e2) { continue; }
                        if (isFinite(val) && val > 0) return (val / 1000) / 60;
                        return null;
                    }
                }
                return null;
            } catch (e) { return null; }
        }
        // مدة MP4 من الذيل (لملفات moov-at-end): نطاق لاحق 64KB فقط، مع حد أمان ضد التنزيل الكامل
        function fetchTailMp4Duration(url, ms) {
            ms = (ms && isFinite(+ms) && +ms > 0) ? +ms : 4000;
            return (async () => {
                const ctrl = new AbortController();
                const to = setTimeout(() => { try { ctrl.abort(); } catch (e) {} }, ms);
                try {
                    const res = await fetch(String(url), { headers: { 'Range': 'bytes=-65536' }, signal: ctrl.signal, redirect: 'follow' });
                    if (!res || !res.ok) return null;
                    let bytes = null;
                    try {
                        const reader = res.body.getReader();
                        const chunks = [];
                        let total = 0;
                        for (let k = 0; k < 4; k++) {
                            const rr = await Promise.race([
                                reader.read(),
                                new Promise((_, rej) => setTimeout(() => rej(new Error('tail-timeout')), 1000))
                            ]);
                            if (rr.value) { chunks.push(rr.value); total += rr.value.length; }
                            if (rr.done || total > 70000) break;
                        }
                        try { await reader.cancel(); } catch (e) {}
                        if (total <= 0 || total > 70000) return null; // الخادم تجاهل النطاق وبدأ البث الكامل — يُترك للخلفية
                        bytes = new Uint8Array(total);
                        let o = 0;
                        chunks.forEach(c => { bytes.set(c, o); o += c.length; });
                    } catch (e) { return null; }
                    if (!bytes) return null;
                    const m = parseMp4DurationFromBytes(bytes);
                    return (m != null && isFinite(m)) ? m : null;
                } catch (e) { return null; }
                finally { try { clearTimeout(to); } catch (e) {} }
            })();
        }
        // تطبيق نتيجة الشمّ السريع على العنصر: الحالة (شغال/مكسور/غامض) + النوع + مدة الشغال فقط
        function applySniffResult(it, sn) {
            try {
                it.linkCheckedAt = Date.now();
                if (!sn || sn.kind === 'unknown') { if (!it.linkState) it.linkState = 'unknown'; it._sniffKind = (sn && sn.kind) || 'unknown'; return; }
                if (sn.kind === 'dead') { it.linkState = 'dead'; it._sniffKind = 'dead'; return; }
                it.linkState = 'ok';
                it._sniffKind = sn.kind;
                if (sn.liveHint) it._netLiveHint = true;
                if (sn.kind === 'audio' || (isAudioUrl(it.url) && sn.kind !== 'playlist')) { markAudioSus(it); return; }
                if (sn.kind === 'other') { markNonVideoSus(it); return; }
                if (it._maybeNotVideo) { try { delete it._maybeNotVideo; } catch (e) {} } // ثبت أنه فيديو
                if (sn.live) it._probeLive = true;
                if (sn.durationMin != null && isFinite(sn.durationMin)) { it.durationMin = Math.round(sn.durationMin * 10) / 10; }
            } catch (e) {}
        }
        // صوت فقط أو محتوى غير فيديو ⇒ مشبوهة فوراً (غير محدد) + فئة مقترحة من الاسم
        // تخمين فئة الصوت/غير-الفيديو من الاسم فقط (بتجاهل امتداد الصوت كبصمة تقنية،
        // وبتجاهل لاحقة الدقة بين قوسين — فهي وسم بث القناة لا دليل VOD — حتى
        // يثبت التخمين بين اللصق المفرد (اسم الملف) والقائمة (عنوان EXTINF)).
        function audioNameGuess(it) {
            try {
                let rt = String(it.rawTitle || '');
                try { rt = rt.replace(/\(\s*\d{3,4}\s*[pi]\s*\)/gi, ' ').replace(/\[\s*\d{3,4}\s*[pi]\s*\]/gi, ' '); } catch (e) {}
                const probe = Object.assign({}, it, { rawTitle: rt, url: String(it.url || '').replace(/\.(mp3|m4a|aac|oga|ogg|wav|flac|wma|opus|aiff|amr)($|\?)/i, '.mp4$2') });
                const c = (typeof fastClassifyItem === 'function') ? fastClassifyItem(probe) : 'unknown';
                if (c === 'tv' || c === 'movie') return c;
            } catch (e) {}
            return 'live';
        }
        function markAudioSus(it) {
            try {
                it._maybeNotVideo = 'audio';
                it._suspicious = true;
                if (!it._susGuess) it._susGuess = audioNameGuess(it);
            } catch (e) {}
        }
        function markNonVideoSus(it) {
            try {
                it._maybeNotVideo = 'page';
                it._suspicious = true;
                if (!it._susGuess) {
                    let g = 'live';
                    try { const c = (typeof fastClassifyItem === 'function') ? fastClassifyItem(it) : 'unknown'; if (c === 'tv' || c === 'movie') g = c; } catch (e) {}
                    it._susGuess = g;
                }
            } catch (e) {}
        }
        // مسح الشمّ السريع لكل الروابط (توازٍ 24، fetch خفيف فقط)
        async function sniffSweepFast(list, onTick) {
            const W = 24;
            let di = 0;
            const worker = async () => {
                while (true) {
                    let it = null;
                    if (di < list.length) it = list[di++];
                    else break;
                    if (!it || it._droppedPlaylist || it._sweepDone) { try { if (onTick) onTick(); } catch (e) {} continue; }
                    try {
                        let sn = null;
                        try { sn = await sniffFast(it.url, 2000); } catch (e) { sn = null; }
                        try { applySniffResult(it, sn); } catch (e) {}
                    } catch (e) {}
                    try { it._sweepDone = true; } catch (e) {}
                    try { if (onTick) onTick(); } catch (e) {}
                }
            };
            const pool = [];
            for (let i = 0; i < W; i++) pool.push(worker());
            try { await Promise.all(pool); } catch (e) {}
        }
        // ===== توازٍ تكيفي للفحص (نمط التركيز): كل الأداء لفحص الروابط =====
        // أجهزة قوية ⇒ عمال أكثر ومهلة كاملة؛ أجهزة ضعيفة ⇒ عمال أقل ومهلة
        // أقصر (استجابة أسرع بلا اختناق عناصر الفيديو)، والدقة محفوظة بقاعدة الدقائق.
        function probeParallelism() {
            let w = 6, ms = 7000;
            try {
                const cores = (typeof navigator !== 'undefined' && navigator.hardwareConcurrency) || 4;
                const mem = (typeof navigator !== 'undefined' && navigator.deviceMemory) || 4;
                if (cores >= 8 && mem >= 8) { w = 8; ms = 7000; }
                else if (cores >= 4) { w = 6; ms = 6000; }
                else { w = 3; ms = 5000; }
            } catch (e) {}
            return { workers: w, ms: ms };
        }
        // قائمة الوسائط (مجزأة HLS) ليست دليلاً ⇒ يُبقى العنصر الأصلي كما هو.
        // بلا أي حد عددي: كل عناصر الملف/الرابط تُعالج مهما بلغ عددها،
        // والتقدم يُبلَّغ عبر onTick ليرسم الزر النسبة أولاً بأول.
        async function resolveNestedPlaylists(items, onTick) {
            const out = [];
            let expanded = 0, dropped = 0;
            const list = (items || []).slice();
            for (let qi = 0; qi < list.length; qi++) {
                const it = list[qi];
                let lookPl = false;
                try {
                    const u = String(it.url || '');
                    lookPl = /\.m3u($|\?)/i.test(u) && !/\.(m3u8|mpd|ts)($|\?)/i.test(u);
                } catch (e) {}
                if (!lookPl) { out.push(it); try { if (onTick) onTick(); } catch (e) {} continue; }
                let kids = null, isMedia = false;
                try {
                    const t = await fetchFullText(it.url, 12 * 1024 * 1024, null);
                    if (isM3UText(t)) {
                        if (isHlsMediaPlaylist(t)) isMedia = true;
                        else { try { kids = parseM3UString(t) || []; } catch (e) { kids = []; } }
                    }
                } catch (e) { kids = null; }
                if (isMedia || kids === null) { out.push(it); try { if (onTick) onTick(); } catch (e) {} continue; }
                if (!kids.length) { dropped++; try { if (onTick) onTick(); } catch (e) {} continue; }
                expanded += kids.length;
                kids.forEach(k => {
                    try { if (!k.group && it.group) k.group = it.group; } catch (e) {}
                    out.push(k);
                });
                try { if (onTick) onTick(); } catch (e) {}
            }
            return { items: out, expanded: expanded, dropped: dropped, total: list.length };
        }
        // تحقق صارم من رابط ميت مرشح كقائمة: شمّ أولاً (رخيص)، ثم تنزيل بميزانية
        // قصيرة فقط عند الحاجة. يعيد روابط الأبناء أو null (ميت فعلاً / ليس قائمة).
        async function verifyDeadPlaylist(d) {
            try {
                if (!d || d._dlFailed) return null; // فشل تنزيله الآن ⇒ لا جدوى من إعادته
                let t = null;
                try {
                    const sn = await sniffUrlContent(d.url, 8000);
                    if (sn && sn.kind === 'playlist' && sn.text && isM3UText(sn.text)) t = sn.text;
                    else if (sn && (sn.kind === 'video' || sn.kind === 'other' || sn.kind === 'dead')) return null;
                } catch (e) {}
                if (t == null) {
                    try { t = await fetchFullText(d.url, 12 * 1024 * 1024, null, 20000); } catch (e) { return null; }
                }
                if (!isM3UText(t) || isHlsMediaPlaylist(t)) return null;
                let kids = [];
                try { kids = parseM3UString(t) || []; } catch (e) {}
                if (!kids.length) return null;
                let r = null;
                try { r = await resolveNestedPlaylists(kids, () => {}); } catch (e) { r = null; }
                const fresh = (r && r.items) || kids;
                return fresh.length ? fresh : null;
            } catch (e) { return null; }
        }
        function markClipLiveHint(clip, sn) {
            try { if (clip && sn && sn.liveHint) clip._netLiveHint = true; } catch (e) {}
            try { if (clip && sn && sn.kind) clip._sniffKind = sn.kind; } catch (e) {}
            return clip;
        }
        // مسار الرابط المفرد: التعرف على المحتوى أولاً، ثم التوجيه الصحيح
        // (قائمة ⇒ تنزيل الروابط داخلها ومعالجتها، مقطع ⇒ الفحص مباشرة)
        async function resolveSingleUrl(url) {
            const u = String(url || '').trim();
            if (!u) return;
            if (typeof importProg !== 'undefined' && importProg) { try { showStatus(tLang('tBusy'), "error"); } catch (e) {} return; }
            setActionLoading(true);
            const finishClip = async (clip) => {
                urlInput.value = '';
                try { urlInput.dispatchEvent(new Event('input')); } catch (e) {}
                if (clip && typeof runStagedImport === 'function') await runStagedImport([clip]);
                else { try { progEnd(); } catch (e) {} try { showStatus(tLang('clipInvalid'), "error"); } catch (e2) {} }
            };
            const finishList = async (items) => {
                urlInput.value = '';
                try { urlInput.dispatchEvent(new Event('input')); } catch (e) {}
                if (items && items.length && typeof runStagedImport === 'function') await runStagedImport(items);
                else { try { progEnd(); } catch (e2) {} try { showStatus(tLang('tNoValid'), "error"); } catch (e3) {} }
            };
            try {
            try { showStatus(tLang('resolving'), "info"); } catch (e) {}
            const extPl = /\.m3u($|\?)/i.test(u) && !/\.(m3u8|mpd|ts)($|\?)/i.test(u);
            // 1) امتداد قائمة صريح ⇒ تنزيل مباشر بلا شمّ
            if (extPl) {
                try {
                    const t = await fetchFullText(u, 12 * 1024 * 1024, (n) => { try { showStatus(tLang('downloading').replace('{n}', Math.round(n / 1024)), "info"); } catch (e) {} });
                    if (isM3UText(t)) {
                        if (isHlsMediaPlaylist(t)) { await finishClip(markClipLiveHint(buildClipItem(u, null), { liveHint: false })); return; }
                        let items = [];
                        try { items = parseM3UString(t) || []; } catch (e) {}
                        if (items.length) {
                            try { showStatus(tLang('expanding'), "info"); } catch (e) {}
                            const r = await resolveNestedPlaylists(items, () => {});
                            await finishList(r.items); return;
                        }
                    }
                    await finishClip(buildClipItem(u, null)); return;
                } catch (e) {
                    // تعذّر التنزيل: لا يُتجاهل الرابط — يمر كعنصر ميت بالفحص المرحلي
                    // (يُستخرج اسمه ويُعلَّم، وإن ثبت أنه قائمة لاحقاً تُوسَّع).
                    // _dlFailed: فشل تنزيله الآن ⇒ التحقق اللاحق يتخطى إعادة التنزيل.
                    let c = null;
                    try { c = buildClipItem(u, null); } catch (e2) {}
                    try { if (c) c._dlFailed = true; } catch (e3) {}
                    try { await finishClip(c); } catch (e2) {}
                    return;
                }
            }
            // 2) شمّ المحتوى أولاً (8KB فقط، بلا تنزيل)
            let sn = null;
            try { sn = await sniffUrlContent(u, 8000); } catch (e) { sn = null; }
            const kind = sn ? sn.kind : 'unknown';
            if (kind === 'playlist') {
                try {
                    const t = (sn && sn.text) || await fetchFullText(u, 12 * 1024 * 1024, (n) => { try { showStatus(tLang('downloading').replace('{n}', Math.round(n / 1024)), "info"); } catch (e) {} });
                    if (isM3UText(t)) {
                        if (isHlsMediaPlaylist(t)) { await finishClip(markClipLiveHint(buildClipItem(u, null), sn)); return; }
                        let items = [];
                        try { items = parseM3UString(t) || []; } catch (e) {}
                        if (items.length) {
                            try { showStatus(tLang('expanding'), "info"); } catch (e) {}
                            const r = await resolveNestedPlaylists(items, () => {});
                            await finishList(r.items); return;
                        }
                    }
                    await finishClip(markClipLiveHint(buildClipItem(u, null), sn)); return;
                } catch (e) {
                    await finishClip(markClipLiveHint(buildClipItem(u, null), sn)); return;
                }
            }
            // 3) مقطع / صفحة / ميت / غامض (CORS) ⇒ عنصر واحد يمر بالفحص المرحلي
            await finishClip(markClipLiveHint(buildClipItem(u, null), sn));
            } catch (e) {
                // ضمانة أخيرة: لا يبقى الزر عالقاً ولا تضيع العملية بصمت
                try { if (typeof importProg !== 'undefined' && importProg) progEnd(); else setActionLoading(false); } catch (e2) {}
                try { showStatus(tLang('tCors'), "error"); } catch (e3) {}
            }
        }
        async function fetchRemoteM3U(url) {
            try { await resolveSingleUrl(url); } catch (e) { try { setActionLoading(false); } catch (e2) {} try { showStatus(tLang('tCors'), "error"); } catch (e3) {} }
        }

