        // ===== مصنّف نوع المحتوى (مسلسل/فيلم/مباشر) من بصمات أسماء الروابط =====
        // المسلسل: رموز الموسم/الحلقة الشائعة (S01E01) أو مجلد موسم أو تلميح المحلل.
        // الفيلم: بلا رموز حلقات لكن برموز تقنية (جودة/مصدر/ترميز/ترجمة) مع سنة غالباً.
        // القناة: اسم فقط عادة (روابط live/ts/m3u8 أو مسارات xtream من نوع live).
        // ===== ديالوغ اختيار عناصر الاستيراد: 4 فئات مندلسة (قسم واحد مفتوح) =====
        // الشغالة محددة افتراضياً؛ المكسورة والصوت/غير-الفيديو غير محددة، والمستخدم يلغي ما لا يريد، ثم تُضاف مباشرة بدون توثيق.
        // التوثيق أصبح اقتراحاً لمرة واحدة عند أول ضغطة على عنصر جديد غير موثق (openDocSuggest).
        let importSelected = new Set();
        let importCatById = new Map(); // id -> 'tv'|'movie'|'live'|'none' (المشبوهة عبر القائمة المنسدلة)
        let importGroups = null; // {tvShows, movie, live, sus}
        let importOpenSection = null;
        const IMP_MORE_STEP = 200;
        const IMP_SHOW_STEP = 200;
        let impRenderedCount = { movie: IMP_MORE_STEP, live: IMP_MORE_STEP, sus: IMP_MORE_STEP };
        let impRenderedShows = IMP_SHOW_STEP;
        const impExpandedShows = new Set();
        const impExpandedSeasons = new Set();
        // بحث داخل كل فئة + خرائط مساعدة للتحديث الحي
        let impSearch = { tv: '', movie: '', live: '', sus: '' };
        let impByIdMap = new Map();
        let impSeenIds = new Set();
        let impManualSel = new Set(); // ids that the user toggled manually (bg auto-deselect must not touch them)
        let importAbort = false;
        let __impSearchT = 0;
        function escImp(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
        function partitionPending() {
            // لا فئة "غير مؤكدة": كل ما ليس مسلسلاً/فيلماً/مباشراً ⇒ مشبوهة
            // (الميت بلا بصمات عبر _suspicious، والغامض الباقي عبر التصنيف).
            const g = { tv: [], movie: [], live: [], sus: [] };
            (pendingRawItems || []).forEach(it => {
                try { if (it && it._suspicious) { g.sus.push(it); return; } } catch (e) {}
                let t = null;
                try { t = it._fastCat || detectContentType(it); } catch (e) { t = 'unknown'; }
                if (t === 'tv') g.tv.push(it);
                else if (t === 'movie') g.movie.push(it);
                else if (t === 'live') g.live.push(it);
                else g.sus.push(it);
            });
            return g;
        }
        // ===== خط الاستيراد الفوري (نموذج MediaParser): استخراج ← أسماء ← توزيع URL-Only ← ديالوغ =====
        function fileNameOfUrl(u) {
            try {
                let s = String(u || '');
                try { s = new URL(s).pathname.split('/').filter(Boolean).pop() || ''; }
                catch (e) { const p = s.split('/').filter(Boolean); s = p.length ? p[p.length - 1] : ''; }
                try { s = decodeURIComponent(s); } catch (e) {}
                return s.split('?')[0].split('#')[0];
            } catch (e) { return String(u || ''); }
        }
        function hasAnyFingerprint(it) {
            // أي بصمة فيلم/مسلسل: رموز حلقات، تلميح المحلل، مجلد موسم، تقنية،
            // سنة، ملف فيديو، مجلد أفلام، مجموعة نوع، أو معرّف قناة (إشارة تصنيفية)
            try {
                const url = String(it.url || ''), raw = String(it.rawTitle || '');
                const blob = fileNameOfUrl(url) + ' ' + raw;
                const gm = String(it.extinfRaw || '').match(/group-title="([^"]*)"/i);
                const gt = gm ? groupHintOf(gm[1]) : null;
                if (hasSeriesCode(blob) || it.isSeriesHint || hasSeasonFolder(url)) return true;
                if (techPositive(blob) || it.resolution || it.quality || it.codec || it.audio || it.edition || (it.languages && it.languages.length)) return true;
                if (hasYear(blob) || it.year) return true;
                if (/\.(mp4|mkv|avi|wmv|flv|m4v|mov|mpg|mpeg|vob|webm)($|\?)/i.test(url)) return true;
                if (/\b(movies?|films?|vod|cinema|أفلام|افلام)\b/i.test(url)) return true;
                if (gt === 'tv' || gt === 'movie') return true;
                if (/tvg-id="[^"]+"/i.test(String(it.extinfRaw || ''))) return true;
            } catch (e) {}
            return false;
        }
        // تغليف رقيق فوق المصنف (بلا قواعد شبكة: التوزيع من الرابط والاسم فقط)
        function fastClassifyItem(it) {
            try { const c = detectContentType(it); return c || 'live'; } catch (e) { return 'live'; }
        }
        // المرحلة 1 (فورية، بلا شبكة): أسماء + بصمات واضحة أولاً (أفلام/مسلسلات) + وسم الصوت/غير-الفيديو
        function preClassifyOne(it) {
            try {
                if (!it) return;
                try { if ((typeof isAudioUrl === 'function') && isAudioUrl(it.url)) markAudioSus(it); } catch (e) {}
                let c = 'unknown';
                try { c = fastClassifyItem(it) || 'unknown'; } catch (e) {}
                it._fastCat = c;
            } catch (e) {}
        }
        function preClassifySync(list) {
            try { (list || []).forEach(preClassifyOne); } catch (e) {}
        }
        // تصنيف نهائي URL-Only (نموذج MediaParser، بلا شبكة)
        function classifyAll(list) {
            try {
                list.forEach(it => {
                    let c = 'unknown';
                    try { c = fastClassifyItem(it) || 'unknown'; } catch (e) {}
                    if (it._probeLive && c === 'unknown') c = 'live';
                    it._fastCat = c;
                });
            } catch (e) {}
        }
        // خط الاستيراد الفوري (نموذج الملف: بلا شبكة): استخراج ← أسماء ← توزيع URL-Only ← ديالوغ
        async function runStagedImport(items) {
            const list = (items || []).filter(Boolean);
            if (!list.length) { try { progEnd(); } catch (e) {} try { showStatus(tLang('tNoValid'), "error"); } catch (e) {} return; }
            // حارس إعادة الدخول من خط اللصق: مرحلة resolve مملوكة لنفس العملية
            // فيُسمح بالمتابعة (progStart التالي يستبدلها) بدل رفض tBusy الذي
            // كان يترك الزر عالقاً على "جارٍ التعرف على الروابط" للأبد.
            if (typeof importProg !== 'undefined' && importProg && importProg.phase !== 'resolve') { try { showStatus(tLang('tBusy'), "error"); } catch (e) {} return; }
            try { importAbort = false; } catch (e) {}
            progStart('class', 0, list.length);
            try {
                try { preClassifySync(list); } catch (e) {}
                try { progTick(list.length, list.length); } catch (e) {}
                classifyAll(list);
                try { markSuspicious(list); } catch (e) {}
                pendingRawItems = list.filter(it => it && !it._droppedPlaylist);
                isReDocumenting = false;
            } catch (e) {
                try {
                    const m = String((e && e.message) || e || '').slice(0, 120);
                    showStatus(tLang('tPipeFail').replace('{m}', m || '?'), "error");
                } catch (e2) {}
            }
            finally {
                try { progEnd(); } catch (e) {}
            }
            if ((pendingRawItems || []).length) {
                try {
                    openImportDialog();
                } catch (e) {
                    try {
                        const m = String((e && e.message) || e || '').slice(0, 120);
                        showStatus(tLang('tPipeFail').replace('{m}', m || '?'), "error");
                    } catch (e2) {}
                }
                // الديالوغ مفتوح وتفاعلي فوراً — الفحص الذكي يعمل بالخلفية ويحدّث أولاً بأول
                try { runSmartSweep(pendingRawItems); } catch (e) {}
            } else {
                try { showStatus(tLang('tNoValid'), "error"); } catch (e) {}
            }
        }
        // ===== الفحص الذكي اللحظي: يعمل/مكسور + نوع المحتوى (بعد فتح الديالوغ فوراً) =====
        // الديالوغ يُفتح فورياً بالتصنيف الاسمي، ثم يُفحص كل رابط لحظياً بقراءة
        // خفيفة (أول بايتات + نوع المحتوى) وتُحدَّث الشارة والتحديد أولاً بأول —
        // التصنيف (مسلسل/فيلم/مباشر) ثابت لا يتغير، والتحديد اليدوي محترم دائماً.
        // يُدار من الإعدادات: فحص العمل + فحص النوع (CORS/الحجب ⇒ مجهول بلا تغيير).
        let smartSweepToken = 0;
        function stopSmartSweep() { try { smartSweepToken++; } catch (e) {} }
        function applySmartResult(it, sn, aliveOn, kindOn) {
            try {
                if (!it) return false;
                try { it.linkCheckedAt = Date.now(); } catch (e) {}
                if (!sn || sn.kind === 'unknown') { try { if (!it.linkState) it.linkState = 'unknown'; } catch (e) {} return false; }
                let changed = false;
                if (aliveOn) {
                    if (sn.kind === 'dead') { if (it.linkState !== 'dead') { it.linkState = 'dead'; changed = true; } }
                    else if (!it.linkState || it.linkState === 'dead' || it.linkState === 'unknown') { it.linkState = 'ok'; changed = true; }
                }
                if (kindOn) {
                    const was = it._maybeNotVideo || null;
                    // إثبات الفيديو (kind=video) يغلب امتداد الصوت؛ وامتداد الصوت
                    // يُعتد به فقط عندما لا يحسم الشمّ (ليس فيديو/صفحة/قائمة).
                    if (sn.kind === 'audio' || (sn.kind !== 'video' && sn.kind !== 'other' && sn.kind !== 'playlist' && isAudioUrl(it.url))) {
                        if (was !== 'audio') { try { markAudioSus(it); } catch (e) {} changed = true; }
                        else if (!it._susGuess) { try { it._susGuess = audioNameGuess(it); } catch (e) {} }
                    } else if (sn.kind === 'other') {
                        if (was !== 'page') { try { markNonVideoSus(it); } catch (e) {} changed = true; }
                    } else if (sn.kind === 'video' && was) {
                        // ثبت أنه فيديو فعلاً: إسقاط الشارة (الفئة الاسمية تبقى كما هي)
                        try { delete it._maybeNotVideo; } catch (e) {}
                        try { it._suspicious = false; } catch (e) {}
                        changed = true;
                    }
                }
                return changed;
            } catch (e) { return false; }
        }
        function syncImpSelectionSmart(it) {
            try {
                if (!it || !it.id) return;
                const bad = (it.linkState === 'dead') || !!it._maybeNotVideo;
                if (bad) { if (importSelected.has(it.id) && !impManualSel.has(it.id)) importSelected.delete(it.id); }
                else if (!importSelected.has(it.id) && !impManualSel.has(it.id)) { importSelected.add(it.id); }
            } catch (e) {}
        }
        function patchImpRow(it) {
            try {
                if (!it || !it.id || typeof importGroups === 'undefined' || !importGroups) return;
                const cat = importCatById.get(it.id);
                const cb = importAccordion.querySelector('[data-imp-check][data-id="' + String(it.id).replace(/"/g, '&quot;') + '"]');
                if (!cb) { try { updateImportConfirm(); } catch (e) {} return; }
                const kind = cb.getAttribute('data-imp-check');
                if (kind === 'single' && (cat === 'movie' || cat === 'live')) {
                    const row = cb.closest('label');
                    if (row) { try { row.replaceWith(impFlatRow(it, cat)); } catch (e) {} }
                } else if (kind === 'sus') {
                    const row = cb.closest('div');
                    if (row) { try { row.replaceWith(impSusRow(it)); } catch (e) {} }
                } else if (kind === 'ep') {
                    const row = cb.closest('label');
                    if (row) { try { row.replaceWith(impEpRow(it)); } catch (e) {} }
                    try {
                        const anyCb = importAccordion.querySelector('[data-imp-eps] input[data-id="' + String(it.id).replace(/"/g, '&quot;') + '"]');
                        const box = anyCb ? anyCb.closest('[data-imp-eps]') : null;
                        const k = box ? String(box.getAttribute('data-imp-eps') || '').split(':')[0] : null;
                        if (k) impRefreshShowBox(k);
                    } catch (e) {}
                }
                try { updateImportConfirm(); } catch (e) {}
            } catch (e) {}
        }
        async function runSmartSweep(list) {
            const token = ++smartSweepToken;
            let aliveOn = true, kindOn = true;
            try { aliveOn = (typeof isSmartAliveOn === 'function') ? !!isSmartAliveOn() : true; } catch (e) {}
            try { kindOn = (typeof isSmartKindOn === 'function') ? !!isSmartKindOn() : true; } catch (e) {}
            if (!aliveOn && !kindOn) return;
            const items = (list || []).filter(it => it && !it._droppedPlaylist && it.url);
            if (!items.length) return;
            let di = 0, done = 0, okN = 0, deadN = 0, lastPaint = 0;
            try {
                const paint = () => {
                    try {
                        const now = Date.now();
                        if (now - lastPaint < 1000 && done < items.length) return;
                        lastPaint = now;
                        let m = 'smart';
                        try { m = tLang('smartProgress'); } catch (e) {}
                        try { m = String(m).replace('{d}', done).replace('{t}', items.length).replace('{ok}', okN).replace('{dead}', deadN); } catch (e) {}
                        try { showStatus(m, done < items.length ? 'info' : 'success'); } catch (e) {}
                    } catch (e) {}
                };
                const worker = async () => {
                    while (di < items.length) {
                        if (token !== smartSweepToken) return;
                        try { if (importSelectModal.classList.contains('hidden')) { stopSmartSweep(); return; } } catch (e) {}
                        const it = items[di++];
                        let sn = null;
                        try { sn = await sniffFast(it.url, 4000); } catch (e) { sn = null; }
                        if (token !== smartSweepToken) return;
                        try {
                            if (aliveOn && sn && sn.kind === 'dead') deadN++;
                            else if (sn && sn.kind !== 'unknown') okN++;
                        } catch (e) {}
                        let changed = false;
                        try { changed = applySmartResult(it, sn, aliveOn, kindOn); } catch (e) {}
                        if (changed) { try { syncImpSelectionSmart(it); } catch (e) {} try { patchImpRow(it); } catch (e) {} }
                        done++;
                        paint();
                    }
                };
                const pool = [];
                for (let w = 0; w < 24; w++) pool.push(worker());
                paint();
                await Promise.all(pool);
                try { updateImportConfirm(); } catch (e) {}
            } catch (e) {}
        }
        // (أُزيل الإكمال الخلفي: كل المراحل تتم قبل الديالوغ الآن)
        // وسم المشبوهة (بلا شبكة): الغامض بلا فئة فقط ⇒ قسم مستقل غير محدد.
        // الصوت/غير-الفيديو ليس مشبوهاً: فئته المناسبة من الاسم (بشارة 🎧/📄) لكن غير محدد.
        function markSuspicious(list) {
            try {
                (list || []).forEach(it => {
                    if (!it) return;
                    if (it._maybeNotVideo) {
                        try { it._suspicious = false; } catch (e) {}
                        try { it._fastCat = it._susGuess || audioNameGuess(it) || 'live'; } catch (e) {}
                        return;
                    }
                    if (!it._suspicious) {
                        let c = null;
                        try { c = it._fastCat || fastClassifyItem(it); } catch (e) {}
                        if (!c || c === 'unknown') it._suspicious = true;
                        else return;
                    }
                    if (it._suspicious && !it._susGuess) {
                        let g = 'live';
                        try { const c = fastClassifyItem(it); if (c === 'tv' || c === 'movie') g = c; } catch (e) {}
                        try { it._susGuess = g; } catch (e) {}
                    }
                });
            } catch (e) {}
        }
        function groupTvItems(tvItems) {
            const map = new Map();
            tvItems.forEach(it => {
                const k = it.showKey || groupKeyOf(it) || 'unknown';
                if (!map.has(k)) map.set(k, { key: k, title: it.parsedShowTitle || it.cleanTitle || k, seasons: new Map() });
                const s = map.get(k);
                const sn = it.seasonNumber || 1;
                if (!s.seasons.has(sn)) s.seasons.set(sn, []);
                s.seasons.get(sn).push(it);
            });
            return [...map.values()].map(s => ({
                key: s.key, title: s.title,
                seasons: [...s.seasons.entries()].sort((a, b) => a[0] - b[0]).map(([n, eps]) => ({ n, eps: eps.slice().sort((a, b) => (a.episodeNumber || 0) - (b.episodeNumber || 0)) }))
            })).sort((a, b) => String(a.title).localeCompare(String(b.title)));
        }
        function impShowEpIds(show) {
            const ids = [];
            (show.seasons || []).forEach(s => (s.eps || []).forEach(e => ids.push(e.id)));
            return ids;
        }
        function impSeasonEpIds(show, sn) {
            const s = (show.seasons || []).find(x => x.n === sn);
            return s ? s.eps.map(e => e.id) : [];
        }
        function openImportDialog() {
            if (!pendingRawItems || !pendingRawItems.length) {
                showStatus(tLang('tNoValid'), "error");
                return;
            }
            const part = partitionPending();
            importGroups = {
                tvShows: groupTvItems(part.tv),
                movie: part.movie.slice().sort((a, b) => String(a.cleanTitle || '').localeCompare(String(b.cleanTitle || ''))),
                live: part.live.slice().sort((a, b) => String(a.cleanTitle || '').localeCompare(String(b.cleanTitle || ''))),
                sus: part.sus.slice().sort(impDeadFirst)
            };
            // المكسور والصوت/غير-الفيديو غير محددين افتراضياً + شارة (يُحدَّدان يدوياً فقط).
            // المشبوهة غير محددة + فئتها المقترحة من الاسم (تُؤكَّد أو تُغيَّر عند التحديد).
            importSelected = new Set();
            importCatById = new Map();
            try { impByIdMap = new Map(); impSeenIds = new Set(); impManualSel = new Set(); } catch (e) {}
            part.tv.forEach(it => { try { impByIdMap.set(it.id, it); impSeenIds.add(it.id); } catch (e) {} importCatById.set(it.id, 'tv'); if (it.linkState !== 'dead' && !it._maybeNotVideo) importSelected.add(it.id); });
            part.movie.forEach(it => { try { impByIdMap.set(it.id, it); impSeenIds.add(it.id); } catch (e) {} importCatById.set(it.id, 'movie'); if (it.linkState !== 'dead' && !it._maybeNotVideo) importSelected.add(it.id); });
            part.live.forEach(it => { try { impByIdMap.set(it.id, it); impSeenIds.add(it.id); } catch (e) {} importCatById.set(it.id, 'live'); if (it.linkState !== 'dead' && !it._maybeNotVideo) importSelected.add(it.id); });
            part.sus.forEach(it => { try { impByIdMap.set(it.id, it); impSeenIds.add(it.id); } catch (e) {} importCatById.set(it.id, it._susGuess || 'none'); }); // المشبوهة: غير محددة + فئة مقترحة
            try {
                impSearch = { tv: '', movie: '', live: '', sus: '' };
                document.querySelectorAll('#importAccordion [data-imp-search]').forEach(el => { try { el.value = ''; } catch (e) {} });
            } catch (e) {}
            impRenderedCount = { movie: IMP_MORE_STEP, live: IMP_MORE_STEP, sus: IMP_MORE_STEP };
            impRenderedShows = IMP_SHOW_STEP;
            impExpandedShows.clear();
            impExpandedSeasons.clear();
            importOpenSection = importGroups.tvShows.length ? 'tv' : (importGroups.movie.length ? 'movie' : (importGroups.live.length ? 'live' : 'sus'));
            renderImportDialog();
            importSelectModal.classList.remove('hidden');
            importSelectModal.classList.add('flex');
            updateImportConfirm();
        }
        function closeImportDialog() {
            try { importAbort = true; } catch (e) {}
            try { stopSmartSweep(); } catch (e) {}
            importSelectModal.classList.add('hidden');
            importSelectModal.classList.remove('flex');
            pendingRawItems = [];
            importSelected = new Set();
            importGroups = null;
        }
        function setImpOpen(name) {
            importOpenSection = name;
            document.querySelectorAll('#importAccordion .imp-acc-body').forEach(b => {
                const isOpen = b.dataset.impBody === name;
                b.style.maxHeight = isOpen ? '60vh' : '0px';
                if (isOpen) b.style.overflowY = 'auto'; else b.style.overflowY = 'hidden';
            });
            document.querySelectorAll('#importAccordion .imp-acc-head').forEach(h => {
                const chev = h.querySelector('.imp-chev');
                if (chev) chev.style.transform = h.dataset.imp === name ? 'rotate(180deg)' : '';
            });
        }
        function renderImportDialog() {
            if (!importGroups) return;
            const tvEps = importGroups.tvShows.reduce((a, s) => a + s.seasons.reduce((x, se) => x + se.eps.length, 0), 0);
            document.getElementById('impCountTv').textContent = importGroups.tvShows.length ? (importGroups.tvShows.length + ' ' + tLang('tabTv') + ' • ' + tvEps + ' ' + tLang('episodesWord')) : '0';
            document.getElementById('impCountMovie').textContent = String(importGroups.movie.length);
            document.getElementById('impCountLive').textContent = String(importGroups.live.length);
            try { document.getElementById('impCountSus').textContent = String((importGroups.sus || []).length); } catch (e) {}
            try { impSusSection.classList.toggle('hidden', (importGroups.sus || []).length === 0); } catch (e) {}
            if (importSummaryLine) importSummaryLine.textContent = tLang('tabTv') + ': ' + importGroups.tvShows.length + ' (' + tvEps + ' ' + tLang('episodesWord') + ') • ' + tLang('tabMovie') + ': ' + importGroups.movie.length + ' • ' + tLang('tabLive') + ': ' + importGroups.live.length + ((importGroups.sus || []).length ? ' • ' + tLang('impSus') + ': ' + importGroups.sus.length : '');
            renderImpTv();
            renderImpFlat('movie');
            renderImpFlat('live');
            renderImpSus();
            setImpOpen(importOpenSection);
            updateImportConfirm();
        }
        function impShowCheckState(show) {
            const ids = impShowEpIds(show);
            const sel = ids.filter(id => importSelected.has(id)).length;
            return { all: ids.length > 0 && sel === ids.length, some: sel > 0 && sel < ids.length };
        }
        function impSeasonCheckState(show, sn) {
            const ids = impSeasonEpIds(show, sn);
            const sel = ids.filter(id => importSelected.has(id)).length;
            return { all: ids.length > 0 && sel === ids.length, some: sel > 0 && sel < ids.length };
        }
        function renderImpTv() {
            impTvList.innerHTML = '';
            const allShows = importGroups.tvShows || [];
            // بحث داخل الفئة: ترشيح المسلسلات بالعنوان (يبقى العدد الكلي في الشارة)
            let q = '';
            try { q = (impSearch.tv || '').toLowerCase(); } catch (e) {}
            const shows = (!q) ? allShows : allShows.filter(s => String(s.title || '').toLowerCase().indexOf(q) >= 0);
            if (!shows.length) {
                impTvList.innerHTML = '<div class="text-center py-3 text-slate-500 text-[11px]">' + (!allShows.length ? tLang('impTvEmpty') : tLang('noResults')) + '</div>';
                try { impTvMore.classList.add('hidden'); } catch (e) {}
                return;
            }
            // سقف عرض فقط (بلا حد على البيانات): القوائم الضخمة تُعرض دفعات لتفادي تجميد المتصفح
            shows.slice(0, impRenderedShows).forEach(show => {
                const st = impShowCheckState(show);
                const epCount = show.seasons.reduce((a, s) => a + s.eps.length, 0);
                const box = document.createElement('div');
                box.className = "bg-slate-900 border border-slate-800 rounded-lg overflow-hidden";
                box.innerHTML = '<div class="flex items-center gap-2 px-2.5 py-2">'
                    + '<input type="checkbox" data-imp-check="show" data-show="' + escImp(show.key) + '" class="w-4 h-4 accent-emerald-500 cursor-pointer flex-shrink-0"' + (st.all ? ' checked' : '') + '>'
                    + '<button data-imp-expand-show="' + escImp(show.key) + '" class="flex-1 min-w-0 text-right cursor-pointer">'
                    + '<span class="block text-xs font-bold text-slate-200 truncate">' + escImp(show.title) + '</span>'
                    + '<span class="block text-[10px] text-slate-500">' + show.seasons.length + ' ' + tLang('seasonLabel') + ' • ' + epCount + ' ' + tLang('episodesWord') + '</span></button>'
                    + '<i class="fa-solid fa-chevron-down text-slate-500 text-[10px]"></i></div>'
                    + '<div class="hidden px-2 pb-2 flex-col gap-1" data-imp-seasons="' + escImp(show.key) + '"></div>';
                const cb = box.querySelector('[data-imp-check="show"]');
                if (st.some) cb.indeterminate = true;
                impTvList.appendChild(box);
                if (impExpandedShows.has(show.key)) expandImpShow(show.key, box);
            });
            try {
                if (shows.length > impRenderedShows) {
                    impTvMore.classList.remove('hidden');
                    impTvMore.textContent = tLang('showMore') + ' (' + impRenderedShows + ' / ' + shows.length + ')';
                } else impTvMore.classList.add('hidden');
            } catch (e) {}
        }
        function expandImpShow(showKey, scopeBox) {
            const show = importGroups.tvShows.find(s => s.key === showKey);
            if (!show) return;
            const ctn = (scopeBox || impTvList).querySelector('[data-imp-seasons="' + showKey.replace(/"/g, '&quot;') + '"]');
            if (!ctn) return;
            ctn.classList.remove('hidden');
            ctn.classList.add('flex');
            if (!ctn.children.length) {
                show.seasons.forEach(se => {
                    const sst = impSeasonCheckState(show, se.n);
                    const row = document.createElement('div');
                    row.className = "bg-slate-950 border border-slate-800/80 rounded-lg overflow-hidden";
                    row.innerHTML = '<div class="flex items-center gap-2 px-2 py-1.5">'
                        + '<input type="checkbox" data-imp-check="season" data-show="' + escImp(show.key) + '" data-season="' + se.n + '" class="w-4 h-4 accent-amber-500 cursor-pointer flex-shrink-0"' + (sst.all ? ' checked' : '') + '>'
                        + '<button data-imp-expand-season="' + escImp(show.key) + ':' + se.n + '" class="flex-1 text-right text-[11px] font-bold text-slate-300 cursor-pointer">' + tLang('seasonLabel') + ' ' + se.n + ' <span class="text-slate-500 font-normal">(' + se.eps.length + ' ' + tLang('episodesWord') + ')</span></button>'
                        + '<i class="fa-solid fa-chevron-down text-slate-600 text-[10px]"></i></div>'
                        + '<div class="hidden px-2 pb-1.5 flex-col gap-1" data-imp-eps="' + escImp(show.key) + ':' + se.n + '"></div>';
                    const scb = row.querySelector('[data-imp-check="season"]');
                    if (sst.some) scb.indeterminate = true;
                    ctn.appendChild(row);
                    if (impExpandedSeasons.has(show.key + ':' + se.n)) expandImpSeason(show.key, se.n, row);
                });
            }
        }
        function impEpRow(ep) {
            const code = 'S' + String(ep.seasonNumber || 1).padStart(2, '0') + 'E' + String(ep.episodeNumber || 1).padStart(2, '0');
            const lbl = ep.episodeTitle || ep.cleanTitle || ('#' + (ep.episodeNumber || 1));
            const epMins = (ep.durationMin != null && isFinite(+ep.durationMin)) ? (' <span class="text-sky-300 text-[10px]">⏱' + (Math.round(+ep.durationMin * 10) / 10) + '</span>') : '';
            const epDead = (ep.linkState === 'dead') ? (' <span class="text-[9px] font-bold px-1 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/80">🔗 ' + tLang('linkDead') + '</span>') : '';
            const r = document.createElement('label');
            r.className = "flex items-center gap-2 px-2 py-1.5 bg-slate-900 border border-slate-800/60 rounded-lg cursor-pointer text-[11px] text-slate-300 hover:border-emerald-500/40 transition";
            r.innerHTML = '<input type="checkbox" data-imp-check="ep" data-id="' + escImp(ep.id) + '" class="w-3.5 h-3.5 accent-emerald-500 cursor-pointer flex-shrink-0"' + (importSelected.has(ep.id) ? ' checked' : '') + '>'
                + '<span class="text-emerald-500/90 font-bold flex-shrink-0">' + code + '</span>'
                + '<span class="truncate">' + escImp(lbl) + epMins + epDead + ((ep._maybeNotVideo) ? (' <span class="text-[9px] font-bold px-1 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + (ep._maybeNotVideo === 'page' ? '📄' : '🎧') + ' ' + tLang('impMaybeNotVideo') + '</span>') : '') + '</span>';
            return r;
        }
        function expandImpSeason(showKey, sn, scopeRow) {
            const show = importGroups.tvShows.find(s => s.key === showKey);
            if (!show) return;
            const se = show.seasons.find(s => s.n === sn);
            if (!se) return;
            const ctn = (scopeRow || impTvList).querySelector('[data-imp-eps="' + showKey.replace(/"/g, '&quot;') + ':' + sn + '"]');
            if (!ctn) return;
            ctn.classList.remove('hidden');
            ctn.classList.add('flex');
            if (!ctn.children.length) {
                se.eps.forEach(ep => ctn.appendChild(impEpRow(ep)));
            }
        }
        function impFlatRow(it, kind) {
            const lbl = kind === 'live'
                ? (it.rawTitle || '').replace(/^-1,?\s*/, '').trim()
                : (it.cleanTitle || it.rawTitle || it.url);
            const sub = (kind === 'movie' && (it.year || it.resolution || it.quality)) ? (' <span class="text-slate-500">(' + escImp([it.year, it.resolution, it.quality].filter(Boolean).join(' • ')) + '</span>') : '';
            const mins = (it.durationMin != null && isFinite(+it.durationMin)) ? (' <span class="text-sky-300">⏱' + (Math.round(+it.durationMin * 10) / 10) + '</span>') : '';
            const dead = (it.linkState === 'dead') ? (' <span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/80">🔗 ' + tLang('linkDead') + '</span>') : '';
            const r = document.createElement('label');
            r.className = "flex items-center gap-2 px-2.5 py-2 bg-slate-900 border border-slate-800 rounded-lg cursor-pointer text-[11px] text-slate-200 hover:border-emerald-500/40 transition";
            r.innerHTML = '<input type="checkbox" data-imp-check="single" data-id="' + escImp(it.id) + '" class="w-4 h-4 accent-emerald-500 cursor-pointer flex-shrink-0"' + (importSelected.has(it.id) ? ' checked' : '') + '>'
                + '<span class="truncate">' + escImp(lbl) + sub + mins + dead + ((it._maybeNotVideo) ? (' <span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + (it._maybeNotVideo === 'page' ? '📄' : '🎧') + ' ' + tLang('impMaybeNotVideo') + '</span>') : '') + '</span>';
            return r;
        }
        function impDeadFirst(a, b) {
            const da = (a && a.linkState === 'dead') ? 1 : 0, db = (b && b.linkState === 'dead') ? 1 : 0;
            return db - da; // المكسور يُعزل أولاً
        }
        function impFlatText(it, kind) {
            try {
                const lbl = kind === 'live' ? String(it.rawTitle || '').replace(/^-1,?\s*/, '').trim() : String(it.cleanTitle || it.rawTitle || it.url || '');
                return (lbl + ' ' + (it.year || '') + ' ' + (it.resolution || '') + ' ' + (it.quality || '') + ' ' + (it.url || '')).toLowerCase();
            } catch (e) { return ''; }
        }
        function renderImpFlat(kind) {
            const list = kind === 'movie' ? impMovieList : impLiveList;
            const full = (kind === 'movie' ? importGroups.movie : importGroups.live).slice().sort(impDeadFirst);
            let q = '';
            try { q = (impSearch[kind] || '').toLowerCase(); } catch (e) {}
            const arr = (!q) ? full : full.filter(it => impFlatText(it, kind).indexOf(q) >= 0);
            const moreBtn = kind === 'movie' ? impMovieMore : impLiveMore;
            list.innerHTML = '';
            if (!arr.length) {
                list.innerHTML = '<div class="text-center py-3 text-slate-500 text-[11px]">' + (!full.length ? (kind === 'movie' ? tLang('impMovieEmpty') : tLang('impLiveEmpty')) : tLang('noResults')) + '</div>';
                moreBtn.classList.add('hidden');
                return;
            }
            arr.slice(0, impRenderedCount[kind]).forEach(it => list.appendChild(impFlatRow(it, kind)));
            if (arr.length > impRenderedCount[kind]) {
                moreBtn.classList.remove('hidden');
                moreBtn.textContent = tLang('showMore') + ' (' + impRenderedCount[kind] + ' / ' + arr.length + ')';
            } else moreBtn.classList.add('hidden');
        }
        // قسم المشبوهة: صوت فقط/غير-فيديو (بشارة 🎧/📄)، ميت بلا معلومات، أو غامض.
        // غير محدد افتراضياً، وفئته مقترحة من الاسم — تُفعَّل القائمة بتحديد الرابط،
        // وعند التأكيد يُجبر المستخدم على فئة من الثلاثة لكل محدد ما زال 'غير محدد'.
        function impSusRow(it) {
            const lbl = it.cleanTitle || it.rawTitle || it.url;
            const cat = importCatById.get(it.id) || 'none';
            const checked = importSelected.has(it.id);
            const isDead = it.linkState === 'dead';
            const mins = (!isDead && it.durationMin != null && isFinite(+it.durationMin)) ? (' <span class="text-sky-300">⏱' + (Math.round(+it.durationMin * 10) / 10) + '</span>') : '';
            const dead = isDead ? (' <span class="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800/80">🔗 ' + tLang('linkDead') + '</span>') : '';
            const nb = it._maybeNotVideo ? (' <span class="text-[9px] font-bold px-1 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800/80">' + (it._maybeNotVideo === 'page' ? '📄' : '🎧') + ' ' + tLang('impMaybeNotVideo') + '</span>') : '';
            const r = document.createElement('div');
            r.className = "flex items-center gap-2 px-2.5 py-2 bg-rose-950/30 border border-rose-900/50 rounded-lg text-[11px]";
            r.innerHTML = '<input type="checkbox" data-imp-check="sus" data-id="' + escImp(it.id) + '" class="w-4 h-4 accent-rose-500 cursor-pointer flex-shrink-0"' + (checked ? ' checked' : '') + '>'
                + '<span class="truncate flex-1 text-slate-200">' + escImp(lbl) + mins + dead + nb + '</span>'
                + '<select data-imp-catchange="' + escImp(it.id) + '"' + (checked ? '' : ' disabled') + ' class="bg-slate-950 border border-slate-700 rounded-lg text-[11px] text-slate-200 px-1.5 py-1 cursor-pointer flex-shrink-0 disabled:opacity-40">'
                + '<option value="none"' + (cat === 'none' ? ' selected' : '') + '>' + tLang('impCatNone') + '</option>'
                + '<option value="tv"' + (cat === 'tv' ? ' selected' : '') + '>' + tLang('tabTv') + '</option>'
                + '<option value="movie"' + (cat === 'movie' ? ' selected' : '') + '>' + tLang('tabMovie') + '</option>'
                + '<option value="live"' + (cat === 'live' ? ' selected' : '') + '>' + tLang('tabLive') + '</option></select>';
            return r;
        }
        function renderImpSus() {
            try { impSusList.innerHTML = ''; } catch (e) { return; }
            const full = ((importGroups && importGroups.sus) || []).slice().sort(impDeadFirst);
            let q = '';
            try { q = (impSearch.sus || '').toLowerCase(); } catch (e) {}
            const arr = (!q) ? full : full.filter(it => String((it.cleanTitle || '') + ' ' + (it.rawTitle || '') + ' ' + (it.url || '')).toLowerCase().indexOf(q) >= 0);
            if (!arr.length) {
                try {
                    impSusList.innerHTML = '<div class="text-center py-3 text-slate-500 text-[11px]">' + (!full.length ? '' : tLang('noResults')) + '</div>';
                } catch (e) {}
                try { impSusMore.classList.add('hidden'); } catch (e) {}
                return;
            }
            arr.slice(0, impRenderedCount.sus).forEach(it => { try { impSusList.appendChild(impSusRow(it)); } catch (e) {} });
            try {
                if (arr.length > impRenderedCount.sus) {
                    impSusMore.classList.remove('hidden');
                    impSusMore.textContent = tLang('showMore') + ' (' + impRenderedCount.sus + ' / ' + arr.length + ')';
                } else impSusMore.classList.add('hidden');
            } catch (e) {}
        }
        function updateImportConfirm() {
            const n = importSelected.size;
            confirmImportBtn.textContent = tLang('tAddSelected').replace('{n}', n);
            confirmImportBtn.classList.toggle('opacity-40', n === 0);
        }
        function impRefreshShowBox(showKey) {
            const show = importGroups.tvShows.find(s => s.key === showKey);
            if (!show) return;
            const cb = impTvList.querySelector('[data-imp-check="show"][data-show="' + showKey.replace(/"/g, '&quot;') + '"]');
            if (cb) {
                const st = impShowCheckState(show);
                cb.checked = st.all;
                cb.indeterminate = st.some;
            }
            show.seasons.forEach(se => {
                const scb = impTvList.querySelector('[data-imp-check="season"][data-show="' + showKey.replace(/"/g, '&quot;') + '"][data-season="' + se.n + '"]');
                if (scb) {
                    const sst = impSeasonCheckState(show, se.n);
                    scb.checked = sst.all;
                    scb.indeterminate = sst.some;
                }
            });
        }
        // تفويض الأحداث (يبقى بعد إعادة الرسم): توسيع الأقسام، تحديد/إلغاء، المزيد، الشيك بوكسات
        importAccordion.addEventListener('click', (e) => {
            const head = e.target.closest('.imp-acc-head');
            if (head) {
                const name = head.dataset.imp;
                setImpOpen(importOpenSection === name ? null : name);
                return;
            }
            const exS = e.target.closest('[data-imp-expand-show]');
            if (exS) {
                const k = exS.getAttribute('data-imp-expand-show');
                if (impExpandedShows.has(k)) {
                    impExpandedShows.delete(k);
                    const ctn = impTvList.querySelector('[data-imp-seasons="' + k.replace(/"/g, '&quot;') + '"]');
                    if (ctn) { ctn.classList.add('hidden'); ctn.classList.remove('flex'); }
                } else {
                    impExpandedShows.add(k);
                    expandImpShow(k, impTvList);
                }
                return;
            }
            const exSe = e.target.closest('[data-imp-expand-season]');
            if (exSe) {
                const [k, sn] = exSe.getAttribute('data-imp-expand-season').split(':');
                const n = parseInt(sn, 10);
                const ck = k + ':' + n;
                if (impExpandedSeasons.has(ck)) {
                    impExpandedSeasons.delete(ck);
                    const ctn = impTvList.querySelector('[data-imp-eps="' + k.replace(/"/g, '&quot;') + ':' + n + '"]');
                    if (ctn) { ctn.classList.add('hidden'); ctn.classList.remove('flex'); }
                } else {
                    impExpandedSeasons.add(ck);
                    expandImpSeason(k, n, impTvList);
                }
                return;
            }
            const allB = e.target.closest('[data-imp-all]');
            if (allB) {
                const c = allB.getAttribute('data-imp-all');
                // تحديد الكل يتجاوز المكسور دائماً (المكسور يُحدَّد يدوياً فقط)
                try {
                    if (c === 'tv') importGroups.tvShows.forEach(s => impShowEpIds(s).forEach(id => { const it = impByIdMap.get(id); if (it && it.linkState !== 'dead' && !it._maybeNotVideo) { importSelected.add(id); impManualSel.add(id); } }));
                    else (c === 'movie' ? importGroups.movie : importGroups.live).forEach(it => { if (it && it.linkState !== 'dead' && !it._maybeNotVideo) { importSelected.add(it.id); try { impManualSel.add(it.id); } catch (e2) {} } });
                } catch (e2) {}
                renderImportDialog();
                setImpOpen(c);
                return;
            }
            const noneB = e.target.closest('[data-imp-none]');
            if (noneB) {
                const c = noneB.getAttribute('data-imp-none');
                if (c === 'tv') importGroups.tvShows.forEach(s => impShowEpIds(s).forEach(id => importSelected.delete(id)));
                else (c === 'movie' ? importGroups.movie : importGroups.live).forEach(it => importSelected.delete(it.id));
                renderImportDialog();
                setImpOpen(c);
                return;
            }
        });
        importAccordion.addEventListener('change', (e) => {
            const t = e.target;
            if (t.matches('[data-imp-catchange]')) {
                importCatById.set(t.getAttribute('data-imp-catchange'), t.value);
                return;
            }
            if (!t.matches('[data-imp-check]')) return;
            const kind = t.getAttribute('data-imp-check');
            const on = t.checked;
            if (kind === 'ep' || kind === 'single') {
                const id = t.getAttribute('data-id');
                if (on) importSelected.add(id); else importSelected.delete(id);
                try { impManualSel.add(id); } catch (e) {}
                if (kind === 'ep') {
                    const row = t.closest('[data-imp-eps]');
                    if (row) {
                        const [k, sn] = row.getAttribute('data-imp-eps').split(':');
                        impRefreshShowBox(k);
                    }
                }
            } else if (kind === 'sus') {
                // المشبوهة: التحديد يفعّل قائمة الفئة إجبارياً، وإلغاؤه يعيدها لغير محدد
                const id = t.getAttribute('data-id');
                const row = t.closest('div');
                const sel = row ? row.querySelector('select[data-imp-catchange]') : null;
                if (on) {
                    importSelected.add(id);
                    try { impManualSel.add(id); } catch (e) {}
                    if (sel) {
                        sel.disabled = false;
                        const cur = importCatById.get(id) || 'none';
                        if (cur === 'none') { try { sel.focus({ preventScroll: true }); } catch (e2) { try { sel.focus(); } catch (e3) {} } }
                    }
                } else {
                    importSelected.delete(id);
                    try { impManualSel.add(id); } catch (e) {}
                    importCatById.set(id, 'none');
                    if (sel) { sel.disabled = true; try { sel.value = 'none'; } catch (e2) {} }
                }
            } else if (kind === 'season') {
                const k = t.getAttribute('data-show');
                const n = parseInt(t.getAttribute('data-season'), 10);
                const show = importGroups.tvShows.find(s => s.key === k);
                if (show) impSeasonEpIds(show, n).forEach(id => { if (on) importSelected.add(id); else importSelected.delete(id); try { impManualSel.add(id); } catch (e) {} });
                impRefreshShowBox(k);
            } else if (kind === 'show') {
                const k = t.getAttribute('data-show');
                const show = importGroups.tvShows.find(s => s.key === k);
                if (show) {
                    impShowEpIds(show).forEach(id => { if (on) importSelected.add(id); else importSelected.delete(id); try { impManualSel.add(id); } catch (e) {} });
                    impTvList.querySelectorAll('[data-imp-seasons] input[data-imp-check], [data-imp-eps] input[data-imp-check]').forEach(cb => {
                        const sid = cb.getAttribute('data-id');
                        const sk = cb.getAttribute('data-show');
                        if ((sid && impShowEpIds(show).includes(sid)) || (sk === k && (cb.getAttribute('data-imp-check') === 'season'))) {
                            cb.checked = on;
                            cb.indeterminate = false;
                        }
                    });
                }
                impRefreshShowBox(k);
            }
            updateImportConfirm();
        });
        // بحث داخل كل فئة من الأربع (ترشيح حي، يُحترم مع دفعات "عرض المزيد")
        importAccordion.addEventListener('input', (e) => {
            const t = e.target;
            if (!t || !t.matches || !t.matches('[data-imp-search]')) return;
            const k = t.getAttribute('data-imp-search');
            try { impSearch[k] = String(t.value || '').trim().toLowerCase(); } catch (e2) {}
            try { clearTimeout(__impSearchT); } catch (e2) {}
            __impSearchT = setTimeout(() => {
                try {
                    if (k === 'tv') renderImpTv();
                    else if (k === 'movie' || k === 'live') renderImpFlat(k);
                    else renderImpSus();
                } catch (e2) {}
            }, 200);
        });
        function restoreImpSearchInputs() {
            try {
                document.querySelectorAll('#importAccordion [data-imp-search]').forEach(el => {
                    const k = el.getAttribute('data-imp-search');
                    const v = (impSearch && impSearch[k]) || '';
                    if (String(el.value || '') !== v) { try { el.value = v; } catch (e) {} }
                });
            } catch (e) {}
        }
        // (أُزيل التحديث الحي وإعادة التقسيم: كل المراحل تتم قبل الديالوغ الآن)
        impMovieMore.addEventListener('click', () => {
            impRenderedCount.movie += IMP_MORE_STEP;
            renderImpFlat('movie');
        });
        impLiveMore.addEventListener('click', () => {
            impRenderedCount.live += IMP_MORE_STEP;
            renderImpFlat('live');
        });
        impTvMore.addEventListener('click', () => {
            impRenderedShows += IMP_SHOW_STEP;
            renderImpTv();
        });
        impSusMore.addEventListener('click', () => {
            impRenderedCount.sus += IMP_MORE_STEP;
            renderImpSus();
        });
        cancelImportBtn.addEventListener('click', closeImportDialog);
        closeImportModalBtn.addEventListener('click', closeImportDialog);
        confirmImportBtn.addEventListener('click', () => {
            commitImportSelection();
        });
        function hasSeriesCode(s) {
            const t = ' ' + String(s || '').replace(/[._\-+()\[\]{}]+/g, ' ') + ' ';
            if (/\bS\d{1,4}\s*E(?!(?:19|20)\d{2}\b)\d{1,4}\b/i.test(t)) return true;
            if (/\b\d{1,2}x\d{1,3}\b/i.test(t)) return true;
            if (/\bSeason\s*\d{1,2}\b/i.test(t)) return true;
            if (/\bE(?:p(?:isode)?)?[\s.]*(?!(?:19|20)\d{2}\b)\d{1,4}\b/i.test(t)) return true;
            if (SCENE_DATE_RE.test(t)) return true;
            if (/\bcomplete\b/i.test(t) && /\b(season|s\d{1,4}|pack|boxset|collection|series|موسم)\b/i.test(t)) return true;
            if (/\bS\d{1,4}\b/i.test(t) && /(complete|pack|boxset|season|موسم|1080p|720p|2160p|4k|bluray|web|hdtv|x26[45]|hevc)/i.test(t)) return true;
            if (/الموسم\s*\d{1,2}/.test(t)) return true;
            if (/(?:الحلقة|حلقة)\s*\d{1,3}/.test(t)) return true;
            return false;
        }
        function hasYear(s) { return /\b(19\d{2}|20\d{2})\b/.test(String(s || '')); }
        // رموز مسلسلات قوية فقط (S01E01/season/التاريخ): الضعيفة
        // (2x2/S1 المنفردة/EP12/pack/أسماء مثل E4) قد تكون اسم قناة
        // أو جزء معرّف بث (UUID) فلا تحسم ضد tvg-id
        function strongSeriesCode(s) {
            const t = ' ' + String(s || '').replace(/[._\-+()\[\]{}]+/g, ' ') + ' ';
            if (/\bS\d{1,4}\s*E(?!(?:19|20)\d{2}\b)\d{1,4}\b/i.test(t)) return true;
            if (/\bSeason\s*\d{1,2}\b/i.test(t)) return true;
            if (/الموسم\s*\d{1,2}/.test(t)) return true;
            if (SCENE_DATE_RE.test(t)) return true;
            return false;
        }
        function techPositive(s) {
            const t = String(s || '');
            if (sceneStrongTest(t)) return true;
            // ambiguous-but-real source tags count beside a year ("Film.2021.WEB", "Film.2020.TS")
            if (/\b(TS|TC|WEB|DVD|HD|SD)\b/i.test(t) && /\b(19\d{2}|20\d{2})\b/.test(t)) return true;
            const soft = t.match(SCENE_SOFT_RE);
            if ((soft ? soft.length : 0) >= 2) return true;
            const weak = t.match(/(aac|ac3|eac3|dts|ddp\d?\.?\d?|mp3|flac|opus|sub|subs|subbed|dub|dubbed|dual|multi|ita|eng|fre|fra|ger|spa|ara|arabic|hindi|turk|kor|fps|bit|french|spanish|german|italian|netflix|amzn|dsnp|hbo|hulu|proper|repack|rerip|extended|unrated|remastered|limited|uncut|theatrical|imax|hdr\d*\+?|dolby|vision|hlg|sdr|vostfr|truefrench|complete|pack|boxset|collection)/gi);
            return (weak ? weak.length : 0) >= 2;
        }
        function hasSeasonFolder(url) {
            let segs = [];
            try { segs = new URL(url).pathname.split('/').filter(Boolean); }
            catch (e) { segs = String(url || '').split('/').filter(Boolean); }
            segs = segs.slice(0, -1);
            const t = segs.join(' ').toLowerCase();
            return /\bseason\s*\d{1,4}\b/.test(t) || /(^|\s)s\d{1,4}(\s|$)/.test(t) || /موسم\s*\d{1,2}/.test(t);
        }
        function groupHintOf(g) {
            const t = String(g || '').toLowerCase();
            if (!t) return null;
            if (/(series|shows?|saison|s[ée]rie|serie|مسلسل|مسلسلات)/.test(t)) return 'tv';
            if (/\b(movies?|films?|vod|vod-film|cine|cinema|أفلام|افلام|فيلم)\b/.test(t)) return 'movie';
            if (/(live|\btv\b|television|channels?|chaines?|news|sports?|kids|music|docu|relig|قنوات|مباشر|بث|أخبار|اخبار|رياضة|رياضه|أطفال|اطفال|دينية|وثائقية)/.test(t)) return 'live';
            return null;
        }
        // المصنف URL-Only بأولوية نموذج MediaParser (فوري، بلا شبكة):
        // مسلسل ⇒ رموز S/E القوية أو مجلد Season أو حلقة داخل مجلد مرقم؛
        // قناة ⇒ tvg-id بلا ملف VOD يغلب كل إشارة ضعيفة (الدقة وحدها ليست دليل VOD،
        // ومجلدات الخوادم S2/s123 ليست مواسم، ومسار vod وحده لا يغلب دليل القنوات)؛
        // مباشر ⇒ بث صريح بلا سنة/مصدر/ترميز حقيقي؛ فيلم ⇒ سنة/مصدر/ترميز/دقة/ملف/مجلد؛ وإلا مباشر.
        function detectContentType(item) {
            try {
                const url = String((item && item.url) || '');
                const raw = String((item && item.rawTitle) || '');
                const ext = String((item && item.extinfRaw) || '');
                const low = url.toLowerCase();
                let fname = '';
                try {
                    const segs = new URL(url).pathname.split('/').filter(Boolean);
                    fname = segs.length ? segs[segs.length - 1] : '';
                } catch (e) {
                    const parts = url.split('/').filter(Boolean);
                    fname = parts.length ? parts[parts.length - 1] : '';
                }
                try { fname = decodeURIComponent(fname); } catch (e) {}
                const blob = fname + ' ' + raw;
                const yr = hasYear(blob) || !!((item && item.year));
                const srcFile = /\b(bluray|blu-ray|brrip|bdrip|web-?dl|webrip|hdtv|hdcam|hdts|dvdrip|dvdscr|remux|uhd|teLESYNC|telecine|pdtv|camrip|cam)\b/i.test(blob);
                const codecOrRes = /\b(x26[45]|hevc|h\.?26[45]|avc|av1|vc-?1|xvid|divx|vp9|mpeg-?[24])\b/i.test(blob) || /\b(2160|1080|720|480|576|4320)[pi]\b|\b(4K|UHD|8K)\b/i.test(blob)
                    || !!((item && (item.resolution || item.quality || item.codec)));
                // الدقة وحدها (1080p/720p/...) ليست دليل VOD — القنوات تحملها أيضاً؛
                // الترميز الحقيقي فقط (x265/HEVC/AVC/...) يمنع حسم البث المباشر.
                const codecReal = /\b(x26[45]|hevc|h\.?26[45]|avc|av1|vc-?1|xvid|divx|vp9|mpeg-?[24])\b/i.test(blob);
                const movieFolder = /\b(movies?|films?|vod|cinema|أفلام|افلام)\b/i.test(low);
                const gm = ext.match(/group-title="([^"]*)"/i);
                const gt = gm ? groupHintOf(gm[1]) : null;
                const streamT = /\.(ts|m3u8|mpd)($|\?)|\.php(\?|$)|[?&](token|auth)=|\/\d+:\d+:[0-9a-fA-F:]{5,}(\/|$|\?)/i.test(url) || /\/live\//i.test(url) || /(^|[\/_.:-])live([_-]|\/|$)/i.test(url);
                const hasTvg = /tvg-id="[^"]+"/i.test(ext);
                const isVideoFile = /\.(mp4|mkv|avi|wmv|flv|m4v|mov|mpg|mpeg|vob|webm)($|\?)/i.test(url);
                // مقاطع المسار بلا اسم الملف — لكشف مجلد season الحقيقي من مجلدات
                // الخوادم (S2/HLS_LIVE/s123) التي تتشابه مع ترقيم المواسم.
                let pathSegs = [];
                try { pathSegs = new URL(url).pathname.split('/').filter(Boolean); }
                catch (e) { try { pathSegs = String(url).split('?')[0].split('/').filter(Boolean); } catch (e2) {} }
                const pathNoFile = pathSegs.slice(0, -1).join(' ');
                const seasonWord = /\bseason\s*\d|موسم\s*\d/i.test(pathNoFile);
                const epInFname = /\bE(?:p(?:isode)?)?[\s.]*(?!(?:19|20)\d{2}\b)\d{1,4}\b/i.test(fname);
                const xm = low.match(/\/(live|movies?|films?|vod|series|shows)(\/|$|\?)/);
                if (xm) {
                    const k = xm[1];
                    if (k === 'live') return 'live';
                    if (k === 'series' || k === 'shows') return 'tv';
                    // مسار VOD وحده بلا أي دليل VOD آخر لا يغلب دليل القنوات:
                    // tvg-id + رابط بث + بلا (سنة/مصدر/ترميز/ملف) ⇒ قناة
                    // (روابط إعادة البث تحت مسارات vod)، وإلا فيلم كالمعتاد.
                    if (hasTvg && streamT && !isVideoFile && !yr && !srcFile && !codecReal) return 'live';
                    return 'movie';
                }
                // دليل القنوات يغلب: tvg-id + بلا ملف VOD ⇒ قناة بث، قبل أي إشارة
                // ضعيفة (دقة/سنة/مجموعة Movies/رمز حلقة ضعيف/مجلد S2 خادم) — ولا يكسره
                // إلا دليل مسلسل صريح: رمز S01E01، مجلد Season، أو ملف حلقة (E05)
                // داخل مجلد مرقم. ملفات VOD (.mp4/.mkv/...) مستثناة أصلاً.
                if (hasTvg && !isVideoFile) {
                    if (!strongSeriesCode(blob) && !seasonWord && !(epInFname && hasSeasonFolder(url))) return 'live';
                }
                // رموز المسلسلات القوية (S01E01/Season/التاريخ) ومجلد الموسم تحسم tv —
                // أما الإشارات الضعيفة (2x2/E4/EP منفردة) فقد تكون اسم قناة فلا تحسم وحدها.
                if (strongSeriesCode(blob) || hasSeasonFolder(url)) return 'tv';
                if (hasSeriesCode(blob) || !!((item && item.isSeriesHint))) return 'tv';
                if (streamT && !yr && !srcFile && !codecReal) return 'live';
                if (yr || srcFile || codecOrRes || movieFolder) {
                    if (gt === 'tv') return 'tv';
                    return 'movie';
                }
                if (/tvg-id="[^"]+"/i.test(ext)) return 'live';
                if (gt) return gt;
                return 'live';
            } catch (e) { return 'live'; }
        }
        async function openMetadataModal() {
            // وضع إعادة التوثيق اليدوي فقط (عبر ⋮ بحث وتوثيق) — الاستيراد الجديد
            // يمر بديالوغ الاختيار ويُضاف مباشرة، والتوثيق اقتراح لاحق (openDocSuggest).
            selectedMetadata = null;
            metaCategoryBadge.textContent = currentCategory === 'tv' ? tLang('catTv') : tLang('catMovie');
            metaCategoryBadge.className = currentCategory === 'tv' ? 
                'text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-950 text-amber-400 border border-amber-800' :
                'text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-950 text-purple-400 border border-purple-800';

            metaSearchStage.classList.remove('hidden');
            metaDetailsStage.classList.add('hidden');
            metaDetailsStage.classList.remove('flex');

            metadataModal.classList.remove('hidden');
            metadataModal.classList.add('flex');

            const sampleItem = pendingRawItems.find(i => !i._assigned) || pendingRawItems[0];
            const queryName = sampleItem ? (sampleItem.parsedShowTitle || sampleItem.cleanTitle) : "";
            const cleanedQueryName = extractCleanQueryName(queryName);
            metaSearchInput.value = cleanedQueryName;

            executeApiSearch(cleanedQueryName);
        }

        function extractCleanQueryName(raw) {
            if (!raw) return "";
            let name = String(raw).split('/')[0].split('\\')[0];
            name = name.replace(/^\s*\[[^\[\]]{1,30}\]\s*/, ' ');
            name = name.replace(/\b((?:19|20)\d{2})[.\-_]\d{1,2}[.\-_]\d{1,2}\b/g, ' ');
            name = name.replace(/\bS\d{1,4}\s*E\d{1,4}\b/gi, ' ').replace(/\b\d{1,2}x\d{1,3}\b/gi, ' ');
            name = name.replace(/(Season\s?\d+|Episode\s?\d+|\bEP?(?:isode)?[\s.]?\d{1,4}\b|الموسم\s?\d+|الحلقة\s?\d+)/gi, ' ');
            name = name.replace(/(\b\d{3,4}p\b|\b4K\b|\bUHD\b|\bFULL[-\s]?HD\b|\bFHD\b|\bHD\b|\bSD\b|Blu-?Ray|BRRip|BDRip|WEB-?DL|WEBDL|WEBRip|\bWEB\b|HDTV|PDTV|SDTV|TVRip|HDRip|DVDRip|DVDScr|\bDVD\b|REMUX|\bCAM\b|\bHDCAM\b|\bHDTS\b|CAMRIP|\bTS\b|\bTC\b|TELESYNC|TELECINE|x264|x265|x266|HEVC|H\.?264|H\.?265|AVC|\bAV1\b|VVC|VC-?1|XviD|DivX|VP9|MPEG-?[24]|TrueHD|Atmos|DTS(?:-HD(?:-MA)?|-X)?|EAC3|DDP\d?(?:\.\d)?|AC3|AAC|FLAC|Opus|MP3|LPCM|HDR10\+?|DOLBY-?VISION|HLG|\bHDR\b|\bDV\b|SDR|(?:10|12|8)-?BIT|ITA-ENG|\b(?:ITA|ENG|FRE|FRA|GER|SPA|RUS|JAP|JPN|KOR|ARA|HIN|TUR|POR)\b|ARABIC|FRENCH|SPANISH|GERMAN|ITALIAN|ENGLISH|TURKISH|HINDI|RUSSIAN|KOREAN|JAPANESE|PORTUGUESE|VOSTFR|TRUEFRENCH|DUAL|MULTI|SUBBED|DUBBED|\bSUB\b|\bDUB\b|COMPLETE|SEASON[-\s]?PACK|\bPACK\b|BOXSET|COLLECTION|\bPROPER\b|REPACK|RERIP|EXTENDED|UNRATED|REMASTERED|LIMITED|UNCUT|THEATRICAL|IMAX|DIRECTORS[-\s]?CUT|NETFLIX|AMZN|AMAZON|DSNP|DISNEY|\bHBO\b|HULU|ATVP|\bNF\b|(?:60|50|30|25|24|120)FPS|V3SP4EV3R|-[A-Z0-9]{2,12}$)/gi, ' ');
            // trailing absolute episode number from anime naming ("Show - 100", "Show 1000") — only with VOD proof
            if (/(\d{3,4}p\b|\b(4K|UHD|BluRay|WEB|HDTV|x26[45]|HEVC|HDR)\b)/i.test(String(raw))) {
                name = name.replace(/[\s\-–—:]+(?:EP?\s?)?\d{2,4}(?:v\d+)?\s*$/i, ' ');
            }
            name = name.replace(/\b(19\d{2}|20\d{2})\b/g, ' ');
            name = name.replace(/[\._\-+\[\]\(\)\{\}:|]+/g, ' ').replace(/\s+/g, ' ').trim();
            return name;
        }

        manualSearchBtn.addEventListener('click', () => {
            const query = metaSearchInput.value.trim();
            if (query) executeApiSearch(query);
        });

        metaSearchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const query = metaSearchInput.value.trim();
                if (query) executeApiSearch(query);
            }
        });

        async function executeApiSearch(queryName) {
            searchResultsList.innerHTML = `
                <div class="text-center py-6 text-slate-400 text-xs flex flex-col items-center gap-2">
                    <i class="fa-solid fa-spinner fa-spin text-emerald-400 text-xl"></i>
                    <span>${tLang('tSearchBusy')}</span>
                </div>
            `;

            try {
                // الأولوية لإضافات الميتا (cinemeta وغيرها) — وTMDB احتياط فقط عند غيابها أو فشلها
                try {
                    if (typeof stremioMetaSearch === 'function') {
                        const st = ((typeof currentCategory !== 'undefined' && currentCategory === 'tv') ? 'series' : 'movie');
                        const sres = await stremioMetaSearch(queryName, st);
                        if (sres && sres.length) { renderSearchResults(sres); return; }
                    }
                } catch (e) {}
                await searchViaTmdb(queryName);
            } catch(e) {
                renderSearchResults([]);
            }
        }

        async function searchViaTmdb(queryName) {
            const apiKey = tmdbEffectiveKey();
            const searchType = currentCategory === 'tv' ? 'tv' : 'movie';
            const _tl = (typeof tmdbLang === 'function' ? tmdbLang() : 'en-US');
            const apiUrl = `https://api.themoviedb.org/3/search/${searchType}?api_key=${apiKey}&query=${encodeURIComponent(queryName)}&language=` + _tl + `&include_adult=false`;

            let response = null;
            try {
                response = await fetch(apiUrl);
            } catch (e) {
                renderSearchResults([]);
                showStatus(tLang('tTmdbNet'), "error");
                return;
            }
            if (!response.ok) {
                renderSearchResults([]);
                showStatus((response.status === 401 || response.status === 403)
                    ? tLang('tTmdbKeyBad')
                    : tLang('tTmdbSearchFail'), "error");
                return;
            }
            let data = await response.json();

            if ((!data.results || data.results.length === 0)) {
                const fallbackUrl = `https://api.themoviedb.org/3/search/${searchType}?api_key=${apiKey}&query=${encodeURIComponent(queryName)}&language=en-US&include_adult=false`;
                const fallbackRes = await fetch(fallbackUrl);
                if (fallbackRes.ok) {
                    data = await fallbackRes.json();
                }
            }

            if (data.results && data.results.length > 0) {
                const formatted = await Promise.all(data.results.slice(0, 5).map(async (res) => {
                    const _tl2 = (typeof tmdbLang === 'function' ? tmdbLang() : 'en-US');
                    const detailsUrl = `https://api.themoviedb.org/3/${searchType}/${res.id}?api_key=${apiKey}&language=` + _tl2;
                    let detailedData = res;
                    try {
                        const dRes = await fetch(detailsUrl);
                        if (dRes.ok) detailedData = await dRes.json();
                    } catch(e) {}
                    try {
                        if (!detailedData.overview && _tl2 !== 'en-US') {
                            const _er = await fetch('https://api.themoviedb.org/3/' + searchType + '/' + res.id + '?api_key=' + apiKey + '&language=en-US');
                            if (_er.ok) { const _ed = await _er.json(); if (_ed && _ed.overview && !detailedData.overview) detailedData.overview = _ed.overview; }
                        }
                    } catch(e2) {}

                    const title = detailedData.title || detailedData.name || detailedData.original_title || tLang('tUnknownTitle');
                    const releaseDate = detailedData.release_date || detailedData.first_air_date || "";
                    const year = releaseDate ? releaseDate.substring(0, 4) : '';
                    const poster = detailedData.poster_path ? `https://image.tmdb.org/t/p/w500${detailedData.poster_path}` : generateSvgAvatar(title);
                    
                    return {
                        id: detailedData.id,
                        title: title,
                        originalTitle: detailedData.original_title || detailedData.original_name || '',
                        year: year,
                        poster: poster,
                        backdrop: detailedData.backdrop_path ? `https://image.tmdb.org/t/p/w1280${detailedData.backdrop_path}` : '',
                        overview: detailedData.overview || tLang('noDescItem'),
                        rating: detailedData.vote_average ? detailedData.vote_average.toFixed(1) : 'N/A',
                        genres: detailedData.genres ? detailedData.genres.map(g => g.name).join(appLang === 'ar' ? '، ' : ', ') : '',
                        status: detailedData.status || ''
                    };
                }));

                renderSearchResults(formatted);
            } else {
                renderSearchResults([]);
            }
        }

        function renderSearchResults(results) {
            searchResultsList.innerHTML = '';

            if (results.length === 0) {
                searchResultsList.innerHTML = `
                    <div class="text-center py-4 text-slate-400 text-xs bg-slate-950 rounded-xl p-3 border border-slate-800">
                        <p>${tLang('noTmdb')}</p>
                        <p class="text-[11px] text-slate-500 mt-1">${tLang('tmdbHint')}</p>
                    </div>
                `;
                return;
            }

            results.forEach(res => {
                const itemBtn = document.createElement('button');
                itemBtn.className = "p-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-xl flex items-center gap-3 text-right transition cursor-pointer w-full";
                itemBtn.innerHTML = `
                    <img src="${res.poster}" class="w-10 h-14 object-cover rounded bg-slate-900 border border-slate-800 flex-shrink-0" onerror="this.src='${generateSvgAvatar(res.title)}'">
                    <div class="min-w-0 flex-grow text-xs">
                        <h5 class="font-bold text-slate-200 truncate">${res.title}</h5>
                        <p class="text-slate-400 text-[10px] mt-0.5">${res.year ? '('+res.year+')' : ''} ${res.genres ? '• ' + res.genres : ''}${res._src === 'stremio' ? ' • Stremio' : ''}</p>
                    </div>
                    <i class="fa-solid fa-chevron-left flip-rtl text-slate-500 text-xs"></i>
                `;

                itemBtn.addEventListener('click', () => {
                    selectedMetadata = res;
                    showMetadataCard();
                });

                searchResultsList.appendChild(itemBtn);
            });
        }

        function showMetadataCard() {
            metaSearchStage.classList.add('hidden');
            metaDetailsStage.classList.remove('hidden');
            metaDetailsStage.classList.add('flex');

            metaPoster.src = selectedMetadata.poster;
            metaTitle.textContent = selectedMetadata.title;
            metaYear.textContent = selectedMetadata.year ? `(${selectedMetadata.year})` : '';
            metaOverview.textContent = selectedMetadata.overview;
            metaRating.textContent = selectedMetadata.rating;
            metaGenres.textContent = selectedMetadata.genres || tLang('genresFallback');
        }

