        /* ===== Smart Parser v2: hierarchy-aware (URL folders + filename + EXTINF) ===== */
function getUrlSegments(url) {
  if (!url) return [];
  try {
    const u = new URL(url.trim().replace(/\\/g, '/'));
    return u.pathname.split('/').filter(s => s.trim().length > 0).map(s => {
      try { return decodeURIComponent(s); } catch (e) { return s; }
    });
  } catch (e) {
    const clean = String(url).split('?')[0].split('#')[0];
    return clean.split(/[\/\\]/).filter(s => s.trim().length > 0).map(s => {
      try { return decodeURIComponent(s); } catch (err) { return s; }
    });
  }
}
function stripMediaExt(s) {
  return String(s||'').replace(/\.(mkv|mp4|avi|ts|m3u8|mov|wmv|flv|webm|m4v|mpg|mpeg|iso|vob|mp3|aac)$/i, '');
}
const GENERIC_FOLDERS = new Set(['series','serie','tv','shows','show','seasons','season','movies','movie','films','film','aflam','vod','videos','video','stream','streaming','content','media','hls','dash','live','channels','channel','playlist','playlists','play','watch','download','downloads','dn','files','file','data','home','root','public','private','storage','server','library','archive','marathon','complete','مسلسلات','مسلسل','افلام','فلم','فيلم','افلام اجنبية','بث','قنوات','فيديو','مكتبة','series hd','movies hd','arabic','ar','en','mr','test','tmp','out','output','streamfiles','episode','episodes','حلقات','حلقة']);
function normLower(s){ return String(s||'').toLowerCase().trim(); }
function isSeasonFolderName(name) {
  if (!name) return null;
  const n = String(name).trim();
  let m = n.match(/(?:الموسم|موسم)\s*(\d{1,2})/i);
  if (m) return parseInt(m[1],10);
  m = n.match(/\bSeason\s*(\d{1,2})\b/i);
  if (m) return parseInt(m[1],10);
  m = n.match(/^\s*S\s*(\d{1,4})\s*$/i);
  if (m) { const v=parseInt(m[1],10); if(v<=2100) return v; }
  m = n.match(/\bS(\d{1,4})\b/i);
  if (m) { const v=parseInt(m[1],10); if(v<=2100) return v; }
  m = n.match(/^[\s._-]*(\d{1,2})[\s._-]*$/);
  // a bare number folder like "02" deep inside series path could be season - only accept if <= 30
  // caller decides context; return null here to be safe (handled by caller with context)
  return null;
}
function isGenericFolder(name){
  if(!name) return true;
  const n = normLower(name).replace(/[._\-+]+/g,' ').replace(/\s+/g,' ').trim();
  if(!n || n.length<2) return true;
  if(GENERIC_FOLDERS.has(n)) return true;
  if(/^s\d{1,4}$/.test(n.replace(/\s+/g,''))) return true;
  if(/^season\s*\d{1,4}$/.test(n)) return true;
  if(/^(الموسم|موسم)\s*\d{1,2}$/.test(n)) return true;
  if(/^(movies?|series?|shows?)\s*hd$/.test(n)) return true;
  return false;
}
function cleanExtinfTitle(t){
  if(!t) return '';
  let s = String(t).trim().replace(/^-1,?\s*/,'').trim();
  // split by | and take last meaningful part
  if(s.includes('|')){
    const parts = s.split('|').map(x=>x.trim()).filter(Boolean);
    // drop leading parts that look like country/provider tags (short or containing AR/EN etc)
    s = parts[parts.length-1];
  }
  // "AR: Name", "EN - Name"
  s = s.replace(/^([A-Z]{2,3}\s*[:\-–—]\s*)+/i,'');
  s = s.replace(/^(AR|EN|FR|TR|ES|US|UK|NETFLIX|SHAHID|OSN|MBC|IPTV)\s*[:\-–—]\s*/i,'');
  return s.trim();
}
// ===== Scene-release tag tables (per media-naming guide: S/E, x, Season/Episode,
// absolute anime numbers, daily dates, resolution, source, codecs, HDR, languages, editions, groups) =====
const SCENE_DATE_RE = /\b((?:19|20)\d{2})[.\-_\s](0?[1-9]|1[0-2])[.\-_\s](0?[1-9]|[12]\d|3[01])\b/;
const SCENE_RES_RE = /\b(4320p|2160p|1080p|720p|576p|480p|360p|8K|4K|UHD|FULL[-\s]?HD|FHD)\b/i;
const SCENE_SRC_RE = /\b(Blu-?Ray|(?:BR|BD)-?Rip|WEB-?DL|WEB-?Rip|HDTV|PDTV|SDTV|TV ?Rip|HD ?Rip|DVD-?Rip|DVD-?Scr|REMUX|HDCAM|HDTS|TELESYNC|TELECINE|CAM)\b|\b(DVD|TS|TC)\b/i;
const SCENE_SRC_STRONG_RE = /\b(Blu-?Ray|(?:BR|BD)-?Rip|WEB-?DL|WEB-?Rip|HDTV|PDTV|SDTV|TV ?Rip|HD ?Rip|DVD-?Rip|DVD-?Scr|REMUX|HDCAM|HDTS|TELESYNC|TELECINE|CAM)\b/i;
const SCENE_QUALITY_RE = /\b(Blu-?Ray|(?:BR|BD)-?Rip|WEB-?DL|WEB-?Rip|HDTV|PDTV|SDTV|TV ?Rip|HD ?Rip|DVD-?Rip|DVD-?Scr|DVD|REMUX|HDCAM|HDTS|TELESYNC|TELECINE|CAM)\b/i;
const SCENE_VCODEC_RE = /\b(x264|x265|x266|HEVC|H\.264|H\.265|H264|H265|AVC|AV1|VVC|VC-?1|XviD|DivX|VP9|MPEG-?[24])\b/i;
const SCENE_ACODEC_RE = /\b(DTS-HD-MA|DTS-HD|DTS-X|TrueHD|Atmos|DTS|EAC3|DDP\d?(?:\.\d)?|AC3|AAC|FLAC|Opus|MP3|LPCM)\b/i;
const SCENE_HDR_RE = /\b(HDR10\+?|DOLBY[-\s]?VISION|HLG|HDR|DV|SDR)(?![A-Za-z0-9])/i;
const SCENE_EDITION_RE = /\b(PROPER|REPACK|RERIP|EXTENDED|UNRATED|REMASTERED|LIMITED|UNCUT|THEATRICAL|IMAX|DIRECTORS[-\s]?CUT)\b/i;
const SCENE_LANG_RE = /\b(MULTI|DUAL|ITA-ENG|VOSTFR|TRUEFRENCH|SUBBED|DUBBED|ITA|ENG|FRE|FRA|GER|SPA|ESP|RUS|JAP|JPN|KOR|CHI|CHS|CHT|ARA|ARABIC|HIN|HINDI|TUR|TURKISH|POR|POL|UKR|FRENCH|SPANISH|GERMAN|ITALIAN|RUSSIAN|JAPANESE|KOREAN|CHINESE|PORTUGUESE|PERSIAN|FARSI)\b/i;
const SCENE_EXTRA_RE = /\b(COMPLETE|SEASON[-\s]?PACK|PACK|BOXSET|COLLECTION|FULL[-\s]?SEASON)\b|\b(60|50|30|25|24|120)FPS\b|\b(10|12|8)-?BIT\b|\b(NETFLIX|AMZN|AMAZON|DSNP|DISNEY\+?|HBO(?:-?MAX)?|HULU|ATVP|APPLE-?TV|PARAMOUNT|PEACOCK|CRUNCHYROLL|NF)\b/i;
// Strong = unambiguous VOD tech markers. Soft = everyday words (live channels are often
// named "... HD" / "... WEB"), so soft tokens only count in pairs or beside a year.
const SCENE_SOFT_RE = /\b(HD|SD|WEB|DVD|TS|TC|DV|SUB|DUB|RAW|HARDSUB|CAM)\b/gi;
function sceneStrongTest(t){
  if(!t) return false;
  return SCENE_RES_RE.test(t) || SCENE_SRC_STRONG_RE.test(t) || SCENE_VCODEC_RE.test(t) ||
    SCENE_ACODEC_RE.test(t) || SCENE_HDR_RE.test(t) || SCENE_EDITION_RE.test(t) ||
    SCENE_LANG_RE.test(t) || SCENE_EXTRA_RE.test(t) || SCENE_DATE_RE.test(t) ||
    /\bS\d{1,4}\s*E(?!(?:19|20)\d{2}\b)\d{1,4}\b/i.test(t) || /\b\d{1,2}x\d{1,3}\b/i.test(t);
}
// Detailed filename parser (ports MediaParser logic, returns showCandidate)
function techIndexAfter(str, fromIdx, includeSoft){
  if(fromIdx==null || fromIdx<0) fromIdx=0;
  const tail = str.substring(fromIdx);
  const patterns = [
    SCENE_RES_RE,
    /\b(19\d{2}|20\d{2})\b/,
    SCENE_DATE_RE,
    SCENE_SRC_RE,
    SCENE_VCODEC_RE,
    SCENE_ACODEC_RE,
    SCENE_HDR_RE,
    SCENE_EDITION_RE,
    SCENE_LANG_RE,
    SCENE_EXTRA_RE
  ];
  if(includeSoft) patterns.push(/\b(HD|SD|WEB|TS|TC|DV|SUB|DUB|RAW|HARDSUB)\b/i);
  let best = -1;
  for(const p of patterns){
    const mm = tail.match(p);
    if(mm){
      const idx = tail.indexOf(mm[0]);
      if(idx!==-1 && (best===-1 || idx<best)) best=idx;
    }
  }
  return best===-1? -1 : fromIdx+best;
}
function parseFilenameDetailed(nameRaw){
  const out = { showCandidate:'', year:null, season:null, episode:null, episodeTitle:'', resolution:'', quality:'', codec:'', audio:'', languages:[], hdr:'', edition:'', group:'', seasonExplicit:false, episodeExplicit:false, isDaily:false };
  if(!nameRaw) return out;
  let name = String(nameRaw).trim();
  // fansub-style leading group: "[GROUP] Show - 01 [1080p]" -> group
  const preM = name.match(/^\s*\[([^\[\]]{1,30})\]\s*/);
  let hadBracketPrefix = false;
  if(preM && name.slice(preM[0].length).trim().length >= 2){
    hadBracketPrefix = true;
    out.group = preM[1].trim();
    name = name.slice(preM[0].length).trim();
  }
  // strip release group at end: -GROUP (kept when it looks like a plain title tail
  // like Avatar-2009, or a split-off tag fragment like the DL in WEB-DL)
  const gm = name.match(/-([A-Za-z0-9]{2,12})$/);
  if(gm && !/^(DL|RIP|SCR|HD|SD|WEB|TS|TC|TV|EP|E|S|X|MA|V\d+|3D|264|265|366|BIT|FPS|SUB|DUB|ENG|ITA|ARA|FRE|GER|HDR|DV|2160|1080|720|576|480|360|4320|4K|8K|UHD|FHD)$/i.test(gm[1])){
    const rest = name.slice(0, -gm[0].length);
    if(sceneStrongTest(rest) || /\b(19\d{2}|20\d{2})\b/.test(rest)){
      out.group = gm[1];
      name = rest;
    }
  }
  const normalized = name.replace(/[._()\[\]{}]+/g,' ').replace(/\s+/g,' ').trim();
  if(!normalized) return out;
  const afterHasYear = (idx)=> /\b(19\d{2}|20\d{2})\b/.test(normalized.slice(idx));
  // 1) daily date first: Show.2025.10.20 (daily/talk shows) -> season=year, episode=MMDD
  let seEnd = -1;
  const dm = normalized.match(SCENE_DATE_RE);
  if(dm){
    const y=parseInt(dm[1],10), mo=parseInt(dm[2],10), d=parseInt(dm[3],10);
    if(mo>=1&&mo<=12&&d>=1&&d<=31){
      const di = normalized.indexOf(dm[0]);
      out.year=dm[1]; out.season=y; out.episode=mo*100+d;
      out.seasonExplicit=true; out.episodeExplicit=true; out.isDaily=true;
      out.showCandidate=normalized.substring(0,di).replace(/\s*[-–—]\s*$/,'').replace(/\s+/g,' ').trim();
      out.episodeTitle=dm[1]+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0');
      seEnd=di+dm[0].length;
    }
  }
  if(seEnd===-1){
    // S+E (4-digit seasons/episodes allowed for daily-style S2025E1020; year-like E parts rejected)
    const sePatterns = [/\bS(\d{1,4})\s*E(?!(?:19|20)\d{2}\b)(\d{1,4})\b/i, /\b(\d{1,2})x(\d{1,3})\b/i, /\bSeason\s*(\d{1,2})\s*(?:Episode|Ep?)\s*(?!(?:19|20)\d{2}\b)(\d{1,3})\b/i, /(?:الموسم|موسم)\s*(\d{1,2})\s*(?:الحلقة|حلقة|E|EP)?\s*(\d{1,3})/i];
    let seM=null, seIdx=-1;
    for(const p of sePatterns){ const mm=normalized.match(p); if(mm){ seM=mm; seIdx=normalized.indexOf(mm[0]); break; } }
    if(seM){
      out.season = parseInt(seM[1],10); out.episode = parseInt(seM[2],10);
      out.seasonExplicit = true; out.episodeExplicit = true;
      out.showCandidate = normalized.substring(0, seIdx).replace(/\s*[-–—]\s*$/,'').replace(/\s+/g,' ').trim();
      seEnd = seIdx + seM[0].length;
      out.episodeTitle = '';
    }
  }
  if(seEnd!==-1){
    const cut = techIndexAfter(normalized, seEnd, true);
    const epEnd = cut===-1? normalized.length : cut;
    const epT = normalized.substring(seEnd, epEnd).replace(/^[\s\-–—:.]+/,'').replace(/\s+/g,' ').trim();
    if(epT.length>1 && epT.length<80 && !/^\d+$/.test(epT)) out.episodeTitle = epT;
  } else {
    let techStart = normalized.length;
    const markTech = (idx)=>{ if(idx!==-1 && idx<techStart) techStart=idx; };
    const sM = normalized.match(/\bS(\d{1,4})(?=\s|$)/i) || normalized.match(/\bSeason\s*(\d{1,2})\b/i) || normalized.match(/(?:الموسم|موسم)\s*(\d{1,2})/i);
    if(sM){ const v=parseInt((sM[1]||sM[0].replace(/\D/g,'')),10); if(!isNaN(v)&&v<=2100){ out.season=v; out.seasonExplicit=true; markTech(normalized.indexOf(sM[0])); } }
    // EP prefix up to 4 digits (anime absolute with prefix); year-like parts rejected
    let eM = normalized.match(/\bEP?(?:isode)?[\s.]*(?!(?:19|20)\d{2}\b)(\d{1,4})\b/i) || normalized.match(/(?:الحلقة|حلقة)[\s:]*(\d{1,4})/i);
    if(!eM){ const t2=normalized.match(/[\s_.\-]E(\d{1,4})(?=[\s_.\-]|$)/i); if(t2 && !/^(?:19\d{2}|20\d{2})$/.test(t2[1])) eM=t2; }
    if(eM){ const v=parseInt(eM[1],10); if(!isNaN(v)){ out.episode=v; out.episodeExplicit=true; markTech(normalized.indexOf(eM[0])); } }
    // anime-style absolute number or bare season number: standalone number after the show name.
    // Guards: must follow real show text (kills "300", "2012"), must not precede a year
    // (kills "John Wick 3 2019"), needs VOD tech after it or a [fansub] prefix.
    if(out.episode==null && out.season==null){
      const absRe = /(^|[\s.\-–—:])(\d{1,4})(v\d+)?(?=[\s.\-–—:\[\(]|$)/g;
      let m;
      while((m=absRe.exec(normalized))){
        const rawNum = m[2];
        if(/^(?:19\d{2}|20\d{2})$/.test(rawNum)) continue;
        if(/^(1080|720|480|360|576|2160|4320)$/.test(rawNum)) continue;
        const v=parseInt(rawNum,10);
        if(!(v>=1 && v<=1500)) continue;
        const beforeTxt = normalized.substring(0, m.index+m[1].length);
        const beforeClean = beforeTxt.replace(/[\s.\-–—:]+/g,' ').trim();
        if(beforeClean.replace(/\d/g,'').trim().length<2) continue;
        if(!/[A-Za-z\u0600-\u06FF]/.test(beforeClean)) continue;
        // number is a fragment of a dotted decimal ("DDP5.1" -> "DDP5 1"): preceded by a digit,
        // or followed at once by another small number ("7.1" -> "7 1")
        if(/\d$/.test(beforeTxt.replace(/[\s.\-–—:]+$/,''))) continue;
        const mEnd = m.index+m[0].length;
        const tailAfter = normalized.slice(mEnd);
        if(/^[\s.\-–—:]*\d{1,2}(?=[\s.\-–—:\[\(]|$)/.test(tailAfter)) continue;
        if(afterHasYear(m.index)) continue;
        if(!(sceneStrongTest(tailAfter) || hadBracketPrefix)) continue;
        const dashLike = /[-–—:]$/.test(beforeTxt.replace(/[\s.]*$/,'')) || /^[\s.]*[-–—:\[\(]/.test(tailAfter);
        if(dashLike || v>31){ out.episode=v; out.episodeExplicit=true; }
        else { out.season=v; out.seasonExplicit=true; }
        out.showCandidate = beforeClean;
        markTech(m.index+m[1].length);
        break;
      }
    }
    const mRes = normalized.match(SCENE_RES_RE);
    if(mRes){ markTech(normalized.indexOf(mRes[0])); }
    const qM = normalized.match(SCENE_QUALITY_RE);
    if(qM){ markTech(normalized.indexOf(qM[0])); }
    const cm = normalized.match(SCENE_VCODEC_RE);
    if(cm){ markTech(normalized.indexOf(cm[0])); }
    const am = normalized.match(SCENE_ACODEC_RE);
    if(am){ markTech(normalized.indexOf(am[0])); }
    const hm = normalized.match(SCENE_HDR_RE);
    if(hm){ markTech(normalized.indexOf(hm[0])); }
    const edm = normalized.match(SCENE_EDITION_RE);
    if(edm){ markTech(normalized.indexOf(edm[0])); }
    const lm0 = normalized.match(SCENE_LANG_RE);
    if(lm0){ markTech(normalized.indexOf(lm0[0])); }
    const xm = normalized.match(SCENE_EXTRA_RE);
    if(xm){ markTech(normalized.indexOf(xm[0])); }
    // split decimals from audio layouts ("DDP5.1"/"7.1" -> "DDP5 1"/"7 1"): never title text
    const decM = normalized.match(/\b\d\s+\d\b/);
    if(decM){ markTech(normalized.indexOf(decM[0])); }
    // year marks tech too (but keep value)
    const ym0 = normalized.match(/\b(19\d{2}|20\d{2})\b/);
    if(ym0){ markTech(normalized.indexOf(ym0[0])); }
    // soft tokens (HD/WEB/...) end the candidate only past the first token and
    // only with VOD proof after them — never cut a title like "Web Therapy"
    const softRe2 = /\b(HD|SD|WEB|DVD|TS|TC|DV|SUB|DUB|RAW)\b/gi;
    let sm2;
    while((sm2=softRe2.exec(normalized))){
      if(sm2.index===0) continue;
      const after = normalized.slice(sm2.index+sm2[0].length);
      if(sceneStrongTest(after) || /\b(19\d{2}|20\d{2})\b/.test(after)){ markTech(sm2.index); break; }
    }
    let cand = normalized.substring(0, techStart).replace(/\s*[-–—]\s*$/,'').replace(/\s+/g,' ').trim();
    cand = cand.replace(/\bS\d{1,4}\b/gi,' ').replace(/\b\d{1,2}x\d{1,3}\b/gi,' ').replace(/\bEP?(?:isode)?[\s.]*\d{1,4}\b/gi,' ').replace(SCENE_DATE_RE,' ').replace(/\s+/g,' ').trim();
    if(!out.showCandidate) out.showCandidate = cand;
    else if(cand && cand.length > out.showCandidate.length && (out.season==null || out.episode==null)) out.showCandidate = cand;
  }
  // tech fields extracted in both branches
  const resM2 = normalized.match(SCENE_RES_RE);
  if(resM2){ const t=resM2[0].toUpperCase(); out.resolution=(/FULL/.test(t)||t==='FHD')?'1080P':t; }
  const qM2 = normalized.match(SCENE_QUALITY_RE);
  if(qM2) out.quality=qM2[0];
  const cm2 = normalized.match(SCENE_VCODEC_RE);
  if(cm2) out.codec=cm2[0];
  const am2 = normalized.match(SCENE_ACODEC_RE);
  if(am2) out.audio=am2[0];
  const hm2 = normalized.match(SCENE_HDR_RE);
  if(hm2){ const t=hm2[0].toUpperCase().replace(/[\s\-]/g,''); out.hdr=t.indexOf('10+')!==-1?'HDR10+':t.indexOf('10')!==-1?'HDR10':t.indexOf('DOLBY')!==-1?'DOLBY VISION':t.indexOf('HLG')!==-1?'HLG':t.indexOf('SDR')!==-1?'SDR':t==='DV'?'DV':'HDR'; }
  const edm2 = normalized.match(SCENE_EDITION_RE);
  if(edm2) out.edition=edm2[0].toUpperCase().replace(/[\s\-]/g,' ');
  const langSet = [];
  const langReG = /\b(MULTI|DUAL|ITA-ENG|VOSTFR|TRUEFRENCH|SUBBED|DUBBED|ITA|ENG|FRE|FRA|GER|SPA|RUS|JAP|JPN|KOR|CHS|CHT|ARA|ARABIC|HIN|HINDI|TUR|TURKISH|POR|POL|UKR|FRENCH|SPANISH|GERMAN|ITALIAN|RUSSIAN|JAPANESE|KOREAN|CHINESE|PORTUGUESE|PERSIAN|FARSI)\b/gi;
  let lm;
  while((lm=langReG.exec(normalized))){ const u=lm[0].toUpperCase(); if(!langSet.includes(u)) langSet.push(u); }
  out.languages = langSet;
  if(!out.year){ const ym = normalized.match(/\b(19\d{2}|20\d{2})\b/); if(ym) out.year=ym[1]; }
  return out;
}
function cleanDisplayTitle(s){
  if(!s) return '';
  return String(s).replace(/[._\-+\[\]\(\)\{\}:]+/g,' ').replace(/\s+/g,' ').trim();
}
function normalizeShowKey(s){
  if(!s) return '';
  return String(s).toLowerCase().replace(/[._\-+\[\]\(\)\{\}:|]+/g,' ').replace(/["'!?،,؛:]/g,' ').replace(/\s+/g,' ').trim();
}
async function sha256Hex(s){
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(s == null ? '' : s)));
  return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
function fmtBytes(n){
  n = Number(n) || 0;
  let _lg = 'ar'; try { _lg = (typeof appLang !== 'undefined' ? appLang : 'ar'); } catch (e) {}
  const units = _lg === 'en' ? ['B','KB','MB','GB','TB'] : (_lg === 'zh' ? ['B','KB','MB','GB','TB'] : (_lg === 'hi' ? ['B','KB','MB','GB','TB'] : ['بايت','ك.ب','م.ب','ج.ب','ت.ب']));
  if(n <= 0) return '0 ' + units[0];
  let u = 0;
  while(n >= 1024 && u < units.length - 1){ n /= 1024; u++; }
  return (u === 0 ? Math.round(n) : n.toFixed(1)) + ' ' + units[u];
}
function smartParseMedia(extinfRaw, url){
  const segs = getUrlSegments(url);
  const filenameRaw = segs.length? segs[segs.length-1] : '';
  const folders = segs.length? segs.slice(0,-1) : [];
  const filenameNoExt = stripMediaExt(filenameRaw);
  const fileInfo = parseFilenameDetailed(filenameNoExt);
  const extinfClean = cleanExtinfTitle(extinfRaw);
  const extinfNoExt = stripMediaExt(extinfClean);
  const extInfo = parseFilenameDetailed(extinfNoExt);
  // folder season: deepest season-like folder
  let folderSeason=null, folderSeasonIdx=-1;
  for(let i=folders.length-1;i>=0;i--){
    const v=isSeasonFolderName(folders[i]);
    if(v!=null){ folderSeason=v; folderSeasonIdx=i; break; }
  }
  // bare-number folder as season (e.g. /Show/02/E05.mp4) only if parent looks like a show
  if(folderSeason==null && folders.length>=2){
    const lastF = folders[folders.length-1];
    if(/^\d{1,2}$/.test(String(lastF).trim())){
      const n=parseInt(lastF.trim(),10);
      if(n>=1&&n<=30) { folderSeason=n; folderSeasonIdx=folders.length-1; }
    } else if(/^(19\d{2}|20\d{2})$/.test(String(lastF).trim())){
      // year folder as season for daily shows (e.g. /Show/2025/ep.mp4)
      const n=parseInt(lastF.trim(),10);
      if(n>=1990&&n<=2100) { folderSeason=n; folderSeasonIdx=folders.length-1; }
    }
  }
  // folder show: deepest non-season non-generic folder
  let folderShow='', folderShowIdx=-1;
  for(let i=folders.length-1;i>=0;i--){
    if(i===folderSeasonIdx) continue;
    if(isSeasonFolderName(folders[i])!=null) continue;
    if(/^\d{1,3}$/.test(String(folders[i]).trim())) continue; // episode-number folder
    if(/^(E|EP|الحلقة|حلقة)\s*\d{1,3}$/i.test(String(folders[i]).trim())) continue;
    if(isGenericFolder(folders[i])) continue;
    folderShow = cleanDisplayTitle(stripMediaExt(folders[i]));
    // also extract year from folder show e.g. "Avatar (2009)"
    folderShowIdx=i;
    break;
  }
  // year in folder show
  let folderYear=null, folderShowNoYear=folderShow;
  if(folderShow){
    const ym=folderShow.match(/\b(19\d{2}|20\d{2})\b/);
    if(ym){ folderYear=ym[1]; folderShowNoYear=folderShow.replace(ym[0],'').replace(/[()\[\]]/g,' ').replace(/\s+/g,' ').trim(); }
  }
  const seriesContext = (fileInfo.seasonExplicit||fileInfo.episodeExplicit||extInfo.seasonExplicit||extInfo.episodeExplicit||folderSeason!=null);
  // show title decision
  let showTitle='';
  const fileCand = cleanDisplayTitle(fileInfo.showCandidate);
  const extCand = cleanDisplayTitle(extInfo.showCandidate);
  // قناة بث: اسم العرض من عنوان EXTINF مقدَّم على اسم ملف الرابط (غالباً
  // معرّف معتم مثل plu-xxx أو index أو play.php)، إلا إن حمل الملف
  // موسماً/حلقة صريحين (حلقات مسلسلات HLS). إن استُهلك العنوان كله
  // كرمز حلقات (E4/2x2) يُستخدم العنوان منظفاً من لاحقة الجودة.
  const liveUrlLike = /\.(m3u8|ts|mpd)($|\?)|\.php(\?|$)|\/(live|hls|channel)(\/|$)/i.test('/' + segs.join('/'));
  if (liveUrlLike && !fileInfo.seasonExplicit && !fileInfo.episodeExplicit) {
    const fb = (extCand && extCand.length >= 2 && !/^\d+$/.test(extCand)) ? extCand
      : cleanDisplayTitle(String(extinfClean).replace(/\s*\((?:\d{3,4}[pi]|HD|SD|4K|FHD|UHD)\)\s*$/i, ''));
    // (الرقم وحده مقبول هنا: أسماء قنوات مثل 86 و101 و24 حقيقية)
    if (fb && fb.length >= 2) showTitle = fb;
  }
  const fileCandOk = fileCand && fileCand.length>=2 && !/^\d+$/.test(fileCand) && !isGenericFolder(fileCand);
  const extCandOk = extCand && extCand.length>=2 && !/^\d+$/.test(extCand);
  if(showTitle){
    // محسوم أعلاه (قناة بث): يُبقى اسم EXTINF
  } else if(fileCandOk && fileInfo.seasonExplicit){
    showTitle = fileCand;
  } else if(fileCandOk && !seriesContext){
    showTitle = fileCand; // movie from filename
  } else if(fileCandOk && seriesContext && folderShow){
    // filename has name AND folder has name: prefer longer/more informative? Usually filename candidate == folder show (modulo punctuation). Pick folder show if filename candidate is short or equals episode token.
    // If they normalize to same, use folderShow (cleaner, keeps Arabic spacing)
    const kf=normalizeShowKey(fileCand), ks=normalizeShowKey(folderShowNoYear||folderShow);
    if(kf===ks) showTitle=folderShowNoYear||folderShow;
    else if(fileCand.length>=folderShow.length) showTitle=fileCand;
    else showTitle=folderShowNoYear||folderShow;
  } else if(fileCandOk){
    showTitle=fileCand;
  } else if(extCandOk){
    const ke=normalizeShowKey(extCand), kf2=normalizeShowKey(folderShowNoYear||folderShow||'');
    if(folderShow && kf2 && ke && (kf2.includes(ke) || ke.includes(kf2))){
      showTitle = (kf2.length>=ke.length)? (folderShowNoYear||folderShow) : extCand;
    } else showTitle=extCand;
  } else if(folderShow){
    showTitle=folderShowNoYear||folderShow;
  } else if(extCand){
    showTitle=extCand;
  } else if(fileCand){
    showTitle=fileCand;
  } else {
    showTitle=cleanDisplayTitle(filenameNoExt)||extinfClean||'unknown';
  }
  // season
  let season = fileInfo.season ?? extInfo.season ?? folderSeason ?? 1;
  // episode
  let episode = fileInfo.episode ?? extInfo.episode ?? null;
  let episodeExplicit = fileInfo.episodeExplicit || extInfo.episodeExplicit;
  if(episode==null && seriesContext){
    // trailing number in filename like "05", "E05", "Episode 5", "الحلقة 15"
    let m = filenameNoExt.match(/(?:الحلقة|حلقة|Episode|Ep?)\s*(\d{1,3})/i) || filenameNoExt.match(/[\s_.\-]E(\d{1,3})(?=[\s_.\-]|$)/i) || filenameNoExt.match(/(?:^|[\s_.\-])(\d{1,3})(?:\s*$)/);
    if(m){
      const v=parseInt(m[1],10);
      const isYear = /^(19\d{2}|20\d{2})$/.test(m[1]);
      if(!isYear && v>=1 && v<=500){ episode=v; episodeExplicit=true; }
    }
  }
  if(episode==null) episode = 1;
  // year
  const year = fileInfo.year || extInfo.year || folderYear || '';
  // strip year from showTitle if present (keep separately)
  if(year && showTitle.includes(year)){
    showTitle = showTitle.replace(year,'').replace(/[()\[\]]/g,' ').replace(/\s+/g,' ').trim() || showTitle;
  }
  showTitle = cleanDisplayTitle(showTitle);
  // tech
  const resolution = (fileInfo.resolution||'').toUpperCase();
  const quality = fileInfo.quality || extInfo.quality || '';
  const codec = fileInfo.codec || '';
  const group = fileInfo.group || '';
  const audio = fileInfo.audio || extInfo.audio || '';
  const hdr = fileInfo.hdr || extInfo.hdr || '';
  const edition = fileInfo.edition || extInfo.edition || '';
  const langSet = [];
  (fileInfo.languages||[]).concat(extInfo.languages||[]).forEach(l=>{ if(l && !langSet.includes(l)) langSet.push(l); });
  // episode display title
  let epTitle='';
  if(fileInfo.episodeTitle) epTitle=fileInfo.episodeTitle;
  else if(extInfo.episodeTitle) epTitle=extInfo.episodeTitle;
  // if filename is just a number/E05 and no epTitle, leave empty -> UI shows الحلقة N
  const isSeries = seriesContext;
  const showKey = normalizeShowKey(showTitle);
  return {
    showTitle: showTitle||'unknown',
    showKey: showKey||normalizeShowKey(showTitle)||'unknown',
    seasonNumber: isSeries? season : 1,
    episodeNumber: isSeries? episode : 1,
    episodeTitle: epTitle,
    year: year||'',
    resolution, quality, codec, group, audio, hdr, edition,
    languages: langSet,
    isSeries,
    debug:{fileCand, extCand, folderShow, folderSeason, filenameNoExt}
  };
}
        function groupKeyOf(item){ try{ if(item && item.showKey) return item.showKey; const s=(item && (item.metaTitle || item.parsedShowTitle || item.cleanTitle))||''; return normalizeShowKey(s); }catch(e){ return ''; } }
        /* ===== end Smart Parser v2 ===== */
