        // ===== Selection (multi-delete) + Similar-series state =====

        function selKeyFor(data) {
            if (!data) return '';
            if (data.isShowGroup) return 'show:' + data.key;
            if (data.isSeasonFolder) return 'season:' + (navState.showKey || '') + ':' + data.seasonNumber;
            return 'id:' + (data.id || '');
        }

        function attachSelector(card, data) {
            if (!inSelectionMode) return;
            const key = selKeyFor(data);
            const label = document.createElement('label');
            label.className = "sel-box flex-shrink-0 cursor-pointer flex items-center";
            label.innerHTML = '<input type="checkbox" class="sel-checkbox w-4 h-4 accent-emerald-500 cursor-pointer"' + (selectedKeys.has(key) ? ' checked' : '') + '>';
            label.addEventListener('click', e => e.stopPropagation());
            label.querySelector('input').addEventListener('change', e => {
                e.stopPropagation();
                if (e.target.checked) selectedKeys.add(key); else selectedKeys.delete(key);
                updateSelectionToolbar();
            });
            card.prepend(label);
        }

        function disarmDeleteBtn() {
            if (!deleteSelectedBtn) return;
            deleteSelectedBtn.dataset.armed = '';
            deleteSelectedBtn.className = "bg-slate-800 text-slate-400 text-[11px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1";
            try { deleteSelectedBtn.innerHTML = '<i class="fa-solid fa-trash-can"></i> ' + tLang('delSel'); } catch (e) { deleteSelectedBtn.innerHTML = '<i class="fa-solid fa-trash-can"></i> Delete selected'; }
            if (armDeleteTimer) { clearTimeout(armDeleteTimer); armDeleteTimer = null; }
        }

        function updateSelectionToolbar() {
            if (!selectionToolbar) return;
            const has = inSelectionMode && activeRenderList.length > 0;
            selectionToolbar.classList.toggle('hidden', !has);
            selectionToolbar.classList.toggle('flex', has);
            if (!has) return;
            const keys = activeRenderList.map(selKeyFor);
            const allSel = keys.length > 0 && keys.every(k => selectedKeys.has(k));
            selectAllCheckbox.checked = allSel;
            try { selectAllCheckbox.indeterminate = !allSel && keys.some(k => selectedKeys.has(k)); } catch(e) {}
            try { selectedCountLabel.textContent = selectedKeys.size > 0 ? (tLang('selAll') + ': ' + selectedKeys.size) : ''; } catch (e) { selectedCountLabel.textContent = selectedKeys.size > 0 ? ('Selected: ' + selectedKeys.size) : ''; }
            deleteSelectedBtn.disabled = selectedKeys.size === 0;
            deleteSelectedBtn.classList.toggle('opacity-40', selectedKeys.size === 0);
            if (selectedKeys.size === 0) disarmDeleteBtn();
        }

        function deleteSelectedItems() {
            if (selectedKeys.size === 0) return;
            const keys = new Set(selectedKeys);
            const before = parsedItems.length;
            parsedItems = parsedItems.filter(item => {
                if (keys.has('id:' + item.id)) return false;
                if (item.category === 'tv') {
                    if (keys.has('show:' + groupKeyOf(item))) return false;
                    for (const k of keys) {
                        if (k.startsWith('season:')) {
                            const parts = k.split(':');
                            if (parts.length === 3 && groupKeyOf(item) === parts[1] && String(item.seasonNumber || 1) === parts[2]) return false;
                        }
                    }
                }
                return true;
            });
            const removed = before - parsedItems.length;
            inSelectionMode = false; selectedKeys.clear();
            disarmDeleteBtn();
            try { if (typeof pruneLastWatched === 'function') pruneLastWatched(); } catch (e) {}
            saveItemsToStorage();
            try { if (typeof saveLastWatched === 'function') saveLastWatched(); } catch (e) {}
            refreshApp();
            showStatus(removed > 0 ? (removed + ' ' + tLang('itemsUnit') + ' ' + tLang('tDeleted')) : tLang('tNoDelete'), removed > 0 ? "success" : "info");
        }

        // Filter Tabs Event Handler
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.filter-tab').forEach(t => {
                    t.className = "filter-tab flex-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold cursor-pointer transition text-xs text-center truncate";
                });
                tab.className = "filter-tab flex-1 px-3 py-1.5 rounded-xl bg-emerald-600 text-white font-bold cursor-pointer transition text-xs text-center truncate";
                currentFilter = tab.getAttribute('data-filter');
                navState = { level: 1, showTitle: null, showKey: null, seasonNumber: null };
                inSelectionMode = false; selectedKeys.clear();
                disarmDeleteBtn();
                // تبديل التبويب يلغي تحميل السابق فوراً ويركّز على الجديد من الأعلى
                try { VL.gen++; VL.imgGen++; } catch (e) {}
                try { const _lsT = document.getElementById('listScroll'); if (_lsT) _lsT.scrollTop = 0; } catch (e) {}
                refreshApp();
            });
        });

        selectAllCheckbox.addEventListener('change', () => {
            const keys = activeRenderList.map(selKeyFor);
            if (selectAllCheckbox.checked) keys.forEach(k => selectedKeys.add(k));
            else keys.forEach(k => selectedKeys.delete(k));
            renderCurrentLevelList();
        });

        deleteSelectedBtn.addEventListener('click', () => {
            if (selectedKeys.size === 0) return;
            if (!deleteSelectedBtn.dataset.armed) {
                deleteSelectedBtn.dataset.armed = '1';
                deleteSelectedBtn.className = "bg-rose-600 hover:bg-rose-500 text-white text-[11px] px-3 py-1.5 rounded-lg font-bold transition cursor-pointer flex items-center gap-1";
                try { deleteSelectedBtn.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> ' + tLang('delSel') + '?'; } catch (e) { deleteSelectedBtn.innerHTML = '<i class="fa-solid fa-triangle-exclamation"></i> Confirm?'; }
                armDeleteTimer = setTimeout(disarmDeleteBtn, 3000);
            } else {
                deleteSelectedItems();
            }
        });

        exitSelectionBtn.addEventListener('click', () => { exitSelectionMode(); });

        confirmLinksBtn.addEventListener('click', () => {
            const st = pendingLinksState;
            if (!st) return;
            let updatedLinks = 0;
            st.conflicts.forEach(c => {
                c.existing.url = c.updated.url;
                c.existing.extinfRaw = c.updated.extinfRaw || c.existing.extinfRaw;
                updatedLinks++;
            });
            st.toAdd.forEach(u => { parsedItems.push(u); });
            try { if (typeof maybeAutoDoc === 'function') maybeAutoDoc(st.toAdd.slice()); } catch (e) {}
            finishCommit(st.toAdd.length, st.skippedCount, updatedLinks);
        });

        rejectLinksBtn.addEventListener('click', () => {
            const st = pendingLinksState;
            if (!st) return;
            const rejected = st.conflicts.length;
            st.toAdd.forEach(u => { parsedItems.push(u); });
            try { if (typeof maybeAutoDoc === 'function') maybeAutoDoc(st.toAdd.slice()); } catch (e) {}
            finishCommit(st.toAdd.length, st.skippedCount + rejected, 0);
        });

        copyLinksBtn.addEventListener('click', () => {
            const st = pendingLinksState;
            if (!st) return;
            st.conflicts.forEach(c => {
                c.updated.dupIndex = nextDupIndex(c.updated.cleanTitle, currentCategory, st.toAdd);
                parsedItems.push(c.updated);
            });
            st.toAdd.forEach(u => { parsedItems.push(u); });
            try { if (typeof maybeAutoDoc === 'function') maybeAutoDoc(st.toAdd.concat(st.conflicts.map(c => c.updated))); } catch (e) {}
            finishCommit(st.toAdd.length + st.conflicts.length, st.skippedCount, 0, st.conflicts.length);
        });

        function refreshApp() {
            updateCounts();
            renderNavigationHeader();
            try { VL.start = -1; VL.end = -1; VL.center = -1; VL.gen++; VL.imgGen++; VL.cache.clear(); } catch (e) {}
            try { if (typeof invalidateDeadSeasonCache === 'function') invalidateDeadSeasonCache(); } catch (e) {}

            const filtered = parsedItems.filter(item => item.category === currentFilter);

            if (filtered.length === 0) {
                itemsGrid.innerHTML = '';
                itemsGrid.className = "flex flex-col gap-2.5";
                emptyState.classList.remove('hidden');
                emptyState.classList.add('flex');
                activeRenderList = [];
                updateSelectionToolbar();
                try { if (typeof saveUiStateLight === 'function') saveUiStateLight(); } catch (e) {}
                try { if (typeof stremioSyncBox === 'function') stremioSyncBox(); } catch (e) {}
                return;
            }

            emptyState.classList.add('hidden');
            emptyState.classList.remove('flex');

            if (navState.level === 1) {
                prepareLevel1List(filtered);
            } else if (navState.level === 2) {
                prepareLevel2List(filtered);
            } else if (navState.level === 3) {
                prepareLevel3List(filtered);
            }

            renderCurrentLevelList();
            // تذكّر كل شيء: أي إعادة رسم تعكس تبويب/تنقل/بحث جديد — نحفظه فوراً (خفيف)
            try { if (typeof saveUiStateLight === 'function') saveUiStateLight(); } catch (e) {}
            try { if (typeof stremioSyncBox === 'function') stremioSyncBox(); } catch (e) {}
        }

        function fmtTabCount(n) { n = Number(n) || 0; return n > 99999 ? '99999+' : String(n); }
        function updateCounts() {
            const tv = new Set(parsedItems.filter(i => i.category === 'tv').map(i => groupKeyOf(i))).size;
            const movie = parsedItems.filter(i => i.category === 'movie').length;
            const live = parsedItems.filter(i => i.category === 'live').length;

            document.getElementById('countTV').textContent = fmtTabCount(tv);
            document.getElementById('countMovie').textContent = fmtTabCount(movie);
            document.getElementById('countLive').textContent = fmtTabCount(live);
            totalCountEl.textContent = fmtTabCount(parsedItems.length);
        }

        function renderNavigationHeader() {
            if (navState.level === 1) {
                breadcrumbPath.classList.add('hidden');
                breadcrumbPath.classList.remove('flex');
                try { listSearchInput.placeholder = tLang('searchPh1'); } catch (e) { listSearchInput.placeholder = 'Search...'; }
            } else if (navState.level === 2) {
                breadcrumbPath.classList.remove('hidden');
                breadcrumbPath.classList.add('flex');
                document.getElementById('pathShowTitle').textContent = showDisplayTitle(navState.showKey, navState.showTitle);
                document.getElementById('pathSeasonTitle').classList.add('hidden');
                try { const _t2 = tLang('searchPh1'); listSearchInput.placeholder = (appLang === 'en' ? ('Search seasons of ' + (showDisplayTitle(navState.showKey, navState.showTitle) || '')) : (appLang === 'zh' ? ('搜索 ' + (showDisplayTitle(navState.showKey, navState.showTitle) || '')) : (appLang === 'hi' ? ((showDisplayTitle(navState.showKey, navState.showTitle) || '') + ' खोजें') : ('البحث في مواسم ' + (showDisplayTitle(navState.showKey, navState.showTitle) || ''))))); } catch (e) { listSearchInput.placeholder = 'Search...'; }
            } else if (navState.level === 3) {
                breadcrumbPath.classList.remove('hidden');
                breadcrumbPath.classList.add('flex');
                document.getElementById('pathShowTitle').textContent = showDisplayTitle(navState.showKey, navState.showTitle);

                const pathSeason = document.getElementById('pathSeasonTitle');
                pathSeason.classList.remove('hidden');
                pathSeason.textContent = ' — ' + tLang('seasonLabel') + ' ' + navState.seasonNumber;
                try { listSearchInput.placeholder = (appLang === 'en' ? ('Search season ' + navState.seasonNumber + ' episodes') : (appLang === 'zh' ? ('搜索第 ' + navState.seasonNumber + ' 季') : (appLang === 'hi' ? ('सीजन ' + navState.seasonNumber + ' खोजें') : ('البحث في حلقات الموسم ' + navState.seasonNumber)))); } catch (e) { listSearchInput.placeholder = 'Search...'; }
            }
        }

        backToMainBtn.addEventListener('click', () => {
            if (navState.level === 3) {
                navState.level = 2;
                navState.seasonNumber = null;
            } else {
                navState.level = 1;
                navState.showTitle = null;
                navState.showKey = null;
            }
            listSearchInput.value = '';
            listSearchQuery = '';
            clearListSearchBtn.classList.add('hidden');
            inSelectionMode = false; selectedKeys.clear();
            disarmDeleteBtn();
            refreshApp();
        });

        // ===== المفضلة: تثبيت المحتوى المميز أعلى القائمة + مزامنة سحابية =====
        function isShowFav(show) { try { return !!(show && show.items && show.items.length && show.items.every(i => i.isFavorite)); } catch (e) { return false; } }
        function toggleFavShow(showKey) {
            const lst = (parsedItems || []).filter(i => i.category === 'tv' && groupKeyOf(i) === showKey);
            if (!lst.length) return;
            const allFav = lst.every(i => i.isFavorite);
            lst.forEach(i => { i.isFavorite = !allFav; });
            saveItemsToStorage();
            refreshApp();
            showStatus(!allFav ? tLang('favAdded') : tLang('favRemoved'), !allFav ? "success" : "info");
        }
        function toggleFavItem(id) {
            const it = (parsedItems || []).find(i => i.id === id);
            if (!it) return;
            it.isFavorite = !it.isFavorite;
            saveItemsToStorage();
            refreshApp();
            showStatus(it.isFavorite ? tLang('favAdded') : tLang('favRemoved'), it.isFavorite ? "success" : "info");
        }
        function favRankEntry(e) {
            try {
                if (e && e.isShowGroup) return isShowFav(e) ? 0 : 1;
                return (e && e.isFavorite) ? 0 : 1;
            } catch (ee) { return 1; }
        }
        // Level 1: Folders / Shows / Movies / Live
        function prepareLevel1List(items) {
            const showsMap = new Map();
            const standaloneItems = [];

            items.forEach(item => {
                if (item.category === 'tv') {
                    const key = groupKeyOf(item) || normalizeShowKey(item.cleanTitle || "unknown");
                    const disp = locTitleOf(item) || item.metaTitle || item.parsedShowTitle || item.cleanTitle || key;
                    if (!showsMap.has(key)) {
                        showsMap.set(key, {
                            isShowGroup: true,
                            key: key,
                            title: disp,
                        i18n: item.i18n || null,
                            poster: item.poster || item.logo || generateSvgAvatar(key),
                            overview: item.overview || '',
                            year: item.year || '',
                            rating: item.rating || '',
                            genres: item.genres || '',
                            tmdbDetails: item.tmdbDetails || null,
                            episodesCount: 0,
                            items: []
                        });
                    }
                    const showData = showsMap.get(key);
                    if (item.metaTitle && showData.title !== item.metaTitle && groupKeyOf({metaTitle: showData.title}) !== groupKeyOf(item)) {
                        // keep original folder-derived title; documented TMDB title shown via metaTitle items
                    }
                    if (!showData.i18n && item.i18n) showData.i18n = item.i18n;
                    showData.episodesCount++;
                    showData.items.push(item);
                } else {
                    standaloneItems.push(item);
                }
            });

            showsMap.forEach(function (sd) {
                try {
                    if (!sd.i18n) { const f = (sd.items || []).find(function (x) { return x && x.i18n; }); if (f) sd.i18n = f.i18n; }
                    if (sd.i18n) (sd.items || []).forEach(function (x) { try { if (x && !x.i18n) x.i18n = sd.i18n; } catch (e) {} });
                } catch (e) {}
            });
            let list = [...showsMap.values(), ...standaloneItems];
            try { list.sort((a, b) => favRankEntry(a) - favRankEntry(b)); } catch (e) {}

            if (listSearchQuery !== '') {
                list = list.filter(item => {
                    const name = (item.title || locTitleOf(item) || item.metaTitle || item.cleanTitle || '').toLowerCase();
                    return name.includes(listSearchQuery);
                });
            }

            activeRenderList = list;
        }

        // Level 2: Seasons inside Specific Show Folder
        function prepareLevel2List(items) {
            const nk = navState.showKey || normalizeShowKey(navState.showTitle || "");
            const showItems = items.filter(i => groupKeyOf(i) === nk || (!nk && (i.metaTitle || i.parsedShowTitle || i.cleanTitle) === navState.showTitle));
            const seasonsMap = new Map();

            showItems.forEach(item => {
                const sNum = item.seasonNumber || 1;
                if (!seasonsMap.has(sNum)) {
                    seasonsMap.set(sNum, []);
                }
                seasonsMap.get(sNum).push(item);
            });

            const sortedSeasons = Array.from(seasonsMap.keys()).sort((a, b) => a - b);
            let list = sortedSeasons.map(sNum => ({
                isSeasonFolder: true,
                seasonNumber: sNum,
                episodesList: seasonsMap.get(sNum)
            }));

            if (listSearchQuery !== '') {
                list = list.filter(s => {
                    const sText = ('الموسم ' + s.seasonNumber + ' ' + tLang('seasonLabel') + ' ' + s.seasonNumber).toLowerCase();
                    const numText = `${s.seasonNumber}`;
                    return sText.includes(listSearchQuery) || numText.includes(listSearchQuery);
                });
            }

            activeRenderList = list;
        }

        // Level 3: Episodes inside Specific Season
        function prepareLevel3List(items) {
            const nk3 = navState.showKey || normalizeShowKey(navState.showTitle || "");
            let list = items.filter(i =>
                (groupKeyOf(i) === nk3 || (!nk3 && (i.metaTitle || i.parsedShowTitle || i.cleanTitle) === navState.showTitle)) &&
                (i.seasonNumber || 1) === navState.seasonNumber
            ).sort((a, b) => (a.episodeNumber || 0) - (b.episodeNumber || 0));

            if (listSearchQuery !== '') {
                list = list.filter(i => {
                    const epTitle = (i.episodeTitle || '').toLowerCase();
                    const epNum = `${i.episodeNumber || ''}`;
                    return epTitle.includes(listSearchQuery) || epNum.includes(listSearchQuery);
                });
            }

            activeRenderList = list;
        }

        // ===== القائمة الكسولة v2: طبقتان (معلومات ±50 بلا صور / صور ±15)، إلغاء بالأجيال، كاش عقد =====
        // لا رسم أثناء السكرول المتتابع؛ بعد الاستقرار تُبنى النافذة حول العنصر الأوسط:
        // ±50 بطاقة معلومات فقط (بلا أي تحميل شبكي للصور)، و±15 بالصور الحقيقية.
        // الابتعاد ≥5 عناصر قبل الاستقرار يجهض تحميل الصور المعلقة فوراً، وتبديل
        // التبويب/البحث/التنقل يلغي تحميل السابق ويركّز على الجديد. كاش العقد (140)
        // يعيد استخدام ما رُسم سابقاً ولا يعيد بناءه إلا عند تجاوز السعة (إزاحة LRU).
        var VL = { start: -1, end: -1, center: -1, imgStart: -1, imgEnd: -1, avgH: 170,
            h: { show: 155, single: 175, season: 66, ep: 58 }, gap: 10,
            INFO_WIN: 50, IMG_WIN: 15, MOVE_CANCEL: 5, CACHE_MAX: 140,
            measured: {}, gen: 0, imgGen: 0, cache: new Map() };
        function vlTypeOf(d) {
            try {
                if (!d) return 'single';
                if (d.isSeasonFolder) return 'season';
                if (d.isShowGroup) return 'show';
                if (typeof navState !== 'undefined' && navState.level === 3) return 'ep';
            } catch (e) {}
            return 'single';
        }
        function vlKeyOf(d) {
            try {
                if (!d) return 'x';
                if (d.isShowGroup) return 'g:' + d.key;
                if (d.isSeasonFolder) return 's:' + (navState.showKey || '') + ':' + d.seasonNumber;
                return 'id:' + d.id;
            } catch (e) { return 'x'; }
        }
        function vlEstH(d) {
            try {
                const m = VL.measured[vlKeyOf(d)];
                if (m) return m + VL.gap;
                return (VL.h[vlTypeOf(d)] || 150) + VL.gap;
            } catch (e) { return 160; }
        }
        function vlBuildCard(data) {
            let card = null;
            if (data.isShowGroup) {
                card = createShowListViewCard(data);
            } else if (data.isSeasonFolder) {
                card = createSeasonFolderCard(data);
            } else if (navState.level === 3) {
                card = createEpisodeCard(data);
            } else {
                card = createSingleItemListViewCard(data);
            }
            if (card) { bindLongPress(card, data); attachSelector(card, data); }
            return card;
        }
        function vlCacheTouch(key, node) { try { VL.cache.delete(key); VL.cache.set(key, { node: node }); } catch (e) {} }
        // إزاحة LRU: الأقدم أولاً، ولا تُمسّ عقد النافذة الحالية أبداً
        function vlCacheEvict() {
            try {
                const win = {};
                for (let i = VL.start; i < VL.end; i++) { try { win[vlKeyOf(activeRenderList[i])] = 1; } catch (e) {} }
                let guard = 0;
                for (const k of VL.cache.keys()) {
                    if (VL.cache.size <= VL.CACHE_MAX || guard++ > 600) break;
                    if (!win[k]) VL.cache.delete(k);
                }
            } catch (e) {}
        }
        // إخفاء الصور الشبكية مع حفظ مصدرها (بلا طلبات شبكة، مع بقاء الأبعاد)
        function vlStripImages(node) {
            try {
                node.querySelectorAll('img').forEach(function (im) {
                    const s = im.getAttribute('src') || '';
                    if (/^https?:/i.test(s)) { im.dataset.vlsrc = s; im.removeAttribute('src'); }
                });
            } catch (e) {}
        }
        // إعادة وصل الصور عند دخول نطاق ±15 (ومسح الأثر بعد الوصل)
        function vlAttachImages(node) {
            try {
                node.querySelectorAll('img').forEach(function (im) {
                    const s = im.dataset.vlsrc;
                    if (s && im.getAttribute('src') !== s) { im.setAttribute('src', s); try { delete im.dataset.vlsrc; } catch (e) { try { im.removeAttribute('data-vlsrc'); } catch (ee) {} } }
                });
            } catch (e) {}
        }
        // إجهاض تحميل الصور المعلقة فقط (المكتملة يُترك) — يُستدعى عند الابتعاد ≥5
        function vlAbortPendingImages() {
            try {
                itemsGrid.querySelectorAll('img').forEach(function (im) {
                    if (!im.complete) {
                        const s = im.getAttribute('src') || '';
                        if (/^https?:/i.test(s)) { im.dataset.vlsrc = s; im.removeAttribute('src'); }
                    }
                });
            } catch (e) {}
        }
        function vlHeights(list) {
            const n = list.length, hs = new Array(n), pref = new Array(n + 1);
            pref[0] = 0;
            for (let i = 0; i < n; i++) { const h = vlEstH(list[i]); hs[i] = h; pref[i + 1] = pref[i] + h; }
            try { VL.avgH = n ? Math.max(40, pref[n] / n) : 170; } catch (e) {}
            return { hs: hs, pref: pref, total: pref[n] };
        }
        function vlCenterFrom(pref, n, middle) {
            let lo = 0, hi = n;
            while (lo < hi) { const mid = (lo + hi) >> 1; if (pref[mid + 1] < middle) lo = mid + 1; else hi = mid; }
            return Math.max(0, Math.min(n - 1, lo));
        }
        function renderCurrentLevelList() {
            itemsGrid.className = "flex flex-col gap-2.5";
            renderListWindow(false);
        }
        function renderListWindow(fromScroll) {
            const list = activeRenderList;
            const grid = itemsGrid;
            if (!list || !list.length) {
                try { grid.innerHTML = '<div class="text-center py-8 text-slate-500 text-xs">' + tLang('noResults') + '</div>'; } catch (e) { grid.innerHTML = '<div class="text-center py-8 text-slate-500 text-xs">No results.</div>'; }
                updateSelectionToolbar();
                return;
            }
            let ls = null;
            try { ls = document.getElementById('listScroll'); } catch (e) {}
            let gridTop = 0;
            try {
                if (ls && grid) {
                    const gr = grid.getBoundingClientRect(), lr = ls.getBoundingClientRect();
                    gridTop = gr.top - lr.top + ls.scrollTop;
                }
            } catch (e) {}
            const scrollTop = (ls && ls.scrollTop) || 0;
            const viewH = (ls && ls.clientHeight) || 700;
            const viewTop = Math.max(0, scrollTop - gridTop);
            const n = list.length;
            const HH = vlHeights(list);
            const center = vlCenterFrom(HH.pref, n, viewTop + viewH / 2);
            VL.center = center;
            const start = Math.max(0, center - VL.INFO_WIN);
            const end = Math.min(n, center + VL.INFO_WIN + 1);
            const imgS = Math.max(0, center - VL.IMG_WIN);
            const imgE = Math.min(n, center + VL.IMG_WIN + 1);
            if (fromScroll && start === VL.start && end === VL.end && imgS === VL.imgStart && imgE === VL.imgEnd) return;
            VL.start = start; VL.end = end; VL.imgStart = imgS; VL.imgEnd = imgE;
            const g = VL.gen;
            const frag = document.createDocumentFragment();
            const topSp = document.createElement('div');
            topSp.className = 'vl-spacer';
            topSp.style.height = Math.max(0, HH.pref[start] - (start > 0 ? VL.gap : 0)) + 'px';
            frag.appendChild(topSp);
            for (let i = start; i < end; i++) {
                if (VL.gen !== g) return; // تبديل تبويب/بحث أثناء البناء: ألغِ القديم فوراً
                const data = list[i];
                let key = '';
                try { key = vlKeyOf(data); } catch (e) {}
                let card = null;
                const hit = (key && VL.cache.get(key)) || null;
                if (hit && hit.node) {
                    card = hit.node;
                    try { card.querySelectorAll('.sel-box').forEach(function (x) { x.remove(); }); attachSelector(card, data); } catch (e) {}
                } else {
                    try { card = vlBuildCard(data); } catch (e) { card = null; }
                }
                if (card) {
                    try {
                        card.classList.add('vl-card', 'vl-' + vlTypeOf(data));
                        card._vlIdx = i;
                    } catch (e) {}
                    if (i >= imgS && i < imgE) { try { vlAttachImages(card); } catch (e) {} }
                    else { try { vlStripImages(card); } catch (e) {} }
                    if (key) vlCacheTouch(key, card);
                    frag.appendChild(card);
                }
            }
            grid.innerHTML = '';
            grid.appendChild(frag);
            const botSp = document.createElement('div');
            botSp.className = 'vl-spacer';
            botSp.style.height = Math.max(0, HH.total - HH.pref[end]) + 'px';
            grid.appendChild(botSp);
            vlCacheEvict();
            updateSelectionToolbar();
            // قياس حي: نحدّث متوسط ارتفاع كل نوع + ارتفاعات العناصر المقاسة فعلاً
            try {
                const sums = {}, ns = {};
                grid.querySelectorAll(':scope > div.vl-card').forEach(function (c) {
                    const ii = c._vlIdx;
                    if (ii == null || !list[ii]) return;
                    let h = 0;
                    try { h = c.getBoundingClientRect().height; } catch (e) {}
                    if (!h || h > 1200) return;
                    const t = vlTypeOf(list[ii]);
                    sums[t] = (sums[t] || 0) + h; ns[t] = (ns[t] || 0) + 1;
                    try { VL.measured[vlKeyOf(list[ii])] = Math.round(h); } catch (e) {}
                });
                for (const t in sums) {
                    if (ns[t] > 0) {
                        const avg = sums[t] / ns[t];
                        VL.h[t] = Math.round((VL.h[t] || avg) * 0.6 + avg * 0.4);
                    }
                }
                try {
                    const ks = Object.keys(VL.measured);
                    if (ks.length > 3000) { for (let qi = 0; qi < ks.length - 3000; qi++) delete VL.measured[ks[qi]]; }
                } catch (e) {}
            } catch (e) {}
        }

        // فتح ديالوغ اختيار المشغلات يتطلب ضغطتين (حلقة/فيلم/قناة): الأولى تسليح، الثانية فتح
        function bindDoubleOpen(el, fn, ringCls) {
            let armTimer = null;
            const ring = ringCls || 'ring-emerald-500';
            try { el.classList.add('select-none'); } catch (e) {}
            el.addEventListener('click', (e) => {
                if (e.target && e.target.closest && e.target.closest('.ep-num-badge')) return;
                if (armTimer) {
                    clearTimeout(armTimer);
                    armTimer = null;
                    try { el.classList.remove('ring-1', 'ring-emerald-500', 'ring-purple-500'); } catch (e2) {}
                    fn();
                } else {
                    try { el.classList.add('ring-1', ring); } catch (e2) {}
                    armTimer = setTimeout(() => {
                        armTimer = null;
                        try { el.classList.remove('ring-1', 'ring-emerald-500', 'ring-purple-500'); } catch (e2) {}
                    }, 700);
                }
            });
            el.addEventListener('dblclick', (e) => { try { e.preventDefault(); } catch (e2) {} });
        }

